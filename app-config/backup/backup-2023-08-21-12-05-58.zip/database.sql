#
# TABLE STRUCTURE FOR: achat
#

DROP TABLE IF EXISTS `achat`;

CREATE TABLE `achat` (
  `id_achat` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_fournisseur` int(11) DEFAULT NULL,
  `id_commande` int(11) DEFAULT NULL,
  `code_achat` varchar(200) NOT NULL,
  `num_facture` varchar(200) DEFAULT NULL,
  `date_achat` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `tva` double NOT NULL DEFAULT '20',
  `frais` double NOT NULL DEFAULT '0',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  `id_transport` int(11) DEFAULT NULL,
  `num_expedition` varchar(255) DEFAULT NULL,
  `num_bon_avoir` varchar(255) DEFAULT NULL,
  `bon_avoir` varchar(255) DEFAULT NULL,
  `facture` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_achat`),
  UNIQUE KEY `code_achat` (`code_achat`),
  KEY `id_fournisseur` (`id_fournisseur`),
  KEY `id_user` (`id_user`),
  KEY `id_commande` (`id_commande`),
  KEY `id_transport` (`id_transport`),
  CONSTRAINT `achat_ibfk_1` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseur` (`id_fournisseur`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `achat_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `achat_ibfk_3` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `achat_ibfk_4` FOREIGN KEY (`id_transport`) REFERENCES `transport` (`id_transport`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `achat` (`id_achat`, `id_user`, `id_fournisseur`, `id_commande`, `code_achat`, `num_facture`, `date_achat`, `remarque`, `tva`, `frais`, `date_create`, `date_update`, `id_transport`, `num_expedition`, `num_bon_avoir`, `bon_avoir`, `facture`) VALUES (1, 1, 1, NULL, 'A/23/0010', '111', '2023-08-15', '', '20', '0', '2023-08-15 11:55:37', '2023-08-16 03:57:53', 8, '', '', NULL, NULL);
INSERT INTO `achat` (`id_achat`, `id_user`, `id_fournisseur`, `id_commande`, `code_achat`, `num_facture`, `date_achat`, `remarque`, `tva`, `frais`, `date_create`, `date_update`, `id_transport`, `num_expedition`, `num_bon_avoir`, `bon_avoir`, `facture`) VALUES (2, 1, 1, NULL, 'A/23/0011', '111', '2023-08-15', '', '20', '0', '2023-08-15 12:28:55', '2023-08-16 04:28:20', 8, '', '', NULL, NULL);
INSERT INTO `achat` (`id_achat`, `id_user`, `id_fournisseur`, `id_commande`, `code_achat`, `num_facture`, `date_achat`, `remarque`, `tva`, `frais`, `date_create`, `date_update`, `id_transport`, `num_expedition`, `num_bon_avoir`, `bon_avoir`, `facture`) VALUES (3, 1, 1, 1, 'A/23/0012', '', '2023-08-16', '', '20', '0', '2023-08-16 04:28:58', '2023-08-17 05:44:45', 8, '', '', NULL, NULL);
INSERT INTO `achat` (`id_achat`, `id_user`, `id_fournisseur`, `id_commande`, `code_achat`, `num_facture`, `date_achat`, `remarque`, `tva`, `frais`, `date_create`, `date_update`, `id_transport`, `num_expedition`, `num_bon_avoir`, `bon_avoir`, `facture`) VALUES (4, 1, 4, NULL, 'A/23/0013', '312', '2023-08-21', '', '20', '0', '2023-08-21 03:42:57', NULL, 9, '', '', NULL, NULL);


#
# TABLE STRUCTURE FOR: achat_details
#

DROP TABLE IF EXISTS `achat_details`;

CREATE TABLE `achat_details` (
  `id_achat_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_achat` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_achat` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_achat_details`),
  KEY `id_achat` (`id_achat`),
  KEY `achat_details_ibfk_1` (`id_produit`),
  CONSTRAINT `achat_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `achat_details_ibfk_2` FOREIGN KEY (`id_achat`) REFERENCES `achat` (`id_achat`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `achat_details` (`id_achat_details`, `id_achat`, `id_produit`, `quantite`, `prix_achat`, `date_create`, `date_update`) VALUES (5, 1, 1, '11', '66', '2023-08-16 03:57:53', NULL);
INSERT INTO `achat_details` (`id_achat_details`, `id_achat`, `id_produit`, `quantite`, `prix_achat`, `date_create`, `date_update`) VALUES (6, 2, 2, '10', '30', '2023-08-16 04:28:20', NULL);
INSERT INTO `achat_details` (`id_achat_details`, `id_achat`, `id_produit`, `quantite`, `prix_achat`, `date_create`, `date_update`) VALUES (8, 3, 3, '10', '12', '2023-08-17 05:44:45', NULL);
INSERT INTO `achat_details` (`id_achat_details`, `id_achat`, `id_produit`, `quantite`, `prix_achat`, `date_create`, `date_update`) VALUES (9, 4, 32, '10', '9', '2023-08-21 03:42:57', NULL);


#
# TABLE STRUCTURE FOR: adresse
#

DROP TABLE IF EXISTS `adresse`;

CREATE TABLE `adresse` (
  `id_adresse` int(11) NOT NULL AUTO_INCREMENT,
  `id_commande` int(11) DEFAULT NULL,
  `id_achat` int(11) DEFAULT NULL,
  `id_client_cmd` int(11) DEFAULT NULL,
  `id_devis` int(11) DEFAULT NULL,
  `id_vente` int(11) DEFAULT NULL,
  `id_avoir` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `id_fournisseur` int(11) DEFAULT NULL,
  `ice` varchar(200) DEFAULT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `adresse` varchar(200) DEFAULT NULL,
  `ville` varchar(200) DEFAULT NULL,
  `pays` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_adresse`),
  KEY `id_commande` (`id_commande`),
  KEY `id_achat` (`id_achat`),
  KEY `id_vente` (`id_vente`),
  KEY `id_avoir` (`id_avoir`),
  KEY `id_client` (`id_client`),
  KEY `id_fournisseur` (`id_fournisseur`),
  KEY `id_client_cmd` (`id_client_cmd`),
  KEY `id_devis` (`id_devis`),
  CONSTRAINT `adresse_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_2` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_3` FOREIGN KEY (`id_achat`) REFERENCES `achat` (`id_achat`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_4` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_5` FOREIGN KEY (`id_avoir`) REFERENCES `avoir` (`id_avoir`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_6` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseur` (`id_fournisseur`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_7` FOREIGN KEY (`id_client_cmd`) REFERENCES `client_cmd` (`id_client_cmd`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_8` FOREIGN KEY (`id_devis`) REFERENCES `devis` (`id_devis`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (1, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 'Keaton Gould', 'Eligendi deleniti al', 'Lorem perspiciatis ', 'Liban', '2023-08-15 05:05:30', '2023-08-21 03:31:58');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (2, NULL, 1, NULL, NULL, NULL, NULL, NULL, 1, NULL, 'Keaton Gould', 'Eligendi deleniti al', 'Lorem perspiciatis ', 'Liban', '2023-08-15 11:55:37', '2023-08-16 03:57:53');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (3, NULL, 2, NULL, NULL, NULL, NULL, NULL, 1, NULL, 'Keaton Gould', 'Eligendi deleniti al', 'Lorem perspiciatis ', 'Liban', '2023-08-15 12:28:55', '2023-08-16 04:28:20');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (4, NULL, 3, NULL, NULL, NULL, NULL, NULL, 1, NULL, 'Keaton Gould', 'Eligendi deleniti al', 'Lorem perspiciatis ', 'Liban', '2023-08-16 04:28:58', '2023-08-17 05:44:45');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (15, NULL, NULL, NULL, NULL, 11, NULL, 7, NULL, 'Eu veniam voluptate', 'Phoebe Ryan', 'Perspiciatis volupt', 'Anim earum commodo s', 'Cuba', '2023-08-16 04:56:48', '2023-08-16 09:47:32');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (16, NULL, NULL, NULL, NULL, 12, NULL, 1, NULL, NULL, 'CLIENT COMPTOIRE1', '', 'Fes', 'Maroc', '2023-08-16 08:37:14', NULL);
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (17, NULL, NULL, NULL, NULL, 13, NULL, 4, NULL, 'Deserunt ', 'Warren White', 'Accusamus velit volu', 'Et expedita dolores ', 'Grenade', '2023-08-16 08:52:02', '2023-08-16 09:47:20');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (21, NULL, NULL, 1, NULL, NULL, NULL, 4, NULL, NULL, 'Warren White', 'Accusamus velit volu', 'Et expedita dolores ', 'Grenade', '2023-08-16 09:13:00', '2023-08-17 05:41:47');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (25, NULL, NULL, NULL, 7, NULL, NULL, 5, NULL, 'Iusto fugiat debitis', 'Dawn Bauer', 'Cumque dolor enim to', 'Nisi obcaecati provi', 'Slovaquie', '2023-08-17 04:45:23', '2023-08-18 04:55:03');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (26, NULL, NULL, NULL, NULL, 14, NULL, 5, NULL, 'Iusto fugiat debitis', 'Dawn Bauer', 'Cumque dolor enim to', 'Nisi obcaecati provi', 'Slovaquie', '2023-08-17 04:48:52', NULL);
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (27, NULL, NULL, NULL, 8, NULL, NULL, 4, NULL, 'Deserunt ', 'Warren White', 'Accusamus velit volu', 'Et expedita dolores ', 'Grenade', '2023-08-17 04:54:43', '2023-08-17 04:54:58');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (28, NULL, NULL, NULL, NULL, 15, NULL, 4, NULL, 'Deserunt ', 'Warren White', 'Accusamus velit volu', 'Et expedita dolores ', 'Grenade', '2023-08-18 05:49:21', NULL);
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (29, NULL, NULL, NULL, NULL, 16, NULL, 8, NULL, 'Quaerat asperiores v', 'Shay Stokes', 'Nihil unde autem iur', 'Laboriosam magnam v', 'Népal', '2023-08-18 05:54:26', '2023-08-19 04:39:30');
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (31, NULL, NULL, NULL, NULL, 18, NULL, 4, NULL, 'Deserunt ', 'Warren White', 'Accusamus velit volu', 'Et expedita dolores ', 'Grenade', '2023-08-19 04:52:07', NULL);
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (32, NULL, 4, NULL, NULL, NULL, NULL, NULL, 4, NULL, 'Mahmoud', 'Ut qui facilis qui', 'Dolor autem nulla', 'Maroc', '2023-08-21 03:42:57', NULL);
INSERT INTO `adresse` (`id_adresse`, `id_commande`, `id_achat`, `id_client_cmd`, `id_devis`, `id_vente`, `id_avoir`, `id_client`, `id_fournisseur`, `ice`, `full_name`, `adresse`, `ville`, `pays`, `date_create`, `date_update`) VALUES (33, NULL, NULL, 2, NULL, NULL, NULL, 7, NULL, NULL, 'Phoebe Ryan', 'Perspiciatis volupt', 'Anim earum commodo s', 'Cuba', '2023-08-21 05:21:45', NULL);


#
# TABLE STRUCTURE FOR: auto_code
#

DROP TABLE IF EXISTS `auto_code`;

CREATE TABLE `auto_code` (
  `reference` varchar(200) NOT NULL,
  `year` int(11) NOT NULL DEFAULT '2000',
  `next_value` int(11) NOT NULL DEFAULT '1',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`reference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('A', 2023, 14, NULL, '2023-08-21 03:42:57');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('BA', 2023, 1, NULL, '2023-08-14 03:34:08');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('BL', 2023, 20, NULL, '2023-08-19 04:52:07');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('C', 2023, 8, NULL, '2023-08-15 05:01:04');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('CC', 2023, 3, NULL, '2023-08-21 05:21:45');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('CF', 2023, 2, NULL, '2023-08-15 05:05:30');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('D', 2023, 19, NULL, '2023-08-17 04:54:43');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('DM', 2023, 1, NULL, '2023-08-14 03:33:16');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('F', 2023, 5, NULL, '2023-08-21 03:39:11');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('INVOICE', 2023, 58, NULL, '2023-08-21 05:14:19');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('IV', 2023, 5, NULL, '2023-08-21 03:44:24');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('PD', 2023, 1, NULL, '2023-08-14 03:57:27');


#
# TABLE STRUCTURE FOR: avance
#

DROP TABLE IF EXISTS `avance`;

CREATE TABLE `avance` (
  `id_avance` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `date_avance` date NOT NULL,
  `montant` double NOT NULL,
  `methode` int(11) NOT NULL COMMENT '1=Espece, 2=Cheque, 3=Effet, 4=Virement',
  `description` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avance`),
  KEY `id_client` (`id_client`,`id_user`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `avance_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avance_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `avance` (`id_avance`, `id_client`, `id_user`, `date_avance`, `montant`, `methode`, `description`, `date_create`, `date_update`) VALUES (1, 3, 1, '2023-08-14', '1000', 1, '', '2023-08-14 03:45:07', NULL);


#
# TABLE STRUCTURE FOR: avance_retour
#

DROP TABLE IF EXISTS `avance_retour`;

CREATE TABLE `avance_retour` (
  `id_avance_retour` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `date_retour` date NOT NULL,
  `montant` double NOT NULL,
  `methode` int(11) NOT NULL COMMENT '1=Espece, 2=Cheque, 3=Effet, 4=Virement, 5=From Avance',
  `type_avance` tinyint(4) DEFAULT NULL COMMENT '1=Espece, 2=Cheque/Effet, 3=Virement',
  `description` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avance_retour`),
  KEY `id_client` (`id_client`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `avance_retour_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avance_retour_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: avoir
#

DROP TABLE IF EXISTS `avoir`;

CREATE TABLE `avoir` (
  `id_avoir` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_vente` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `code_avoir` varchar(200) NOT NULL,
  `date_avoir` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `tva` double NOT NULL DEFAULT '20',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avoir`),
  UNIQUE KEY `code_avoir` (`code_avoir`),
  KEY `id_user` (`id_user`),
  KEY `id_client` (`id_client`),
  KEY `avoir_ibfk_3` (`id_vente`),
  CONSTRAINT `avoir_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avoir_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avoir_ibfk_3` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: avoir_details_in
#

DROP TABLE IF EXISTS `avoir_details_in`;

CREATE TABLE `avoir_details_in` (
  `id_avoir_details_in` int(11) NOT NULL AUTO_INCREMENT,
  `id_avoir` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '0',
  `remise` double NOT NULL DEFAULT '0',
  `remise_dh` double NOT NULL DEFAULT '0',
  `etat` int(11) NOT NULL COMMENT '1=GOOD, 0=BROKEN',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avoir_details_in`),
  KEY `id_produit` (`id_produit`),
  KEY `id_avoir` (`id_avoir`),
  CONSTRAINT `avoir_details_in_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avoir_details_in_ibfk_2` FOREIGN KEY (`id_avoir`) REFERENCES `avoir` (`id_avoir`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: avoir_details_out
#

DROP TABLE IF EXISTS `avoir_details_out`;

CREATE TABLE `avoir_details_out` (
  `id_avoir_details_out` int(11) NOT NULL AUTO_INCREMENT,
  `id_avoir` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '0',
  `remise` double NOT NULL DEFAULT '0',
  `remise_dh` double NOT NULL DEFAULT '0',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avoir_details_out`),
  KEY `id_produit` (`id_produit`),
  KEY `id_avoir` (`id_avoir`),
  CONSTRAINT `avoir_details_out_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avoir_details_out_ibfk_2` FOREIGN KEY (`id_avoir`) REFERENCES `avoir` (`id_avoir`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: caisse_entree
#

DROP TABLE IF EXISTS `caisse_entree`;

CREATE TABLE `caisse_entree` (
  `id_caisse_entree` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `montant` double NOT NULL,
  `date_entree` date NOT NULL,
  `description` varchar(200) NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_caisse_entree`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `caisse_entree_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `caisse_entree` (`id_caisse_entree`, `id_user`, `montant`, `date_entree`, `description`, `date_create`, `date_update`) VALUES (1, 1, '1000', '2009-07-09', 'Eiusmod assumenda eos ullam nulla animi repellendus Non voluptate harum repellendus Velit suscipit non est eius earum', '2023-08-14 03:45:50', NULL);
INSERT INTO `caisse_entree` (`id_caisse_entree`, `id_user`, `montant`, `date_entree`, `description`, `date_create`, `date_update`) VALUES (2, 1, '20000', '2023-08-16', 'cfvbhjn', '2023-08-16 04:27:35', NULL);
INSERT INTO `caisse_entree` (`id_caisse_entree`, `id_user`, `montant`, `date_entree`, `description`, `date_create`, `date_update`) VALUES (3, 1, '1000', '2023-08-18', 'pour teste c tous', '2023-08-18 03:48:22', NULL);


#
# TABLE STRUCTURE FOR: caisse_sortie
#

DROP TABLE IF EXISTS `caisse_sortie`;

CREATE TABLE `caisse_sortie` (
  `id_caisse_sortie` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `montant` double NOT NULL,
  `date_sortie` date NOT NULL,
  `description` varchar(200) NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_caisse_sortie`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `caisse_sortie_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `caisse_sortie` (`id_caisse_sortie`, `id_user`, `montant`, `date_sortie`, `description`, `date_create`, `date_update`) VALUES (1, 1, '500', '1998-01-30', 'Molestiae labore deserunt unde quia et aut omnis aute do omnis ex officiis maiores natus ut qui non dignissimos', '2023-08-14 03:46:23', NULL);


#
# TABLE STRUCTURE FOR: categorie
#

DROP TABLE IF EXISTS `categorie`;

CREATE TABLE `categorie` (
  `id_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `categorie` (`id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (1, 'Shellie Santoss', 'Irure deserunt consequuntur sint et facere qui blanditiis aliquip sint veniam fugit in nostrum nesciunt deserunt velit omnis esse in', 0, '2023-08-14 03:31:56', '2023-08-17 04:49:12');
INSERT INTO `categorie` (`id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (3, 'Catherine Wolfe', 'Tenetur eligendi q\r\n', 0, '2023-08-14 03:56:27', '2023-08-14 03:57:00');
INSERT INTO `categorie` (`id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (4, 'Abdul Clark', 'Qui dolor pariatur Molestias numquam rerum ipsum corporis consequuntur eos cillum dolor saepe numquam ea eum sit suscipit', 1, '2023-08-14 11:55:09', '2023-08-18 03:31:51');
INSERT INTO `categorie` (`id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (5, 'Howard Jacobs', 'Dolor tenetur atque perspiciatis labore veniam deleniti sint Nam consequatur aut id est reiciendis provident qui dolore', 1, '2023-08-15 05:02:22', '2023-08-15 05:02:39');
INSERT INTO `categorie` (`id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (6, 'Categorie 3', 'juste pour le teste c tous', 1, '2023-08-18 03:32:18', '2023-08-18 03:32:28');
INSERT INTO `categorie` (`id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (7, 'Catégorie 4', '', 1, '2023-08-21 03:36:59', NULL);


#
# TABLE STRUCTURE FOR: charge
#

DROP TABLE IF EXISTS `charge`;

CREATE TABLE `charge` (
  `id_charge` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `date_charge` date NOT NULL,
  `montant` double NOT NULL,
  `methode` int(11) NOT NULL COMMENT '1=Espece, 2=Cheque, 3=Effet, 4=Virement',
  `description` varchar(200) NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_charge`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `charge_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `charge` (`id_charge`, `id_user`, `date_charge`, `montant`, `methode`, `description`, `date_create`, `date_update`) VALUES (1, 1, '2023-08-17', '100', 1, 'sedfrghnjm', '2023-08-17 06:00:06', NULL);


#
# TABLE STRUCTURE FOR: cheque
#

DROP TABLE IF EXISTS `cheque`;

CREATE TABLE `cheque` (
  `id_cheque` int(11) NOT NULL AUTO_INCREMENT,
  `id_paiement` int(11) DEFAULT NULL,
  `id_charge` int(11) DEFAULT NULL,
  `id_avance` int(11) DEFAULT NULL,
  `id_avance_retour` int(11) DEFAULT NULL,
  `date_cheque` date NOT NULL,
  `montant` double NOT NULL,
  `reference` varchar(200) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1=Vente, 2=Achat, 3=Reglement, 4=Charge, 5=Avance, 6=Retour d''Avance',
  `methode` tinyint(4) NOT NULL COMMENT '2=Cheque, 3=Effet',
  `remarque` varchar(200) DEFAULT NULL,
  `paid` tinyint(4) NOT NULL DEFAULT '0' COMMENT ' 0=Not Yet, 1=Paid, 2=Unpaid',
  `caisse` tinyint(4) DEFAULT NULL COMMENT '0=Bank, 1=Caisse',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cheque`),
  KEY `id_paiement` (`id_paiement`),
  KEY `id_charge` (`id_charge`),
  KEY `id_avance` (`id_avance`),
  KEY `id_avance_retour` (`id_avance_retour`),
  CONSTRAINT `cheque_ibfk_1` FOREIGN KEY (`id_paiement`) REFERENCES `paiement` (`id_paiement`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cheque_ibfk_2` FOREIGN KEY (`id_charge`) REFERENCES `charge` (`id_charge`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cheque_ibfk_3` FOREIGN KEY (`id_avance`) REFERENCES `avance` (`id_avance`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cheque_ibfk_4` FOREIGN KEY (`id_avance_retour`) REFERENCES `avance_retour` (`id_avance_retour`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0023193711923591ed34db24d3702c064aeef3f5', '196.206.77.183', 1692347028, '__ci_last_regenerate|i:1692347028;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('002a58d4362c5caf6148e5480d78f67964967f83', '196.74.158.189', 1692265569, '__ci_last_regenerate|i:1692265569;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('006ed6af00f8441d483bd9f2c295fb0f22941803', '196.65.169.61', 1692438672, '__ci_last_regenerate|i:1692438672;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('007df2d92a6953c978be8dde5f7cdc28886dc815', '196.74.145.227', 1692020712, '__ci_last_regenerate|i:1692020712;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01763803da4096da74fcd74da5214d74d2752a24', '196.74.151.235', 1692002475, '__ci_last_regenerate|i:1692002475;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:36:\"Commercial enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0188f7ecde7cb8f7be476ba6b3852bde47ae2cb8', '196.65.169.61', 1692438339, '__ci_last_regenerate|i:1692438339;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01eff64ed27392d118c00c83c041d0f05340bc30', '105.157.143.32', 1692615837, '__ci_last_regenerate|i:1692615837;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('02d401ecf223923af6160f1047b3d4b3fb66313b', '160.179.56.31', 1692443046, '__ci_last_regenerate|i:1692443046;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('02e21f096b9436b846e3caa51f1247d0427d2aa5', '196.65.169.61', 1692357051, '__ci_last_regenerate|i:1692357051;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('04380e9dfcf1448a5490aaa35b9ceb2a85b2c057', '196.74.167.20', 1692113205, '__ci_last_regenerate|i:1692113205;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('052edab7663ddf1cc9526ede1ff04f7ddce288c1', '196.74.167.20', 1692175865, '__ci_last_regenerate|i:1692175865;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('058a334ad0fe41b31f63bc78005cd3411906d811', '196.74.151.235', 1692006432, '__ci_last_regenerate|i:1692006432;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('05b2bf3d6f387a257b40cfbb7867a96ab3547482', '196.74.158.189', 1692264653, '__ci_last_regenerate|i:1692264653;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('069ccc82b1e335fb6e19c84f15f15f650c01b675', '196.74.167.20', 1692174649, '__ci_last_regenerate|i:1692174649;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0757a229a304fc6f16a1b936beb247a82b003801', '196.74.158.189', 1692205129, '__ci_last_regenerate|i:1692205129;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0785d6a2812f1107dc4d71a6de4391ce2d4d2d3e', '196.206.77.183', 1692351828, '__ci_last_regenerate|i:1692351828;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('093c45774501e194bbbd78c38ef0fc0a073ab3d1', '196.74.144.48', 1692606900, '__ci_last_regenerate|i:1692606900;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a0941a3d07e8c9ccbb36eda50ce94ecccfffceb', '196.74.158.189', 1692204630, '__ci_last_regenerate|i:1692204630;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0aba80bcdab63352f8c00df46b82c10642bebd01', '196.74.145.227', 1692015475, '__ci_last_regenerate|i:1692015475;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0abc20e1ffda311ead55743566e1095dc19f6a28', '196.74.151.235', 1692002298, '__ci_last_regenerate|i:1692002298;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ae5f305853fc490633b29d168825151544926ff', '196.74.167.20', 1692180530, '__ci_last_regenerate|i:1692180530;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0afbc3940412c59cd1310bd9442762fcb797b69d', '196.65.169.61', 1692437692, '__ci_last_regenerate|i:1692437692;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b1768583af6eba86f65d80f2a8a5f3c6c625eeb', '196.206.77.183', 1692348509, '__ci_last_regenerate|i:1692348509;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b77195d9bc5892f739948f9a9249e9b168e87c1', '196.74.151.235', 1692004428, '__ci_last_regenerate|i:1692004428;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b82b3d3545d9c9b7a8785d44a39df26d2fc9ac8', '196.206.77.183', 1692290761, '__ci_last_regenerate|i:1692290761;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ca235d7efd66ec4cabd19e8df055ddd16af9cbf', '196.206.77.183', 1692351944, '__ci_last_regenerate|i:1692351944;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0d23b97d3a8de5c020497f79274d3bf945adcdaa', '196.74.158.189', 1692204753, '__ci_last_regenerate|i:1692204753;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0e8fd690c40ba302577b59c0d6045bd016053cbb', '196.74.167.20', 1692106076, '__ci_last_regenerate|i:1692106076;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f1c4c47bed024b4ebd20daf2d30503eff915cb9', '196.74.145.227', 1692026441, '__ci_last_regenerate|i:1692026441;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0fa27dcac474a46406a918119ff2bf01581d32be', '196.65.169.61', 1692434210, '__ci_last_regenerate|i:1692434210;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1035d310e954e3038822e2e32a8d2aecb8ae2c7a', '196.74.151.235', 1692001698, '__ci_last_regenerate|i:1692001698;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10c46f471ee1dbd1164163c0de4aa245d1f450db', '196.74.145.227', 1692092206, '__ci_last_regenerate|i:1692092206;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10d113124bce45a523db91c3cd2568575048ac22', '196.74.151.235', 1692002607, '__ci_last_regenerate|i:1692002607;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('11030d8ea80445f2fe514d9eb05e808c8aff9a9d', '196.74.167.20', 1692118438, '__ci_last_regenerate|i:1692118438;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('11f0a86fa0ed80f69f8337f1a61e84dfd5f2ece4', '196.74.151.235', 1692002783, '__ci_last_regenerate|i:1692002783;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('13114b5804b99b190b108fac945b49e4369f191a', '196.74.158.189', 1692202367, '__ci_last_regenerate|i:1692202367;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:29:\"Facture créée avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('132ac58029955041f6631efb609a53e925f26aa8', '196.74.167.20', 1692105758, '__ci_last_regenerate|i:1692105758;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('13abfeae453e09a77f51b1aac47eaddf082631ea', '196.65.169.61', 1692436521, '__ci_last_regenerate|i:1692436521;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1411aa4cb4e1a864dfc91a84da90c1b7957aa271', '196.74.145.227', 1692023788, '__ci_last_regenerate|i:1692023788;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('14423a3e7229eba7cd44922d2f93dc6fc81d9b19', '196.74.151.235', 1692008591, '__ci_last_regenerate|i:1692008591;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('14dae1cc62527c34c22efdd2be4aaf8c303118f7', '196.74.145.227', 1692023482, '__ci_last_regenerate|i:1692023482;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('14f8317d9e1e4a523b1fcb73e350e33608af99dc', '196.74.158.189', 1692199051, '__ci_last_regenerate|i:1692199051;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('14f85c2ecdb1d8c3d152f05e18cffc2ce9f78a1e', '196.74.145.227', 1692032421, '__ci_last_regenerate|i:1692032236;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('150221339056d13db15dec2a394d0e5e27219bf9', '196.74.158.189', 1692205699, '__ci_last_regenerate|i:1692205699;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1565825774bc5653444696c6f724703c8b89eca2', '196.65.169.61', 1692442051, '__ci_last_regenerate|i:1692442051;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('157c445de76fbd56eb9d7bca0c5871b803631804', '196.74.144.48', 1692611021, '__ci_last_regenerate|i:1692611021;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15c983f671aac11852d5d6ba16dc978f910861d3', '196.74.167.20', 1692104479, '__ci_last_regenerate|i:1692104479;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15e9e465b4b7675c38535483a6a69fd91650bd33', '196.74.158.189', 1692184642, '__ci_last_regenerate|i:1692184642;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('164e5beb661bba322739cf7a3553c657e7a2db1d', '196.74.158.189', 1692195492, '__ci_last_regenerate|i:1692195492;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('184792c66bddffdf68a2a95583555bc38c8bd153', '196.74.167.20', 1692108780, '__ci_last_regenerate|i:1692108780;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('186ae7a9065d859472c38917b71ed5b1a4048430', '196.74.167.20', 1692181044, '__ci_last_regenerate|i:1692181044;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('18d229a33842509bb986e5c7e2ceda9ea4ad24db', '196.206.77.183', 1692355027, '__ci_last_regenerate|i:1692355027;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('198dfb11d9a000e369cd1a295ef0b901a3cc4efe', '196.74.167.20', 1692102539, '__ci_last_regenerate|i:1692102539;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('19daececdd9f368efe8025f65809004b7bc111a3', '196.74.145.227', 1692094018, '__ci_last_regenerate|i:1692094018;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('19e15c55aa68f2d8b64fb81526b0c4b1853895e5', '105.69.222.57', 1692606143, '__ci_last_regenerate|i:1692606143;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1a3b3940a4108af2b2836aee1fec8f1c833c7565', '196.206.77.183', 1692285984, '__ci_last_regenerate|i:1692285984;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1afcb6c6b0b8fb95bd8729117115e028608b6c81', '196.74.158.189', 1692194331, '__ci_last_regenerate|i:1692194331;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b7e3fe3e24d8008d9e282689f17bbcbb2999fde', '196.74.158.189', 1692267027, '__ci_last_regenerate|i:1692267027;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1c309890aa6a0fcfcfec1593a7ad2a0d549f3da7', '196.74.158.189', 1692203770, '__ci_last_regenerate|i:1692203770;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1cd56ac38f2b63d2bdb21c1a0c87ab8cb5ac2172', '196.74.151.235', 1692003227, '__ci_last_regenerate|i:1692003227;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1de836ba9dffd20124959e1bbc180b9587ee4aa9', '196.74.145.227', 1692027569, '__ci_last_regenerate|i:1692027569;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1deaa9456080874842b6c8021a2a31e28df4ee08', '196.206.77.183', 1692355141, '__ci_last_regenerate|i:1692355141;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1e1f814d37569788f1233437ad800feb39a3257e', '196.74.158.189', 1692195183, '__ci_last_regenerate|i:1692195183;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1f72bbcb45c53a0f4663a9ec1427943d89034767', '196.65.169.61', 1692377125, '__ci_last_regenerate|i:1692377125;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1f7e279c4ad1b69048ef9aa6df9061fcb30a7f19', '196.206.77.183', 1692271204, '__ci_last_regenerate|i:1692271204;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1fd9f86a288b8d25f21c5b58105a535f51ccb5d3', '196.74.145.227', 1692027150, '__ci_last_regenerate|i:1692027150;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2100150f3eb34bc6bc61a5ab6c93b62ac88d6cfa', '196.74.144.48', 1692607622, '__ci_last_regenerate|i:1692607622;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2115b1bc6ba6ce10e4d5620ec1642cee156c1011', '196.74.158.189', 1692203933, '__ci_last_regenerate|i:1692203933;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('212147888155807479acc7fdbbd0325762631644', '196.74.158.189', 1692183753, '__ci_last_regenerate|i:1692183753;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2122a88d48dd320b818c73bce24b1f1098b44ae0', '196.74.151.235', 1692003836, '__ci_last_regenerate|i:1692003836;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('21c5bbfe828aa218f2724325f5c8e63d3f8201dc', '196.74.158.189', 1692264330, '__ci_last_regenerate|i:1692264330;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('225b6e3ebd7002cb373492af90ab64dbc1560312', '196.65.169.61', 1692375714, '__ci_last_regenerate|i:1692375714;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2328b09053c9cbc2ea1f0a25ee134f5d7cba1cf4', '196.74.145.227', 1692012153, '__ci_last_regenerate|i:1692012153;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Service enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2436141fbffe21222dcf1fc46685f95a8440bfaa', '196.74.158.189', 1692184375, '__ci_last_regenerate|i:1692184375;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('24718cd955decd6b9a55fc121098a6247f34ec20', '196.74.145.227', 1692091569, '__ci_last_regenerate|i:1692091569;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('24adc0d6933a6dfd87d395051d274373830c229c', '196.206.77.183', 1692347745, '__ci_last_regenerate|i:1692347745;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('254ab78a7655e3b5f4ed37dd47a8b83883ad292c', '196.74.144.48', 1692612829, '__ci_last_regenerate|i:1692612829;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('25758bb7c319c401727fc5db08af0602a624a8fb', '196.74.144.48', 1692613312, '__ci_last_regenerate|i:1692613312;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:44:\"Commande de Client enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('25c529e0eb5c99c06fd96d4c65dc6a0e0b0b4f21', '196.206.77.183', 1692286387, '__ci_last_regenerate|i:1692286387;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('25c85a5150d0721dd63b103c6ce61308433a12d0', '196.65.169.61', 1692376570, '__ci_last_regenerate|i:1692376570;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('26fb2bb488535a39fb11d632551ef04bc636e650', '196.74.167.20', 1692098848, '__ci_last_regenerate|i:1692098848;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2709f64cce04e806ef97630c85d9361b1fca3606', '196.65.169.61', 1692375685, '__ci_last_regenerate|i:1692375685;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('273e0aca0b3297bd25220974671bf9c5249e4656', '196.74.145.227', 1692026875, '__ci_last_regenerate|i:1692026875;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('284aba6edc14be38af86cf5296e1117d40fa332e', '196.74.158.189', 1692268315, '__ci_last_regenerate|i:1692268315;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('29f2b0e6e48557085b835ca94e7849ab31aa7221', '196.74.158.189', 1692260081, '__ci_last_regenerate|i:1692260081;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b7d435fff29ffec450396985444e73f01e6a4a5', '196.74.158.189', 1692268854, '__ci_last_regenerate|i:1692268854;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b81aaee64884c5a71b2de792d23b803130d5af3', '196.206.77.183', 1692279303, '__ci_last_regenerate|i:1692279303;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b973b08074f56c16af71bafc8a1a13a2b2e9414', '196.74.151.235', 1692008946, '__ci_last_regenerate|i:1692008946;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Produit enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2bd86dc45e5c1a994bb973fca51e9c303bdf5eff', '196.65.169.61', 1692356136, '__ci_last_regenerate|i:1692356136;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2c6c5f1a6ed5d23d2a1b648e7d764df2368bb6e1', '196.74.167.20', 1692179808, '__ci_last_regenerate|i:1692179808;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2cbf5359cae4fea2fe6925361bc2685be3a202d6', '196.74.167.20', 1692179201, '__ci_last_regenerate|i:1692179201;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d64e6e73070c225ca4394de23fd4ed5f035e4ea', '196.74.158.189', 1692197108, '__ci_last_regenerate|i:1692197108;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d7597b97ebac82e7fe74e7019bdb219808afb11', '197.253.253.185', 1692283381, '__ci_last_regenerate|i:1692283381;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2dc0ba7dc1dd44f7b24759c51ca2357658491ebe', '196.74.144.48', 1692611718, '__ci_last_regenerate|i:1692611718;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2df88bc1654d88394e69605321202651c66454fc', '196.65.169.61', 1692359040, '__ci_last_regenerate|i:1692359040;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2e359c50ccc662e0e660c76b4eb6278f0d5ddd0b', '196.74.145.227', 1692013206, '__ci_last_regenerate|i:1692013206;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2e5573385f04f7518b5bdf99541e0b5c5807ee50', '196.74.167.20', 1692182975, '__ci_last_regenerate|i:1692182975;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2f4d8948d9cdc95c355b426c741395b5c3d00db2', '196.65.169.61', 1692441938, '__ci_last_regenerate|i:1692441938;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2f9678b601aa35fb901dfdf06fe9ee96bf85701c', '196.74.144.48', 1692611293, '__ci_last_regenerate|i:1692611293;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('306e79b0492947e540c4efbc6e510fbf136d4ca3', '196.74.144.48', 1692614079, '__ci_last_regenerate|i:1692614079;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('31c7943ee7c730204cd016128a8e4f2f745ffc4f', '196.206.77.183', 1692269629, '__ci_last_regenerate|i:1692269629;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('322b905d4be587f18a9eeee11fcc3036011cbff1', '196.74.167.20', 1692117804, '__ci_last_regenerate|i:1692117804;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3287e2c6c4cb43f23956d9d1fae94e992a67a11c', '196.206.77.183', 1692349885, '__ci_last_regenerate|i:1692349885;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32ba72df489848506a319a012fd21ac4111446f2', '196.74.145.227', 1692041231, '__ci_last_regenerate|i:1692041231;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('32c4e6032004d106745dfa327b6eca097f1e1a3f', '196.74.158.189', 1692206637, '__ci_last_regenerate|i:1692206637;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('34219d2edf41fe2f33d440e272e4580119375072', '196.74.145.227', 1692030923, '__ci_last_regenerate|i:1692030923;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('346ba5338128f756e0768f6a8fc9e406f332fd10', '196.74.145.227', 1692024093, '__ci_last_regenerate|i:1692024093;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('35faa5c736c77a6b3f9ac0e908aeeda2d4fceef7', '196.74.145.227', 1692010434, '__ci_last_regenerate|i:1692010434;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Produit enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('363b9236488874b0941382c6cf2e8ce7a2987c69', '196.74.167.20', 1692180219, '__ci_last_regenerate|i:1692180219;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36be967f6e8660ec7a631e12d7da75e5b2f8bcf0', '196.74.145.227', 1692091873, '__ci_last_regenerate|i:1692091873;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('37441e313dfb2e200f933a36db06fda4a990a69a', '196.206.77.183', 1692352258, '__ci_last_regenerate|i:1692352258;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('37580e60b7b20128b0fe5227077e645e5aa593ea', '196.74.145.227', 1692032069, '__ci_last_regenerate|i:1692032069;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('37ffc4f1d68ae81000da8ee682095385714bbef1', '196.74.167.20', 1692109095, '__ci_last_regenerate|i:1692109095;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('383498aed1f9172868eea5fd930e7668b9b7352d', '196.74.167.20', 1692178250, '__ci_last_regenerate|i:1692178250;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39584275e9c215e4891ac1c4365b1e8a199cc874', '196.74.167.20', 1692112524, '__ci_last_regenerate|i:1692112524;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39ad70279399c054e3e2ceb7c1a131654e719028', '196.74.145.227', 1692024394, '__ci_last_regenerate|i:1692024394;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3b43446f161a7f6b81cefa433493d5ae4f62ad8e', '196.89.134.245', 1691841416, '__ci_last_regenerate|i:1691841340;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 12:56\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3b80d450ba427ec9191c3cec8687059d5c13a7e0', '196.74.145.227', 1692029848, '__ci_last_regenerate|i:1692029848;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ca407167561e3df8b032a82ffad2708cd938e2d', '196.74.145.227', 1692020211, '__ci_last_regenerate|i:1692020211;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3d6aca98b1296834242abe5414a9d80280cc8599', '196.74.145.227', 1692012040, '__ci_last_regenerate|i:1692012040;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Produit enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ee0d0aacd0f48a92d3eb0383b755833921319b6', '160.179.56.31', 1692442726, '__ci_last_regenerate|i:1692442726;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3f46926a7920c7613755b3a03e117aed879e10da', '196.74.158.189', 1692266716, '__ci_last_regenerate|i:1692266716;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3f81fa96059be0014906f70b1b46c5fe8ba440f0', '196.74.167.20', 1692114691, '__ci_last_regenerate|i:1692114691;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3faf9ad66e51f01404d74b0804f548403f1dafa3', '196.74.151.235', 1692007569, '__ci_last_regenerate|i:1692007569;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3fd48389edee0213726c820782b4c2c510d4bd5b', '196.74.144.48', 1692609276, '__ci_last_regenerate|i:1692609276;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('40c151d8406d067fa69e903dc630f5b8db6d2827', '196.206.77.183', 1692292549, '__ci_last_regenerate|i:1692292549;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4116a1071aab671d42838d87fdec4ff482ae1e7c', '196.74.144.48', 1692606673, '__ci_last_regenerate|i:1692606673;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('41313d242abd0adb0ab99da29655f27fb7b1ba61', '196.74.158.189', 1692199815, '__ci_last_regenerate|i:1692199815;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('420662835f1d2701e39607b6d2fba516c7402e49', '196.74.145.227', 1692016751, '__ci_last_regenerate|i:1692016751;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('423a6cc8cd5a4656a812a5d5f8d339bc586305de', '196.74.167.20', 1692117341, '__ci_last_regenerate|i:1692117341;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4341afc57a98b5d86a17d3d30932a1fa92d14818', '196.74.158.189', 1692262313, '__ci_last_regenerate|i:1692262313;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('43749121ae88e6291c100b67abf4112c87381675', '196.65.169.61', 1692356742, '__ci_last_regenerate|i:1692356742;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('44339921e7451cebf2492c7692dc313fedb766fb', '196.74.158.189', 1692267332, '__ci_last_regenerate|i:1692267332;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4487c802de7e03c91474785cef238a43cbbbffae', '196.74.158.189', 1692199045, '__ci_last_regenerate|i:1692199045;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('449d83d562520af866e2b9ca5b39353bc475d48d', '196.74.145.227', 1692015123, '__ci_last_regenerate|i:1692015123;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('44abef5f34056875886a2d135871d0c27105b9f2', '196.206.77.183', 1692270632, '__ci_last_regenerate|i:1692270632;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('44f10acc687bd2dc14f3d6dd3b165d4fe95f214b', '196.74.158.189', 1692199355, '__ci_last_regenerate|i:1692199355;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45970f361573ca4b9d3bb382dbc7ddc773a34760', '196.74.167.20', 1692115913, '__ci_last_regenerate|i:1692115913;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45dea01f7c5de9e57fc9cbb959124f3da1f99193', '196.74.144.48', 1692610575, '__ci_last_regenerate|i:1692610575;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('462a4468cea8732c262962300cfc7d2a504f6507', '196.74.145.227', 1692013288, '__ci_last_regenerate|i:1692013288;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Service enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4675ab3b1a8a100d32e4742f0af80feb93a93fe7', '196.74.145.227', 1692026555, '__ci_last_regenerate|i:1692026555;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46f338554ae3b1cd5419fbd77d75e0ce1c2bdaeb', '196.74.158.189', 1692203164, '__ci_last_regenerate|i:1692203164;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('476f0e61f16d18ee0cd97e83aca5300138056e4f', '196.65.169.61', 1692434885, '__ci_last_regenerate|i:1692434885;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('478dfa8a97abe14cb8c4adefd640945ee602f365', '196.74.151.235', 1692009686, '__ci_last_regenerate|i:1692009686;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Produit enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('49050a21129542d37a93c10c12fbbc8a98873cc5', '196.74.167.20', 1692176773, '__ci_last_regenerate|i:1692176773;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:28:\"Achat modifié avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('493f451469fe41d7c4ca28f04614a3ff0110734d', '196.74.167.20', 1692113520, '__ci_last_regenerate|i:1692113520;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('49eef47f67a3d8f65c53eb601ff09350e57eecd7', '196.206.77.183', 1692351478, '__ci_last_regenerate|i:1692351478;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('49ffeee11b5370027f334961554b7f9d31b9e518', '196.74.158.189', 1692193900, '__ci_last_regenerate|i:1692193900;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ad7ea9ad4781888ca58f2424250f6d43a721ef5', '196.74.158.189', 1692262648, '__ci_last_regenerate|i:1692262648;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4af9335a2dd49d6de5191e90eca82d2b951408d7', '196.65.169.61', 1692437084, '__ci_last_regenerate|i:1692437084;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4afb9517037a6267ebc5d29b0b91c248181dfc7f', '196.74.145.227', 1692095636, '__ci_last_regenerate|i:1692095636;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4b8900fa490baeff735aa8b8e1de7136ae748f53', '196.206.77.183', 1692270770, '__ci_last_regenerate|i:1692270770;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4b9d4db2c372d9d8a73600ec2a1715e477491da2', '196.74.145.227', 1692030945, '__ci_last_regenerate|i:1692030945;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4bd8fe38cf52cc4ee15613adc20b7f859af28ef5', '196.65.169.61', 1692356395, '__ci_last_regenerate|i:1692356395;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4c3a9186c444dd5c9ec020af6115d22bc4f249ed', '196.74.145.227', 1692018512, '__ci_last_regenerate|i:1692018512;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4c4bfa35629755d60fcd958feeb1cd44406c1c9f', '196.74.145.227', 1692014264, '__ci_last_regenerate|i:1692014264;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4c5229a3180773703fcdf1e4e35ee6a36841a043', '196.206.77.183', 1692270976, '__ci_last_regenerate|i:1692270976;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4cafd7a84465c1603fb059f08fab8a50db25ad08', '196.74.145.227', 1692023615, '__ci_last_regenerate|i:1692023615;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4d2f8d409b375a1b7ce070c6a57e7e0ee0b091ab', '196.74.145.227', 1692024277, '__ci_last_regenerate|i:1692024277;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4d437c553cdb94803dfe7b696ce9d63d5d9a3cf3', '196.74.167.20', 1692175047, '__ci_last_regenerate|i:1692175047;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4e2254d653770eb9cdf228b611da778414e0d47e', '196.74.167.20', 1692111960, '__ci_last_regenerate|i:1692111960;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4e6d19d0cd0008799d2d2f41095b48326d3396f3', '196.74.145.227', 1692093386, '__ci_last_regenerate|i:1692093386;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4e9c4faa8f4df95648061386b253d8047cefbb5b', '196.65.169.61', 1692374573, '__ci_last_regenerate|i:1692374573;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4eadbbc33672bdca824a5a8be891d6bc8c65bff7', '196.65.169.61', 1692372927, '__ci_last_regenerate|i:1692372927;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ed2fd517aacfb1a9d2888ad025d31919a141107', '196.206.77.183', 1692355420, '__ci_last_regenerate|i:1692355420;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4f05b55b8c7fae7cae24082bb9ee7e1f75964994', '196.74.158.189', 1692200686, '__ci_last_regenerate|i:1692200686;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4f1bace386bd0d5b9cccbd25d4d6bf54c6e1592b', '196.74.167.20', 1692178566, '__ci_last_regenerate|i:1692178566;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4f8bf7190da9048a79008a5548454f0892d5031e', '196.74.145.227', 1692011846, '__ci_last_regenerate|i:1692011846;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('50386fbeeeedbb154e52b95312b91e14f8875b6e', '196.206.77.183', 1692350196, '__ci_last_regenerate|i:1692350196;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('50410c003a75bb308949a3432004e437131fc7ad', '196.74.145.227', 1692031930, '__ci_last_regenerate|i:1692031930;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('50b20a51baf648a8e999cd171cdb2180c22eb80c', '196.74.145.227', 1692032394, '__ci_last_regenerate|i:1692032394;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('51873d7d283eb38afd31f6df88a66462c5b0c6d6', '105.157.138.175', 1692087092, '__ci_last_regenerate|i:1692087092;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('51f4e0b164a7e8f7932a222f20e3679965a806be', '196.74.158.189', 1692194814, '__ci_last_regenerate|i:1692194814;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('527e8156c9e36afe236de61dd1ab016dbbf8b8b3', '196.74.144.48', 1692613585, '__ci_last_regenerate|i:1692613585;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('53ec6b26cfce294f58a982ca50d543ac7f79f859', '196.74.145.227', 1692020056, '__ci_last_regenerate|i:1692020056;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('55d512faf2546c00703f7ab826960da22aa37015', '196.65.169.61', 1692435566, '__ci_last_regenerate|i:1692435566;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('56561a4d36726b09833dffb839a905c185272f32', '196.65.169.61', 1692436195, '__ci_last_regenerate|i:1692436195;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('57b1f72b8f3136ff17c06d10e8d36fdd0639ec18', '196.206.77.183', 1692349258, '__ci_last_regenerate|i:1692349258;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('58b9c2ce641c6055e903ec16f1f65cde278d31e1', '197.253.220.42', 1692284108, '__ci_last_regenerate|i:1692284108;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('59ad632c11dc6458d6a50d7fafcfc5069622d432', '196.74.167.20', 1692098266, '__ci_last_regenerate|i:1692098266;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5a4d62d455f552dcbba38e9fc2ce51b255a69f5a', '196.74.145.227', 1692025399, '__ci_last_regenerate|i:1692025399;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5a548595fbfae87312c0d47b9ff2f812e0242b6d', '196.206.77.183', 1692346700, '__ci_last_regenerate|i:1692346700;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5bd11987722c2b41848a2f4a3dd941dc6bce3099', '196.74.158.189', 1692263415, '__ci_last_regenerate|i:1692263415;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5c2473f7453e4d82ef563c9d5105ca3167386a68', '196.74.158.189', 1692195814, '__ci_last_regenerate|i:1692195814;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5c709240871f81f71f913cd15607151be73b7d55', '196.74.158.189', 1692199375, '__ci_last_regenerate|i:1692199375;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5c96623b1cd51873403aea8c1ee4788d6c0fb6d7', '196.65.169.61', 1692357514, '__ci_last_regenerate|i:1692357514;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d12708d7d6938e4fd659acc0cf77779936ca8ab', '196.74.144.48', 1692611868, '__ci_last_regenerate|i:1692611868;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d39eafe802c564f5f7e442254b8fdf5517af53e', '160.179.56.31', 1692445826, '__ci_last_regenerate|i:1692445826;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d480009deb7ff087e125927d220ae117097eecb', '196.74.158.189', 1692265663, '__ci_last_regenerate|i:1692265663;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:29:\"Devis modifiée avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5de76008e83d7012df6c774122fde0cc94946b03', '196.65.169.61', 1692377523, '__ci_last_regenerate|i:1692377523;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5e73fe3864137665679895bc1ca918a0907c7ca0', '196.206.77.183', 1692350568, '__ci_last_regenerate|i:1692350568;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5f3cc5cf2ab7d6c9b65853c34e453ac3e0cc47a4', '196.74.145.227', 1692018910, '__ci_last_regenerate|i:1692018910;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5fbd499a1eeb7583ee998635b311288f77b28ad7', '105.157.138.175', 1692042168, '__ci_last_regenerate|i:1692042168;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5fc1da14488201806d90e595358c9bb20e03e3be', '196.74.167.20', 1692111659, '__ci_last_regenerate|i:1692111659;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6015006b56ea6230272057a0beb06c4c16b17f43', '196.74.158.189', 1692265080, '__ci_last_regenerate|i:1692265080;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6179ee7dcd696c9d49158fe7a1d830569ccd1b34', '196.74.151.235', 1692007258, '__ci_last_regenerate|i:1692007258;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6186353fda97b6b9ac6a690d8ffeb35445a7fbd6', '196.74.167.20', 1692103545, '__ci_last_regenerate|i:1692103545;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('62e0180ca0cab4e8ede707564618e3d2c1787c4c', '196.74.144.48', 1692606435, '__ci_last_regenerate|i:1692606435;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('638d784ce82f05bc8b84fc3dad7f99195448cb70', '196.65.169.61', 1692440333, '__ci_last_regenerate|i:1692440333;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('638e52cf30a651972770a18c02fb81c52695b3b3', '196.74.151.235', 1692009369, '__ci_last_regenerate|i:1692009369;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64578e21c6011bdee3e141326566021c4ef33e07', '196.206.77.183', 1692348935, '__ci_last_regenerate|i:1692348935;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('649a8d79c360eb858fcc2f10d6f05228a0a33345', '196.74.158.189', 1692268832, '__ci_last_regenerate|i:1692268832;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('64a0156c5a486733853cc48aeb4ca7225915e1c6', '196.74.158.189', 1692202116, '__ci_last_regenerate|i:1692202116;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('651b786bc31bde8feaf444845ace63c5e94c5b68', '196.74.167.20', 1692113835, '__ci_last_regenerate|i:1692113835;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('65b63acab21994b1278afecfd0355dd85714e236', '196.206.77.183', 1692284964, '__ci_last_regenerate|i:1692284964;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6603dc162083eeb5402e36322197bd748d6742a4', '196.74.158.189', 1692269303, '__ci_last_regenerate|i:1692269303;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6673b416bb6707602e3777b92507e1169a764b2b', '196.74.158.189', 1692263295, '__ci_last_regenerate|i:1692263295;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6675629662dc501c13c6fd57c67eb57a3f30a8e2', '196.65.169.61', 1692436174, '__ci_last_regenerate|i:1692436174;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67b291bc7d0ef795e407f18610ded3dd614e2efc', '196.74.167.20', 1692174114, '__ci_last_regenerate|i:1692174114;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67d01082483610c2cb27796d27e579d3957245a2', '196.74.158.189', 1692204432, '__ci_last_regenerate|i:1692204432;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67e0dd520d048a6dff05c89f2374051f655a8739', '196.74.145.227', 1692013888, '__ci_last_regenerate|i:1692013888;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67e8a0fa85044d2ce348331dc186f997d7e7aa85', '196.74.167.20', 1692106941, '__ci_last_regenerate|i:1692106941;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6886bdae4360aa488c4dacbf6bcc576e4ac31a81', '196.74.158.189', 1692184943, '__ci_last_regenerate|i:1692184943;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68ea64c83ce315a25d09d30a06fe1c3811791a37', '196.206.77.183', 1692285379, '__ci_last_regenerate|i:1692285379;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('690e2d557a00d0450a2ad982b3d133463baa424c', '196.74.144.48', 1692614425, '__ci_last_regenerate|i:1692614425;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('69592108a8ca98e53ad3c994359ee64f18643244', '196.74.145.227', 1692027958, '__ci_last_regenerate|i:1692027958;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6989902302ef2fdbc3a2d5c862829c9aecd15bc8', '196.65.169.61', 1692373269, '__ci_last_regenerate|i:1692373269;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6bae20977f1efd1fdad25ed3e4123edfbce933f0', '196.206.77.183', 1692287610, '__ci_last_regenerate|i:1692287610;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6c743b4d4fe82b5df65ecd4f27b42293a7b21e60', '196.74.144.48', 1692607236, '__ci_last_regenerate|i:1692607236;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6cc9d904bb2fe92cdd746c3d45dfeabcee4dda7a', '196.74.151.235', 1692003086, '__ci_last_regenerate|i:1692003086;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:29:\"Client modifié avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6e419a667498fea3010c467f5eac18b4a3ff62c7', '196.74.158.189', 1692262994, '__ci_last_regenerate|i:1692262994;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6e5ac645a2beb92ce0f03b085228d39fe7ef69af', '196.65.169.61', 1692435679, '__ci_last_regenerate|i:1692435679;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6e7d5494fadc226aa82273f76c3006318a096f7d', '160.179.56.31', 1692443480, '__ci_last_regenerate|i:1692443480;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6eefb491a57e018446a2dfea115e57d270a35236', '196.74.145.227', 1692090489, '__ci_last_regenerate|i:1692090489;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6fbf719994b7a3cb06b0e17df76c19ac63f26a15', '196.74.167.20', 1692180725, '__ci_last_regenerate|i:1692180725;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6ff6f9940c67ec63fe7303564f6a585696c72f33', '196.65.169.61', 1692374733, '__ci_last_regenerate|i:1692374733;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('70975f64e67a2b610867876676c5bda00c521fcf', '196.74.158.189', 1692193026, '__ci_last_regenerate|i:1692193026;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('70e0dd2a5bc914b4a2611b147b94721ea36a191a', '105.69.240.198', 1692001649, '__ci_last_regenerate|i:1692001649;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7167025b8792df11da1dedce4f74b2700c8db396', '196.74.158.189', 1692266405, '__ci_last_regenerate|i:1692266405;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('719368108cb2e01aad9ea6b6fc25edec75398551', '160.179.56.31', 1692442424, '__ci_last_regenerate|i:1692442424;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('71bd3d03e6b57e88fb5c42bf763aa1efbbb2422d', '196.74.151.235', 1692008013, '__ci_last_regenerate|i:1692008013;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('733a91ee8b73c3095e16e9e35aba6803e0b5619a', '196.65.169.61', 1692434557, '__ci_last_regenerate|i:1692434557;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('734cba83f42dff68beae914d398ca9634c003c2a', '196.74.158.189', 1692202467, '__ci_last_regenerate|i:1692202467;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7405cd760824b8344f7555652837b91eaf575a0a', '196.74.145.227', 1692013743, '__ci_last_regenerate|i:1692013743;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Produit enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('742e851617d8786ec2191c55eb33909eaf1d2345', '196.65.169.61', 1692374127, '__ci_last_regenerate|i:1692374127;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('74b8794a95c3a6a34ebc89f1dabfeb13c5ba7ccf', '196.74.158.189', 1692198439, '__ci_last_regenerate|i:1692198439;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('759ec59c3bfdb15338578e1c131d1a02ec2bfec7', '196.74.145.227', 1692092761, '__ci_last_regenerate|i:1692092761;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('75a576130e6985468d52595c4fe4ad5378cf30f4', '196.74.158.189', 1692266083, '__ci_last_regenerate|i:1692266083;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('75beb9cc58461a4c61b5f599e2cb3d9af6b5d3a6', '196.74.158.189', 1692201117, '__ci_last_regenerate|i:1692201117;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('760db36a8591a18c49ca07087474d98a30b73e49', '160.179.56.31', 1692444176, '__ci_last_regenerate|i:1692444176;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7634d6f97f4901e40d809ce0c1bf651921f97561', '196.74.144.48', 1692614525, '__ci_last_regenerate|i:1692614525;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('769bffd9e8e0c9e1f2ff1139d3b3c71005f1bb88', '196.74.144.48', 1692607962, '__ci_last_regenerate|i:1692607962;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('76a5e846cbfc2e3de7712bb3822c20b67d37afca', '196.74.158.189', 1692206306, '__ci_last_regenerate|i:1692206306;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7991679243fc16b394e495a26769b47972294b8f', '196.74.145.227', 1692019294, '__ci_last_regenerate|i:1692019294;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7994cbb1b53963ab5e60ebdb1b4e1c68126fe044', '196.206.77.183', 1692353595, '__ci_last_regenerate|i:1692353595;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('79d053c17b7206a2968f56f02140376e02161af5', '196.74.167.20', 1692182111, '__ci_last_regenerate|i:1692182111;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7a331cf30c651bb150fdb463db936b3cbf9add3e', '196.74.167.20', 1692177635, '__ci_last_regenerate|i:1692177635;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7af15fbae4247bc8bf292e12d151080afe81f69b', '105.157.143.32', 1692615530, '__ci_last_regenerate|i:1692615530;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7b1d19a975f1e2ff63739ab66661d4bf88b18be6', '160.179.56.31', 1692443820, '__ci_last_regenerate|i:1692443820;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7bb4375ea9003b736b4d7471419767b731240219', '196.65.169.61', 1692437226, '__ci_last_regenerate|i:1692437226;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7bd4bf6e1572fcacb698bd4bbc809342597b0597', '196.65.169.61', 1692376878, '__ci_last_regenerate|i:1692376878;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7c14583e97ec06ad8bd66b8a57a8a9028f27702a', '196.65.169.61', 1692441692, '__ci_last_regenerate|i:1692441692;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7c6d14f19b6266d932829f323b5b92b076391ade', '196.65.169.61', 1692358003, '__ci_last_regenerate|i:1692358003;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7cf6c81ed35acf12b778f5c90bddd0f7fda45cc6', '196.206.77.183', 1692350273, '__ci_last_regenerate|i:1692350273;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7f3df5f1eb849d61be8b21fe60988c096c371dd5', '196.74.158.189', 1692263908, '__ci_last_regenerate|i:1692263908;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7f732de96a289526723be454fd71a4270150b11f', '196.74.145.227', 1692028590, '__ci_last_regenerate|i:1692028590;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7fa4c738f5a9868596baa770c57c914bb108e251', '196.65.169.61', 1692437729, '__ci_last_regenerate|i:1692437729;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('802646b1e2192567e2e6d23cab514001164ea639', '196.65.169.61', 1692441211, '__ci_last_regenerate|i:1692441211;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80381edf909b2ea46da544ca913e437237228616', '196.206.77.183', 1692347632, '__ci_last_regenerate|i:1692347632;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('806db58a16d28b94a1c6e49b2046d9833c8f63c9', '196.74.144.48', 1692608269, '__ci_last_regenerate|i:1692608269;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('80e300cbc85e16a1fe999f52a96a3ecee56b9757', '196.65.169.61', 1692432939, '__ci_last_regenerate|i:1692432939;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('810073e51f2af7c31d085074b0b98b080a2f8fd6', '197.253.193.209', 1692370333, '__ci_last_regenerate|i:1692370333;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('81f3bca73e5a111ca118b1ac73d2af6a02bcad9c', '196.74.167.20', 1692181452, '__ci_last_regenerate|i:1692181452;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82b12265883e4409906e6ad96f9220709dcde419', '196.65.169.61', 1692376130, '__ci_last_regenerate|i:1692376130;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('836126b8668161648bead90991038bee31f13801', '196.74.145.227', 1692089403, '__ci_last_regenerate|i:1692089403;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('83619057f77276948debf2722d8ce06f7d7bb092', '196.74.167.20', 1692115431, '__ci_last_regenerate|i:1692115431;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:35:\"Transport enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('837165812d80b6928a28b5e533193ed2e13408d6', '196.74.145.227', 1692022760, '__ci_last_regenerate|i:1692022760;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('83cecf3807dfb9dd8d4189a20b9d8ae26e9d6d38', '196.74.158.189', 1692200990, '__ci_last_regenerate|i:1692200990;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8401470993932c3e6d48af29ae74c5e91bbf669b', '196.74.158.189', 1692267069, '__ci_last_regenerate|i:1692267069;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('84737f370f2782c7d5c498e822a1f636ae6e0c36', '196.74.167.20', 1692181110, '__ci_last_regenerate|i:1692181110;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('84c3bc3f4442e97061b87eb4d5d54540b2220abd', '105.69.240.198', 1691924358, '__ci_last_regenerate|i:1691924358;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('84e75af857cc7a8615ac0ba651192043d990d947', '196.74.158.189', 1692193997, '__ci_last_regenerate|i:1692193997;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('85b3ac9cf00f651c34d568dbc1930c26bcb5a410', '196.65.169.61', 1692440092, '__ci_last_regenerate|i:1692440092;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86293cbf1066f8db822498bf63bb8e96d4af6db5', '196.74.167.20', 1692180127, '__ci_last_regenerate|i:1692180127;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('870b1982df480c90157e1f1b9e5ca354026c5953', '196.74.145.227', 1692025088, '__ci_last_regenerate|i:1692025088;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8715cbdff82fa2cf9e8bed40c1a7432fd38aafd9', '196.65.169.61', 1692357686, '__ci_last_regenerate|i:1692357686;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('879781f6c91be2f22f5e598e177d6c33ba7ddbee', '196.65.169.61', 1692441076, '__ci_last_regenerate|i:1692441076;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:41:\"Produit endommagé modifié avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('87a58b70fabdc1097113325cd9e0a3a2911b750f', '197.253.253.185', 1692282929, '__ci_last_regenerate|i:1692282929;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('883953b7e1b2a664e5252950d0b4806178f84f07', '196.74.145.227', 1692017604, '__ci_last_regenerate|i:1692017604;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88413625a72abb9d6005d5ad5e1d2d82f2a45529', '196.65.169.61', 1692435251, '__ci_last_regenerate|i:1692435251;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88a96f3fed0c98813e0edeab8075d049ad4b50d9', '196.74.167.20', 1692178191, '__ci_last_regenerate|i:1692178191;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88ac6fb88837a5e8738dfb0274c650ccb27708b0', '196.65.169.61', 1692432594, '__ci_last_regenerate|i:1692432594;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88cc60840938909e715a38abceae6548f82d2e63', '196.74.158.189', 1692267712, '__ci_last_regenerate|i:1692267712;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('891d287666f72db39d9f5199106950a03181b540', '196.74.145.227', 1692027967, '__ci_last_regenerate|i:1692027967;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('89be0794aceb3fe725b97d67fce014258eccfcae', '196.74.167.20', 1692179460, '__ci_last_regenerate|i:1692179460;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('89e8bc911ab353e524a7aa89f0e854919b3f5885', '196.74.167.20', 1692177625, '__ci_last_regenerate|i:1692177625;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8a8a542e8e3646cf5163dd70cd05af5b7d36b68f', '196.74.145.227', 1692019738, '__ci_last_regenerate|i:1692019738;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Produit enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8b28dd6c60153d2526d98564be3816fff61b66cb', '196.74.158.189', 1692185252, '__ci_last_regenerate|i:1692185252;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8c14ebb29d736d9d58c1f9db4f4177369339cd6a', '196.74.145.227', 1692022086, '__ci_last_regenerate|i:1692022086;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ca6c16013723a1c04b281b0ff60a12b7d24a393', '196.65.169.61', 1692376762, '__ci_last_regenerate|i:1692376762;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8d41d8723633534cf235be44c1033798be0f3a63', '196.74.158.189', 1692193597, '__ci_last_regenerate|i:1692193597;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8e27f211525c8d002417675b7df203b48cc7ffb2', '196.74.144.48', 1692612684, '__ci_last_regenerate|i:1692612684;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8e874c8644f7247348d3ccbeade449b30c1c65db', '196.206.77.183', 1692355617, '__ci_last_regenerate|i:1692355617;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8eac1996ee3bc70fa7bbcb59ad9a3d4d51ea292b', '196.74.151.235', 1692007876, '__ci_last_regenerate|i:1692007876;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8f74ab9496a1b1ec5c60d4d793915dac4d3b6948', '196.74.158.189', 1692184131, '__ci_last_regenerate|i:1692184131;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8fab58912c634cd2ca92c14c205c7085e766287c', '196.74.167.20', 1692120160, '__ci_last_regenerate|i:1692120160;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8fd0e99e6b7d11c4019a44fd6a1dd3387a4dbb52', '196.74.144.48', 1692608880, '__ci_last_regenerate|i:1692608880;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8fdde3e7eb5e5338261259afc2c96ef2767c0359', '196.74.145.227', 1692024709, '__ci_last_regenerate|i:1692024709;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ff05cf0720af4ed42ba22f662ced999a48bf831', '196.74.167.20', 1692178964, '__ci_last_regenerate|i:1692178964;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('903ad8995f87012d74bf6cbeda6255ef6c07ae14', '196.74.158.189', 1692199672, '__ci_last_regenerate|i:1692199672;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('929e0c101b55080c4a0d0cd2b832e52d89beb52f', '196.74.158.189', 1692261956, '__ci_last_regenerate|i:1692261956;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93519002125100fdcb7f5d7f354a55d3e847fc09', '196.89.134.245', 1691923277, '__ci_last_regenerate|i:1691923277;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93fa95072d170409ce81d782ae4c46d09efb9ff3', '196.65.169.61', 1692365797, '__ci_last_regenerate|i:1692365797;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('95535594f050440d3ec2000d62a7c67de3afdc65', '196.74.145.227', 1692030341, '__ci_last_regenerate|i:1692030341;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('95e67b105967be31578fd37b6e5661f098c2dfb7', '196.65.169.61', 1692438636, '__ci_last_regenerate|i:1692438636;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('96313ef466f9b996c9c8d0a542f902d36e7f0b17', '196.74.145.227', 1692022797, '__ci_last_regenerate|i:1692022797;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9673ba831fd99ce6337ed5a4c9d90846ca8700b5', '196.206.77.183', 1692349909, '__ci_last_regenerate|i:1692349909;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('96a51011576f0eb545cc0f3ead5c2ee448c2d58e', '196.206.77.183', 1692270201, '__ci_last_regenerate|i:1692270201;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('971e30e8131fda5e7d4b6ccd1caa5303fc4f09aa', '196.74.158.189', 1692192724, '__ci_last_regenerate|i:1692192724;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('97370c91a34d71ed534ff600ad7447338b0f7327', '196.74.158.189', 1692261167, '__ci_last_regenerate|i:1692261167;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('982c2ea7b6139e31e94fdc0e4039987ffa4faed2', '196.89.134.245', 1691841253, '__ci_last_regenerate|i:1691841253;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 12:49\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('98bbdf0406ce978bb80a09658e5427f19676e5bb', '196.74.151.235', 1692003534, '__ci_last_regenerate|i:1692003534;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('98d82d1c69fb7b7cf05eb818ca88543aa32d911b', '196.74.167.20', 1692110478, '__ci_last_regenerate|i:1692110478;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9a846902f16acb2cb22ad8a2b02828f40ee279be', '196.74.158.189', 1692260820, '__ci_last_regenerate|i:1692260820;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9baefe494423f317e4cd5af98f635dfb38604d76', '196.74.145.227', 1692089774, '__ci_last_regenerate|i:1692089774;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bfe505cd0ba71f1a613492da635f1600ca60d51', '196.74.145.227', 1692028756, '__ci_last_regenerate|i:1692028756;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c39be96ceca11bf89fb39a2e9f8354ade1cf754', '196.206.77.183', 1692280573, '__ci_last_regenerate|i:1692280573;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9cd7a68aaeac80db1c96266b9b6e0529dfe57f1f', '196.74.144.48', 1692610388, '__ci_last_regenerate|i:1692610388;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9d783644466ee315fa78191ac1327f2d3ce79737', '196.65.169.61', 1692358631, '__ci_last_regenerate|i:1692358631;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9e003b78a92e2717c1758a6b6b5e1d963d342a78', '196.74.144.48', 1692609919, '__ci_last_regenerate|i:1692609919;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9e40eefb5ed276d66ad9208f366885fa8b315206', '196.74.145.227', 1692088594, '__ci_last_regenerate|i:1692088594;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9f1976fe1536465997cd446e5471b242c66e6aa3', '196.74.145.227', 1692019408, '__ci_last_regenerate|i:1692019408;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9f1e716e2c96e31d587a7af278d87d8235ab94cd', '160.179.56.31', 1692444518, '__ci_last_regenerate|i:1692444518;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9f440febeebeddb87b8171faaa69b745bb41533e', '197.253.193.209', 1692367045, '__ci_last_regenerate|i:1692367045;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9f5ce681081cd620b83feeabc37228996a55f7cd', '196.74.145.227', 1692020635, '__ci_last_regenerate|i:1692020635;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9f7bea5e32a412bb60ee9e57c0317d44efbdf851', '196.74.158.189', 1692203469, '__ci_last_regenerate|i:1692203469;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:29:\"Facture créée avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9f950d9134225f88bb24b7db69d777e054629fdb', '196.74.145.227', 1692017065, '__ci_last_regenerate|i:1692017065;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a00030cf8362e1a019738b191c8252a5c98ccdac', '105.157.143.32', 1692615949, '__ci_last_regenerate|i:1692615837;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a09229e86effce734cd39db736a4d7e0693997e2', '196.74.145.227', 1692031291, '__ci_last_regenerate|i:1692031291;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0cc140efdf52a3a502eb1cd8aaac188a821e924', '196.65.169.61', 1692439782, '__ci_last_regenerate|i:1692439782;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a10a00e0d87cebdcc543370a1c86ad6de5f0dc00', '196.65.169.61', 1692438042, '__ci_last_regenerate|i:1692438042;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a297ff1230c02b1fc7217da438c41d0ba0e71cdf', '196.74.145.227', 1692031370, '__ci_last_regenerate|i:1692031370;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3236ac3b99f16d147fe3404c54c8f44ca51a252', '196.74.144.48', 1692615151, '__ci_last_regenerate|i:1692615151;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3636784c4656a570b64ef9e248675cd8bbfb79a', '196.74.167.20', 1692104008, '__ci_last_regenerate|i:1692104008;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a49463766d2e8b46b4a619b2a94c3676a443cdc1', '196.74.145.227', 1692011187, '__ci_last_regenerate|i:1692011187;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a5de60df0f508c5336f0f9cbf06271e8d9c7cfb9', '196.74.158.189', 1692194320, '__ci_last_regenerate|i:1692194320;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a742cdf4e3061e2a04d6034d45a83b04342903fb', '105.157.143.32', 1692615619, '__ci_last_regenerate|i:1692615619;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a7512210ce1e1c494d3bcd38e7e2008a2528edad', '196.65.169.61', 1692435349, '__ci_last_regenerate|i:1692435349;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a7b658a6f4d25e9433d79af4d8e20d1b63adb1b8', '196.74.158.189', 1692263772, '__ci_last_regenerate|i:1692263772;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a7cc6753579039531615c5e075535213ccab6247', '196.206.77.183', 1692269904, '__ci_last_regenerate|i:1692269904;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a7de53deb648f9d597128e456b2d59d9e6b28344', '196.74.158.189', 1692204107, '__ci_last_regenerate|i:1692204107;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a827571131ee387b1169282131f55fde4fd3bf0b', '196.65.169.61', 1692370645, '__ci_last_regenerate|i:1692370645;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a84d323ce3adbc83325451c03fa773d2dd4a6be1', '196.74.144.48', 1692610702, '__ci_last_regenerate|i:1692610702;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a8d2c3f5414928af10c32b06906deabe23163407', '196.74.158.189', 1692266368, '__ci_last_regenerate|i:1692266368;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a97eef86553e559210d67c19d373cb72ac8712b3', '196.74.158.189', 1692266755, '__ci_last_regenerate|i:1692266755;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa20de8126d51cb8d90c2643159f83ea80608b47', '196.65.169.61', 1692376417, '__ci_last_regenerate|i:1692376417;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa252c82d4adb895752760be4ba652ad334b4db8', '196.74.158.189', 1692267991, '__ci_last_regenerate|i:1692267991;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa6eb922f1a9d259d524d8f31922fa1d355a00a9', '160.179.56.31', 1692444905, '__ci_last_regenerate|i:1692444905;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aaa170b4bc3b7690f4c168835aee726e1b3e8ce7', '196.74.167.20', 1692175795, '__ci_last_regenerate|i:1692175795;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ac78df3cfaca7f029a6d7715bea6462c5671c185', '196.74.144.48', 1692614826, '__ci_last_regenerate|i:1692614826;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('acf6d381860df5472804b985075e6d458ceb3cae', '196.74.145.227', 1692033104, '__ci_last_regenerate|i:1692033104;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('addc1fe6fb294203ba70c16ff5ec02b0cd35c791', '196.206.77.183', 1692347303, '__ci_last_regenerate|i:1692347303;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ae71b06de85b67ca4624364a16d119f6376a9d8b', '196.74.145.227', 1692029544, '__ci_last_regenerate|i:1692029544;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ae96ebf5138e24dd5ed640a096f79e1ec96217dd', '196.206.77.183', 1692348300, '__ci_last_regenerate|i:1692348300;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aea9aeca277e4994dee9c484f95eb4716977ec33', '196.74.158.189', 1692194640, '__ci_last_regenerate|i:1692194640;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aec64911a6420277696bfc23175705faf7baca8d', '196.74.158.189', 1692200147, '__ci_last_regenerate|i:1692200147;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('af282763aaafa0bc9819c3101c1e73f808250e7c', '196.74.158.189', 1692264776, '__ci_last_regenerate|i:1692264776;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b08a84c069ed213f804485180ee80fa6d1338f2a', '105.69.240.198', 1692001698, '__ci_last_regenerate|i:1692001698;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b1aaebc3a51cb3536769c1e9f4c7d3d350ef6907', '196.74.145.227', 1692029755, '__ci_last_regenerate|i:1692029755;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b218401f34ebd0ba8e01b2e5202aa12911c7b564', '196.74.144.48', 1692610132, '__ci_last_regenerate|i:1692610132;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b26ebfde461f80c7df9d10ce38b3a43f01cd8971', '196.74.158.189', 1692206709, '__ci_last_regenerate|i:1692206709;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b2b2adabb492120e0aecd5d91b15a3a4d6addfaa', '196.65.169.61', 1692433034, '__ci_last_regenerate|i:1692433034;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b2fd6b84fbae83d0a8026244640d5dc5b1fb3635', '196.74.145.227', 1692032236, '__ci_last_regenerate|i:1692032236;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b3a6e826be3ee7ccb5a81c0fec420bdddac13323', '196.74.158.189', 1692198274, '__ci_last_regenerate|i:1692198274;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b421d575b71ba3c5438520f2fda9b4dc46c15c2c', '196.74.151.235', 1692007697, '__ci_last_regenerate|i:1692007697;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b44525b220d08c696b16d6653f0ac7f69e641046', '196.74.151.235', 1692002916, '__ci_last_regenerate|i:1692002916;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Produit enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b55fe1eab6f9c4ce5e4d69737abdffd871d62716', '196.65.169.61', 1692365821, '__ci_last_regenerate|i:1692365821;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b63beac4e13d337b1fc99eed1f13dd40105aa79e', '196.74.158.189', 1692206408, '__ci_last_regenerate|i:1692206408;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b64b6c2382cc0620f3d348b97d356da172a620dd', '196.206.77.183', 1692354658, '__ci_last_regenerate|i:1692354658;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b66abc80a1221cac942796fb6b6face7322c5e8d', '196.206.77.183', 1692351642, '__ci_last_regenerate|i:1692351642;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b6cf5ab2b863ea81d1f831c7b041b6158e06b9f7', '196.74.158.189', 1692265302, '__ci_last_regenerate|i:1692265302;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b6d021712bdf41c2039da84fb4744c6348ee8408', '196.65.169.61', 1692434513, '__ci_last_regenerate|i:1692434513;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b6d1d078d683ca043511e6ac05bbaef0461afb51', '196.74.145.227', 1692019633, '__ci_last_regenerate|i:1692019633;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b6e65bf40642278f84bd72568149fb8bb35e0d79', '196.74.167.20', 1692178509, '__ci_last_regenerate|i:1692178509;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b72e9b2f5a7c95cecd5e7d061a8f5a71ec4a119f', '196.74.151.235', 1692009976, '__ci_last_regenerate|i:1692009976;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b73006310306ac621bb5019ec30f6eb397d5c6b2', '196.65.169.61', 1692377615, '__ci_last_regenerate|i:1692377615;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b7a0f12cd483807c856375801486fb1240119c26', '196.74.145.227', 1692096019, '__ci_last_regenerate|i:1692096019;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b7d7313d4eb440ecfca53c4fc075687e224882ab', '196.65.169.61', 1692375677, '__ci_last_regenerate|i:1692375520;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"18/08/2023 17:19\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b7f4a9c3e03cc952fa96038430f0bbda41df7df5', '196.74.167.20', 1692178876, '__ci_last_regenerate|i:1692178876;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b8534fc0c3879e60c539af3409d7a220ccab8610', '196.74.151.235', 1692006316, '__ci_last_regenerate|i:1692006316;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b981648ebbb5bb538a61cc838a8c577b142df553', '196.206.77.183', 1692284553, '__ci_last_regenerate|i:1692284553;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba43a2b981df86c5cde3bd9671b58df9f205dd94', '196.74.145.227', 1692018987, '__ci_last_regenerate|i:1692018987;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba627081fb91de443f0b70fbdae00a92d106ace2', '196.65.169.61', 1692434879, '__ci_last_regenerate|i:1692434879;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba901d4c19061d4c3bec40dadac176821cf3c55f', '196.74.145.227', 1692023123, '__ci_last_regenerate|i:1692023123;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('babb32821f33aaa7177c3c57623a8e4f8f7cb241', '196.74.145.227', 1692025181, '__ci_last_regenerate|i:1692025181;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bae743d91e2b04c17cb7d40c3bf14a5e724869e3', '196.206.77.183', 1692279113, '__ci_last_regenerate|i:1692279113;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bb47686772b977cf5303384dfa13c53e735a2243', '196.206.77.183', 1692353751, '__ci_last_regenerate|i:1692353751;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bb6422c5cec84954d53158442149c48e2976494b', '196.206.77.183', 1692352882, '__ci_last_regenerate|i:1692352882;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bb8b86396a85841074f0e1603a901e720e6bfb1e', '196.74.144.48', 1692607737, '__ci_last_regenerate|i:1692607737;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbcfa33ae4752a4683c85a9774b257f8e4801e9a', '196.74.145.227', 1692033861, '__ci_last_regenerate|i:1692033861;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bcd77f540a6e2e2b043f56f29a0e1fb2b23da290', '196.74.167.20', 1692111335, '__ci_last_regenerate|i:1692111335;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bd7cd43331c975fc9452d5e11187d14d17330829', '196.74.167.20', 1692116531, '__ci_last_regenerate|i:1692116531;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bd8c07cb7b3ed9647fb907cbe0a45aa5b4ed6acd', '196.74.167.20', 1692173808, '__ci_last_regenerate|i:1692173808;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bdb5b7f236ad2945637a6770b7266d7140b9250f', '196.206.77.183', 1692286789, '__ci_last_regenerate|i:1692286789;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('be6cc2489bb90714c3c8cfa387aadd9bee9b6074', '196.74.145.227', 1692012905, '__ci_last_regenerate|i:1692012905;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bf78fed42c22c1d2c2f2c3d4e2b724eb23652f75', '196.74.167.20', 1692176298, '__ci_last_regenerate|i:1692176298;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bf9ca8c565ae6c0b57e63d2b6f63c853c0a3cdfc', '196.74.145.227', 1692031764, '__ci_last_regenerate|i:1692031764;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c019f2c7ac5f42f37373cb2233d0db90c176e512', '196.74.167.20', 1692175491, '__ci_last_regenerate|i:1692175491;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c05357288e2eb634503e7353427204f06ba38f68', '196.74.167.20', 1692176689, '__ci_last_regenerate|i:1692176689;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c05e072830b49ce4e1780353bbd01a17b4df5565', '196.74.158.189', 1692195491, '__ci_last_regenerate|i:1692195491;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c06981e7c89f7ca9161d181b87cf3d57b3dc3bf6', '196.74.151.235', 1692007144, '__ci_last_regenerate|i:1692007144;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c08abe741713ad53e7fdaabcf48368fed740c9d1', '196.74.151.235', 1692004106, '__ci_last_regenerate|i:1692004106;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c09487c388f6db7fb79339b7f91aba853bf9322a', '196.206.77.183', 1692353396, '__ci_last_regenerate|i:1692353396;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c11232aa3327157d665eeb4c334297f0171a7100', '196.74.145.227', 1692011129, '__ci_last_regenerate|i:1692011129;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c11ac5c095731c40196ff448279612d0125d9ed3', '196.74.158.189', 1692269277, '__ci_last_regenerate|i:1692269277;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c1331eb720e574c19f1c7c20ac0824b33d782428', '196.74.167.20', 1692101873, '__ci_last_regenerate|i:1692101873;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c15856f76fda50be93a63326dc7d08c24177da29', '196.74.145.227', 1692010825, '__ci_last_regenerate|i:1692010825;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Produit enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c1d523fff9f37d312ea98cb3e75a987dfa8d47cf', '196.74.158.189', 1692260197, '__ci_last_regenerate|i:1692260197;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c23cd1cdfe6b5ee3bf2d51b98aa73a6034b1ebf5', '196.65.169.61', 1692439878, '__ci_last_regenerate|i:1692439878;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c33136d176603e3002cb9bd9d8786ca40554fe5f', '196.74.144.48', 1692610886, '__ci_last_regenerate|i:1692610886;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c5631e49b04754ba18bdd823cb580c2ce98785f9', '196.74.167.20', 1692107857, '__ci_last_regenerate|i:1692107857;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c7097ae009d3a33d47a156a34ebeaf38357f8358', '196.206.77.183', 1692287101, '__ci_last_regenerate|i:1692287101;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c7905e3f920d2ab972b9b04467b432bb86230f8a', '196.206.77.183', 1692349580, '__ci_last_regenerate|i:1692349580;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c84d00fc1796292e549d4de3c5de733a4e84c41d', '196.74.144.48', 1692613215, '__ci_last_regenerate|i:1692613215;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c855bd567c513db448a9be4f2e0374bfa3d86e38', '196.74.158.189', 1692196972, '__ci_last_regenerate|i:1692196972;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c8ba07059a2e3568f7b1eeb2e12bfa78dbf4eaee', '105.157.143.32', 1692615921, '__ci_last_regenerate|i:1692615921;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c96595c517bb258e2503a9d1e2fa3290cce6e294', '196.74.145.227', 1692027644, '__ci_last_regenerate|i:1692027644;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c9e2d3626cc85090154c91577a4d9976550b4254', '196.74.158.189', 1692198729, '__ci_last_regenerate|i:1692198729;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ca6fcc84b624f5e3cd736c7c4b97995172b8c27a', '196.206.77.183', 1692355757, '__ci_last_regenerate|i:1692355757;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ca85e79696bf6dfb5b9a836005f5f4ceb502774c', '196.74.158.189', 1692268013, '__ci_last_regenerate|i:1692268013;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cab0b0d26a810a2388051b44c6851e20825446c3', '196.74.145.227', 1692088938, '__ci_last_regenerate|i:1692088938;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cbfcbb5e9fbe424a00e7aab03735111f6cb27b57', '196.74.167.20', 1692109797, '__ci_last_regenerate|i:1692109797;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:35:\"Transport enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cce216346340201d950f3079d419557c2bbf28a9', '196.74.144.48', 1692615227, '__ci_last_regenerate|i:1692615227;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cd54c11a777d1875a2969c9352657cbb9d976532', '196.65.169.61', 1692433954, '__ci_last_regenerate|i:1692433954;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cdfa5c14ab20fb14857934f2d547f6af4d41eb38', '196.74.167.20', 1692182722, '__ci_last_regenerate|i:1692182722;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ce2420b827fdd1047d9934593e76c64de290e577', '196.74.158.189', 1692183156, '__ci_last_regenerate|i:1692183156;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ce3c4a8cd1399924df8a12ac748a2b77c504f2ab', '196.74.158.189', 1692183757, '__ci_last_regenerate|i:1692183757;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cecd04983a6229c45f87726f559d1d93d6594b7a', '196.74.145.227', 1692029241, '__ci_last_regenerate|i:1692029241;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cf82ba771c5c1e0e925078af51a7b3b12a1145a4', '196.74.144.48', 1692612380, '__ci_last_regenerate|i:1692612380;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d010c314d927659f54278711b5f796904f378672', '196.74.167.20', 1692177948, '__ci_last_regenerate|i:1692177948;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d01aaca1934c9d3f2478a97219220af0ca88dce9', '196.65.169.61', 1692439529, '__ci_last_regenerate|i:1692439529;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d09d6d90c842bb9600422b4da3a5bb4b246fd2c3', '196.74.145.227', 1692018125, '__ci_last_regenerate|i:1692018125;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0ab4dd7e14a9faacc26b775c4c081e7afe04421', '196.74.145.227', 1692093689, '__ci_last_regenerate|i:1692093689;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0cd59d42495b90f01340f32cb3ccce2bcc5d014', '196.74.158.189', 1692197668, '__ci_last_regenerate|i:1692197668;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d14f75611a241786aad44cf1f6c474808090e7d8', '196.74.145.227', 1692097160, '__ci_last_regenerate|i:1692097160;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d16b9fff1a28258886f276dfb0fe034fab26c041', '196.74.158.189', 1692261559, '__ci_last_regenerate|i:1692261559;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d190a82865db66e2c24007ad4910252464e0e147', '196.206.77.183', 1692285680, '__ci_last_regenerate|i:1692285680;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d191eac12934045bea4289cac83a9679a4a95dc3', '196.74.158.189', 1692196673, '__ci_last_regenerate|i:1692196673;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d1b5d4529001fb12229324bc8f6aa99ad50c4ac0', '196.74.145.227', 1692021567, '__ci_last_regenerate|i:1692021567;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d24121bae2861b9f57840713e163cfc8d79ae675', '196.65.169.61', 1692356066, '__ci_last_regenerate|i:1692356066;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d246f649dbfe359b51283207120b2b85178f5505', '196.74.151.235', 1692001960, '__ci_last_regenerate|i:1692001960;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Catégorie modifié avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d2931ef10c4dfa2dc4d9e10c197923f7259aec57', '196.74.151.235', 1692008766, '__ci_last_regenerate|i:1692008766;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d29ebf3318f77ae50c1c86236784cf2d31ed53a6', '196.74.158.189', 1692197315, '__ci_last_regenerate|i:1692197315;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d2bf7ff1a7412c9d2535a0a9a7760af17b62257b', '196.74.144.48', 1692609717, '__ci_last_regenerate|i:1692609717;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d2cd6af8012c6392047cec3b000fc0adb08ec248', '196.74.145.227', 1692026796, '__ci_last_regenerate|i:1692026796;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d435ecaab6e52bf6875e5e774ff90f321434cac4', '196.65.169.61', 1692372693, '__ci_last_regenerate|i:1692372693;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d476a84f2774ebb1e484bfd03a2850aad3679203', '196.74.145.227', 1692021201, '__ci_last_regenerate|i:1692021201;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d4b2913ee95749b5d7d23d6d310f8e8db833ed93', '196.206.77.183', 1692347352, '__ci_last_regenerate|i:1692347352;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d51c406e39586862078871274a60117a66a2c528', '196.74.167.20', 1692109417, '__ci_last_regenerate|i:1692109417;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:35:\"Transport enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5b914d15cf16bbfa5d4020e9100782113aeb940', '196.74.158.189', 1692195792, '__ci_last_regenerate|i:1692195792;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5bc5a4a2dc4d521713c1e98a5c11cf77bef7e8d', '196.206.77.183', 1692348877, '__ci_last_regenerate|i:1692348877;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d6a05ce59eec8f7ebf5ca548469285fdd611bd38', '196.65.169.61', 1692441938, '__ci_last_regenerate|i:1692441938;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d6c638697543b3da074726f8ed171ff25220062c', '196.74.167.20', 1692120504, '__ci_last_regenerate|i:1692120504;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d733673d04b3c4b40f54c64e4cbb321b8d4a98f2', '196.206.77.183', 1692287975, '__ci_last_regenerate|i:1692287975;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d74e91e2137d0165b46255bb8b01f662accdd3f3', '196.74.158.189', 1692261773, '__ci_last_regenerate|i:1692261773;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d75dc0cb43451d2637b9d117a73ae1732085a0c9', '196.74.158.189', 1692264149, '__ci_last_regenerate|i:1692264149;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d7a5c36276b26067ec74ebcbb0bf43a37399accf', '196.74.158.189', 1692260713, '__ci_last_regenerate|i:1692260713;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d7fc31fe1e89f5f82cc43f6cb5eaffdcd511906e', '196.74.145.227', 1692026146, '__ci_last_regenerate|i:1692026146;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d8ab2dd36a6b76826963270ebcff8222fa52be60', '196.65.169.61', 1692377306, '__ci_last_regenerate|i:1692377306;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d8b5211ad1b970f37f02db52206810136725a307', '196.74.144.48', 1692611490, '__ci_last_regenerate|i:1692611490;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d946bd97c62752a7ab38ed3557f6f4e12694fb7e', '196.65.169.61', 1692440621, '__ci_last_regenerate|i:1692440621;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d9a82e90b32b69ba0cda85980f39725b8d0545eb', '196.206.77.183', 1692270305, '__ci_last_regenerate|i:1692270305;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d9c3f388c73534f3751d5a7c7a85d915d5be53ad', '105.157.143.32', 1692615948, '__ci_last_regenerate|i:1692615921;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da2a5ad233fb3fce3d1910cd653c4a8b481c8d24', '196.74.144.48', 1692614779, '__ci_last_regenerate|i:1692614779;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da5131558f3df6781f9cb3bf789c1b39f2453dc4', '196.74.158.189', 1692202954, '__ci_last_regenerate|i:1692202954;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da6ab5821ea9c0986ffef3e4c5f7fa73f3b5aa78', '196.74.167.20', 1692176171, '__ci_last_regenerate|i:1692176171;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('da7d4e3722d904ed773a1a0436e075e596f6fe63', '196.74.145.227', 1692018134, '__ci_last_regenerate|i:1692018134;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('daca870cbc4ff79ed2a495a05659bb592fc21993', '196.74.144.48', 1692612528, '__ci_last_regenerate|i:1692612528;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db4a2e3c18d7ba08dd646e30ed2f9eb00d44b9ee', '196.74.145.227', 1692012467, '__ci_last_regenerate|i:1692012467;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db4f6436f2dc9ad4ef531a4ad6d1af7c1c7ccd8c', '196.74.144.48', 1692609219, '__ci_last_regenerate|i:1692609219;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db6c669b15b5b572199fe4138be5e46e20ff7bc9', '196.206.77.183', 1692280425, '__ci_last_regenerate|i:1692280425;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dbdd05891134f1a8e7034d76a8951f65ba55a83e', '196.65.169.61', 1692373343, '__ci_last_regenerate|i:1692373343;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc076151fa7df38ef1f851d105ba47e6fd2ec32b', '196.74.151.235', 1692008294, '__ci_last_regenerate|i:1692008294;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc0cb8d475fe8d4c5c8389c0f8cf9974b91e5c19', '196.74.145.227', 1692090896, '__ci_last_regenerate|i:1692090896;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc5764039e63cb6cb9cbd00a60a6615a994c1f55', '196.206.77.183', 1692289621, '__ci_last_regenerate|i:1692289621;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dd111d58b68ff418f57361f8d5c57ff52e03d48c', '160.179.56.31', 1692445826, '__ci_last_regenerate|i:1692445826;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dd63594de4347e5627c4b50d9f239499faf42cbe', '105.69.222.57', 1692566495, '__ci_last_regenerate|i:1692566495;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dd85590bbf736559e99dd9585ab20fe93fe7d12f', '196.74.144.48', 1692612021, '__ci_last_regenerate|i:1692612021;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ddce88a4a602f3d68d8d022317f429a13d8b3e0a', '196.74.167.20', 1692097462, '__ci_last_regenerate|i:1692097462;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ddcf45eb3af53551d14aa7236881c00a1526807a', '196.74.145.227', 1692030289, '__ci_last_regenerate|i:1692030289;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";form_data|a:0:{}__ci_vars|a:1:{s:9:\"form_data\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ddde249d2d5889d2ccc360dc1c68286f937693f9', '196.74.145.227', 1692012588, '__ci_last_regenerate|i:1692012588;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Produit enregistré avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ddff964421d346e0584fa7bfd6c96b688308b099', '196.74.158.189', 1692201946, '__ci_last_regenerate|i:1692201946;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:29:\"Facture créée avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('de19a5274cdd6c12346b84ab23bfd2ec44173224', '196.74.145.227', 1692095166, '__ci_last_regenerate|i:1692095166;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('de97fe23b08a2979b2d6051bc561468a5c51cfbf', '196.206.77.183', 1692351081, '__ci_last_regenerate|i:1692351081;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('decc739670cd8819f78d2d2c798db5a9a68312c4', '197.253.249.133', 1692370139, '__ci_last_regenerate|i:1692370139;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dee34cacf9b8b475beb38d8223d93a61c0ccd851', '196.74.151.235', 1692010029, '__ci_last_regenerate|i:1692010029;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('df47bd88df2462f63e29e41857a34677625b83ef', '196.74.158.189', 1692201492, '__ci_last_regenerate|i:1692201492;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('df93c7d082e9f04592e9c08bc14274ad871a5f13', '196.65.169.61', 1692358322, '__ci_last_regenerate|i:1692358322;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfb7fd1d8ae758638157dc81c105addf0b2426f5', '196.74.145.227', 1692027239, '__ci_last_regenerate|i:1692027239;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfdf7655c9988705444fe394f12077093434ea72', '196.74.145.227', 1692017668, '__ci_last_regenerate|i:1692017668;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfee52619bfcac5f0229249ffef1706637dad934', '196.74.144.48', 1692609608, '__ci_last_regenerate|i:1692609608;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e07c7d087bfb09c99300d946abc26279ce1ae0e6', '196.74.145.227', 1692020384, '__ci_last_regenerate|i:1692020384;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0874211e90771f59c8c3e969d214d15cb237e2b', '196.65.169.61', 1692439019, '__ci_last_regenerate|i:1692439019;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e18200ac39077517f9927480efa6cc57892b647f', '196.65.169.61', 1692371262, '__ci_last_regenerate|i:1692371262;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e18e754b736dfcadbad97f8b3437686cba6b6b51', '196.74.145.227', 1692025844, '__ci_last_regenerate|i:1692025844;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e1d890d66200bb2189e9c4e120ef84ed935945dd', '196.74.145.227', 1692091255, '__ci_last_regenerate|i:1692091255;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e24dd474a06e9ef243ec08eb3ff2d4f07b87a229', '196.206.77.183', 1692354076, '__ci_last_regenerate|i:1692354076;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e395501695f87ca02e95e29608703ae1798f2f91', '196.74.167.20', 1692118128, '__ci_last_regenerate|i:1692118128;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e3ee75295533999b46c12ef44188c8bb62a9588f', '196.65.169.61', 1692375366, '__ci_last_regenerate|i:1692375366;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e451109e829f8b63c3f61184c27a7e60d170b34d', '196.206.77.183', 1692347935, '__ci_last_regenerate|i:1692347935;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e46457e950ebddd1d02aebe2596ed572c5d3d493', '196.74.144.48', 1692613007, '__ci_last_regenerate|i:1692613007;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e497bfc381618ce5e209fcfe4175f6d86a6485d2', '196.74.144.48', 1692612170, '__ci_last_regenerate|i:1692612170;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"21/08/2023 09:21\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e54f73c239ef0af57aabe90f49b4f4262b0de41c', '196.74.158.189', 1692196621, '__ci_last_regenerate|i:1692196621;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e573da85765a8680f5bf61dfea27d1d158c9e1e8', '196.206.77.183', 1692351196, '__ci_last_regenerate|i:1692351196;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7bbb751ccae913c3c7b0d0c393d08c07ec14534', '196.74.151.235', 1692004155, '__ci_last_regenerate|i:1692004155;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7cc11e804a4a7c702c97ac308d17110e6024af9', '196.74.145.227', 1692014778, '__ci_last_regenerate|i:1692014778;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7e3add2f60f38c3e68b5309e8df9d24d9c3cf88', '196.74.151.235', 1692002042, '__ci_last_regenerate|i:1692002042;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:29\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e8abb66e81179c4f2d99de2af58c5cf6474e8f26', '196.65.169.61', 1692375193, '__ci_last_regenerate|i:1692375193;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e8e8140053bf680feb46dafc8fea919421fec41d', '196.74.151.235', 1692003387, '__ci_last_regenerate|i:1692003387;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e90a22388c7eeef8fce8d7d0d495e17056e1c3e3', '196.74.145.227', 1692022253, '__ci_last_regenerate|i:1692022253;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e9a830a12c094f2aa043a20244444c9a3eb9e840', '196.74.158.189', 1692206094, '__ci_last_regenerate|i:1692206094;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eac1c7db836f80f281fb97a31bb72aeccb9bedb1', '196.206.77.183', 1692352133, '__ci_last_regenerate|i:1692352133;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eae2cfc5c5b8ab9e808bb3fb7a725eac62487293', '196.74.158.189', 1692260390, '__ci_last_regenerate|i:1692260390;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb157bccaa330c8a2573945aafead99569c47634', '196.74.158.189', 1692268546, '__ci_last_regenerate|i:1692268546;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb9d3e4a1b1a9acd19856de48eeccd61ce867376', '196.206.77.183', 1692352524, '__ci_last_regenerate|i:1692352524;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ebc44edb9d1689a80617189a2fce480e6594d94c', '196.206.77.183', 1692349251, '__ci_last_regenerate|i:1692349251;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ec2530e938f3c26218cc7f908228281bc4480ad5', '196.65.169.61', 1692439305, '__ci_last_regenerate|i:1692439305;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eca5d435abd995472b05c045256ca8bfb273592a', '196.65.169.61', 1692374889, '__ci_last_regenerate|i:1692374889;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ed56cae364f86ce6c9e556b87e708d00d416ac55', '196.65.169.61', 1692438960, '__ci_last_regenerate|i:1692438960;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ed666eec8d7870ceb411c81cffcdcd3af7231749', '196.206.77.183', 1692352561, '__ci_last_regenerate|i:1692352561;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ee94b175a75f8952f0cf17a4f2633a36a41d9552', '196.74.145.227', 1692032802, '__ci_last_regenerate|i:1692032802;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eec27cf7b4b0ad6dad7ed44df8d1dfcb4ec89c0d', '196.74.158.189', 1692196114, '__ci_last_regenerate|i:1692196114;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f07436ec82fb60ddcef70cec492920a53a10eaea', '196.74.167.20', 1692119008, '__ci_last_regenerate|i:1692119008;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0817273a934b337ee45004bba819fe93fc62691', '196.74.145.227', 1692028289, '__ci_last_regenerate|i:1692028289;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f121d5732d8699e978634a3431b1b0089c6376a3', '105.69.222.57', 1692547941, '__ci_last_regenerate|i:1692547941;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"20/08/2023 17:03\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f1802305ae92a360c76614babd2bb40539d41a03', '196.74.167.20', 1692179857, '__ci_last_regenerate|i:1692179857;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f23e8eb848534fad6fc9bcb0d212fc75d0995379', '196.65.169.61', 1692436863, '__ci_last_regenerate|i:1692436863;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f2ef3bc6630e297ceca0de2d6285ff96478641e1', '196.65.169.61', 1692371446, '__ci_last_regenerate|i:1692371446;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f2ef8882442846f09989abe4983e436cbc809521', '196.206.77.183', 1692353248, '__ci_last_regenerate|i:1692353248;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3024e93bdc5e52d7a346682223db410c070c48e', '196.74.151.235', 1692009179, '__ci_last_regenerate|i:1692009179;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f378942aaaefa3e759f91be35d904e243301b37f', '196.74.167.20', 1692181781, '__ci_last_regenerate|i:1692181781;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3c07b4173cbbc76405d564f43a5f7fb1d233c05', '196.74.167.20', 1692175458, '__ci_last_regenerate|i:1692175458;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f44d4fb6a6dfdceb3f17355c9c9f96a0f96402d7', '196.74.167.20', 1692181674, '__ci_last_regenerate|i:1692181674;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f63b0594c8afd12224a4803cbb1ad9381ef142eb', '196.74.158.189', 1692261388, '__ci_last_regenerate|i:1692261388;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f684254f382150c7c5a7b987905ae3070112a6b5', '196.74.158.189', 1692194977, '__ci_last_regenerate|i:1692194977;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f88f3c975064610f659cd27564b841fccbfd3237', '196.74.151.235', 1692003692, '__ci_last_regenerate|i:1692003692;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f90ea1e300856e178493f08d691968be10d6fe20', '196.74.158.189', 1692196256, '__ci_last_regenerate|i:1692196256;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f93e64f6cfe7f1e5b9c0eb525aae3df3ce6a7e15', '196.206.77.183', 1692348103, '__ci_last_regenerate|i:1692348103;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa7d3f4ffd2fa9fc20837fca30be36c9d7982160', '196.74.167.20', 1692177143, '__ci_last_regenerate|i:1692177143;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fab8fd150d283f4e616b11acb4fd4a94440df82d', '197.253.253.185', 1692280913, '__ci_last_regenerate|i:1692280913;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fae1c08d69f26b146c7bf571b0cabdf0b0c0890a', '196.206.77.183', 1692348630, '__ci_last_regenerate|i:1692348630;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('faf78c739b8bb8cf2894b032123490e459220389', '196.74.167.20', 1692181367, '__ci_last_regenerate|i:1692181367;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fcb9c77002ef1e59bb9e1ba52ad4eb263c35a022', '196.74.167.20', 1692114137, '__ci_last_regenerate|i:1692114137;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fd23fe602b8a5c2c4ff824b17b826d2fb37f6a33', '196.74.145.227', 1692021704, '__ci_last_regenerate|i:1692021704;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fe6633cba9280d99d7d3d450ff96be9f7003dc02', '196.65.169.61', 1692371006, '__ci_last_regenerate|i:1692371006;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fe6afb77088ca31c364ce2cd128c86f4a3f24908', '196.74.145.227', 1692094818, '__ci_last_regenerate|i:1692094818;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fe73a858c37f28ee9236c60ac07240348f392f71', '196.74.167.20', 1692179507, '__ci_last_regenerate|i:1692179507;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fe82a022eb24be9c2a880bb400579776a9fa8728', '196.206.77.183', 1692279456, '__ci_last_regenerate|i:1692279456;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ff430328264006b4751ad5c4e8c1873f9ece9354', '196.74.167.20', 1692174773, '__ci_last_regenerate|i:1692174773;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"16/08/2023 09:08\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ffbedbdf54dfdac8b3778920f00a6d59da393b06', '196.65.169.61', 1692375034, '__ci_last_regenerate|i:1692375034;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');


#
# TABLE STRUCTURE FOR: client
#

DROP TABLE IF EXISTS `client`;

CREATE TABLE `client` (
  `id_client` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `code_client` varchar(200) NOT NULL,
  `ice` varchar(200) DEFAULT NULL,
  `full_name` varchar(200) NOT NULL,
  `responsable` varchar(200) DEFAULT NULL,
  `adresse` varchar(200) DEFAULT NULL,
  `ville` varchar(200) NOT NULL,
  `pays` varchar(200) NOT NULL,
  `remise` double NOT NULL DEFAULT '0',
  `telephone` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_client`),
  UNIQUE KEY `code_client` (`code_client`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `client_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `client` (`id_client`, `id_user`, `code_client`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `remise`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (1, 1, 'C/21/0001', '', 'CLIENT COMPTOIRE1', '', 'fes', 'Fes', 'Maroc', '0', '', 'client.comptoire@gmail.com', 'client au comptoir teste\r\n', 1, NULL, '2023-08-18 03:31:19');
INSERT INTO `client` (`id_client`, `id_user`, `code_client`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `remise`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (3, 1, 'C/23/0002', '4567890', 'Eaton ', 'Dolore qui exercitat', 'Quia saepe tempore ', 'Do doloremque pariat', 'Pays-Bas', '59', '+1 (816) 602-4059', 'hadi@mailinator.com', 'Corporis voluptatem alias dolor et nostrum voluptas dolorem dolor incidunt', 1, '2023-08-14 03:42:51', '2023-08-14 05:11:25');
INSERT INTO `client` (`id_client`, `id_user`, `code_client`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `remise`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (4, 1, 'C/23/0003', 'Deserunt ', 'Warren White', 'Odio minus sit quos', 'Accusamus velit volu', 'Et expedita dolores ', 'Grenade', '85', '+1 (729) 726-7896', 'tozyl@mailinator.com', 'Beatae eaque et quo nulla omnis officia qui amet quam ea consectetur sint exercitationem perspiciatis est voluptatem Cum ipsam eligendi', 1, '2023-08-14 05:01:39', '2023-08-14 05:10:21');
INSERT INTO `client` (`id_client`, `id_user`, `code_client`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `remise`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (5, 1, 'C/23/0004', 'Iusto fugiat debitis', 'Dawn Bauer', 'Provident et quia i', 'Cumque dolor enim to', 'Nisi obcaecati provi', 'Slovaquie', '33', '+1 (577) 577-9987', 'cuqerox@mailinator.com', 'Nisi adipisicing officia maiores itaque dolorum voluptatem tempore in', 1, '2023-08-14 05:12:01', NULL);
INSERT INTO `client` (`id_client`, `id_user`, `code_client`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `remise`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (7, 1, 'C/23/0006', 'Eu veniam voluptate', 'Phoebe Ryan', 'Id non ut et aliqua', 'Perspiciatis volupt', 'Anim earum commodo s', 'Cuba', '80', '+1 (561) 407-7046', 'filovek@mailinator.com', 'Aut sunt veritatis proident qui repellendus Aut dolorum deserunt ullam rem fuga Velit non quibusdam sit', 1, '2023-08-14 06:22:31', NULL);
INSERT INTO `client` (`id_client`, `id_user`, `code_client`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `remise`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (8, 1, 'C/23/0007', 'Quaerat asperiores v', 'Shay Stokes', 'Incidunt ut quia in', 'Nihil unde autem iur', 'Laboriosam magnam v', 'Népal', '12', '+1 (541) 441-7385', 'sijapunego@mailinator.com', 'Do tempora est voluptas et omnis ut suscipit corrupti id dolore velit laboris rem quaerat ipsum expedita sint', 1, '2023-08-15 05:01:04', '2023-08-18 03:29:54');


#
# TABLE STRUCTURE FOR: client_cmd
#

DROP TABLE IF EXISTS `client_cmd`;

CREATE TABLE `client_cmd` (
  `id_client_cmd` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `code_client_cmd` varchar(200) NOT NULL,
  `date_client_cmd` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_client_cmd`),
  UNIQUE KEY `code_client_cmd` (`code_client_cmd`),
  KEY `id_client` (`id_client`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `client_cmd_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `client_cmd_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `client_cmd` (`id_client_cmd`, `id_client`, `id_user`, `code_client_cmd`, `date_client_cmd`, `remarque`, `date_create`, `date_update`) VALUES (1, 4, 1, 'CC/23/0001', '2023-08-16', '', '2023-08-16 09:13:00', '2023-08-17 05:41:47');
INSERT INTO `client_cmd` (`id_client_cmd`, `id_client`, `id_user`, `code_client_cmd`, `date_client_cmd`, `remarque`, `date_create`, `date_update`) VALUES (2, 7, 1, 'CC/23/0002', '2023-08-21', '', '2023-08-21 05:21:45', NULL);


#
# TABLE STRUCTURE FOR: client_cmd_details
#

DROP TABLE IF EXISTS `client_cmd_details`;

CREATE TABLE `client_cmd_details` (
  `id_client_cmd_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_client_cmd` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  `id_service` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_client_cmd_details`),
  KEY `id_client_cmd` (`id_client_cmd`),
  KEY `id_produit` (`id_produit`),
  KEY `fk_commande_details_id_service` (`id_service`),
  CONSTRAINT `client_cmd_details_ibfk_1` FOREIGN KEY (`id_client_cmd`) REFERENCES `client_cmd` (`id_client_cmd`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_cmd_details_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `fk_commande_details_id_service` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `client_cmd_details` (`id_client_cmd_details`, `id_client_cmd`, `id_produit`, `quantite`, `date_create`, `date_update`, `id_service`) VALUES (3, 1, 1, 1, '2023-08-17 05:41:47', NULL, NULL);
INSERT INTO `client_cmd_details` (`id_client_cmd_details`, `id_client_cmd`, `id_produit`, `quantite`, `date_create`, `date_update`, `id_service`) VALUES (4, 2, 32, 1, '2023-08-21 05:21:45', NULL, NULL);


#
# TABLE STRUCTURE FOR: commande
#

DROP TABLE IF EXISTS `commande`;

CREATE TABLE `commande` (
  `id_commande` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_fournisseur` int(11) DEFAULT NULL,
  `code_commande` varchar(200) NOT NULL,
  `date_commande` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_commande`),
  UNIQUE KEY `code_commande` (`code_commande`),
  KEY `id_fournisseur` (`id_fournisseur`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseur` (`id_fournisseur`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `commande` (`id_commande`, `id_user`, `id_fournisseur`, `code_commande`, `date_commande`, `remarque`, `date_create`, `date_update`) VALUES (1, 1, 1, 'CF/23/0001', '2023-08-15', '', '2023-08-15 05:05:30', '2023-08-21 03:31:58');


#
# TABLE STRUCTURE FOR: commande_details
#

DROP TABLE IF EXISTS `commande_details`;

CREATE TABLE `commande_details` (
  `id_commande_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_commande` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_achat` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  `id_service` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_commande_details`),
  KEY `id_produit` (`id_produit`),
  KEY `commande_details_ibfk_1` (`id_commande`),
  KEY `fk_commande_details_service` (`id_service`),
  CONSTRAINT `commande_details_ibfk_1` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `commande_details_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `fk_commande_details_service` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `commande_details` (`id_commande_details`, `id_commande`, `id_produit`, `quantite`, `prix_achat`, `date_create`, `date_update`, `id_service`) VALUES (3, 1, 3, '10', '0', '2023-08-21 03:31:58', NULL, NULL);


#
# TABLE STRUCTURE FOR: demontage
#

DROP TABLE IF EXISTS `demontage`;

CREATE TABLE `demontage` (
  `id_demontage` int(11) NOT NULL AUTO_INCREMENT,
  `id_produit` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `code_demontage` varchar(200) NOT NULL,
  `quantite` double NOT NULL,
  `frais` double NOT NULL DEFAULT '0',
  `date_demontage` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_demontage`),
  UNIQUE KEY `code_demontage` (`code_demontage`),
  KEY `id_produit` (`id_produit`),
  CONSTRAINT `demontage_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: demontage_details
#

DROP TABLE IF EXISTS `demontage_details`;

CREATE TABLE `demontage_details` (
  `id_demontage_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_demontage` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_demontage_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_demontage` (`id_demontage`),
  CONSTRAINT `demontage_details_ibfk_1` FOREIGN KEY (`id_demontage`) REFERENCES `demontage` (`id_demontage`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `demontage_details_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: devis
#

DROP TABLE IF EXISTS `devis`;

CREATE TABLE `devis` (
  `id_devis` int(11) NOT NULL AUTO_INCREMENT,
  `code_devis` varchar(200) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `tva` double NOT NULL DEFAULT '20',
  `date_devis` date NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `condition` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_devis`),
  UNIQUE KEY `code_devis` (`code_devis`),
  KEY `id_user` (`id_user`),
  KEY `id_client` (`id_client`),
  CONSTRAINT `devis_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `devis_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `devis` (`id_devis`, `code_devis`, `id_user`, `id_client`, `remarque`, `tva`, `date_devis`, `date_create`, `date_update`, `date_debut`, `date_fin`, `condition`) VALUES (7, 'D/23/0017', 1, 5, '', '20', '2023-08-17', '2023-08-17 04:45:23', '2023-08-18 04:55:03', '2023-08-17', '2023-08-24', '50% à la commande \r\n50 % à la livraison');
INSERT INTO `devis` (`id_devis`, `code_devis`, `id_user`, `id_client`, `remarque`, `tva`, `date_devis`, `date_create`, `date_update`, `date_debut`, `date_fin`, `condition`) VALUES (8, 'D/23/0018', 1, 4, '', '20', '2023-08-17', '2023-08-17 04:54:43', '2023-08-17 04:54:58', '2023-08-17', '2023-08-24', '50% à la commande \r\n50 % à la livraison');


#
# TABLE STRUCTURE FOR: devis_details
#

DROP TABLE IF EXISTS `devis_details`;

CREATE TABLE `devis_details` (
  `id_devis_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_devis` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '1',
  `remise` double NOT NULL DEFAULT '0',
  `remise_dh` double NOT NULL DEFAULT '0',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  `id_service` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_devis_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_devis` (`id_devis`),
  KEY `id_service` (`id_service`),
  CONSTRAINT `devis_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `devis_details_ibfk_2` FOREIGN KEY (`id_devis`) REFERENCES `devis` (`id_devis`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `devis_details_ibfk_3` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `devis_details` (`id_devis_details`, `id_devis`, `id_produit`, `quantite`, `prix_vente`, `remise`, `remise_dh`, `date_create`, `date_update`, `id_service`) VALUES (13, 8, NULL, '1', '1000', '85', '0', '2023-08-17 04:54:58', NULL, 5);
INSERT INTO `devis_details` (`id_devis_details`, `id_devis`, `id_produit`, `quantite`, `prix_vente`, `remise`, `remise_dh`, `date_create`, `date_update`, `id_service`) VALUES (14, 7, NULL, '1', '1000', '33', '0', '2023-08-18 04:55:03', NULL, 5);


#
# TABLE STRUCTURE FOR: exoneration_reste
#

DROP TABLE IF EXISTS `exoneration_reste`;

CREATE TABLE `exoneration_reste` (
  `id_exoneration_reste` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_achat` int(11) DEFAULT NULL,
  `id_vente` int(11) DEFAULT NULL,
  `montant` double NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1=Vente, 2=Achat, 3=Reglement',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_exoneration_reste`),
  KEY `id_user` (`id_user`),
  KEY `id_achat` (`id_achat`),
  KEY `id_vente` (`id_vente`),
  CONSTRAINT `exoneration_reste_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `exoneration_reste_ibfk_2` FOREIGN KEY (`id_achat`) REFERENCES `achat` (`id_achat`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `exoneration_reste_ibfk_3` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: facture
#

DROP TABLE IF EXISTS `facture`;

CREATE TABLE `facture` (
  `id_facture` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) DEFAULT NULL,
  `num_facture` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `total_vente` float DEFAULT NULL,
  `total_rest` float DEFAULT NULL,
  PRIMARY KEY (`id_facture`),
  KEY `id_client` (`id_client`),
  CONSTRAINT `facture_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `facture` (`id_facture`, `id_client`, `num_facture`, `date`, `total_vente`, `total_rest`) VALUES (46, 4, '20230056', '2023-08-19', NULL, NULL);
INSERT INTO `facture` (`id_facture`, `id_client`, `num_facture`, `date`, `total_vente`, `total_rest`) VALUES (47, 8, '20230057', '2023-08-21', NULL, NULL);


#
# TABLE STRUCTURE FOR: fournisseur
#

DROP TABLE IF EXISTS `fournisseur`;

CREATE TABLE `fournisseur` (
  `id_fournisseur` int(11) NOT NULL AUTO_INCREMENT,
  `code_fournisseur` varchar(200) NOT NULL,
  `ice` varchar(200) DEFAULT NULL,
  `full_name` varchar(200) NOT NULL,
  `responsable` varchar(200) DEFAULT NULL,
  `adresse` varchar(200) DEFAULT NULL,
  `ville` varchar(200) NOT NULL,
  `pays` varchar(200) NOT NULL,
  `telephone` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_fournisseur`),
  UNIQUE KEY `code_fournisseur` (`code_fournisseur`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `fournisseur` (`id_fournisseur`, `code_fournisseur`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (1, 'F/23/0001', 'Est nostrum accusant', 'Keaton Gould', 'Possimus qui verita', 'Eligendi deleniti al', 'Lorem perspiciatis ', 'Liban', '+1 (232) 963-3323', 'hitugato@mailinator.com', 'Illo consequatur ea aut sequi molestias adipisicing cumque vel ad distinctio Nisi quibusdam aliquam provident nisi', 1, '2023-08-14 03:34:57', '2023-08-17 05:44:33');
INSERT INTO `fournisseur` (`id_fournisseur`, `code_fournisseur`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (3, 'F/23/0003', '12345678987654', 'Fournisseur 3', '', 'casablanca maarif', 'Casablanca', 'Maroc', '+212512348746', 'fournisseur.teste@gmail.com', 'juste pour teste', 1, '2023-08-18 03:45:00', NULL);
INSERT INTO `fournisseur` (`id_fournisseur`, `code_fournisseur`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (4, 'F/23/0004', '56789', 'Mahmoud', 'Fugiat facilis possi', 'Ut qui facilis qui', 'Dolor autem nulla', 'Maroc', '+1 (671) 522-8005', 'zicebidyk@mailinator', '', 1, '2023-08-21 03:39:11', '2023-08-21 03:39:27');


#
# TABLE STRUCTURE FOR: information
#

DROP TABLE IF EXISTS `information`;

CREATE TABLE `information` (
  `id_information` int(11) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `adresse` varchar(200) NOT NULL,
  `ville` varchar(200) NOT NULL,
  `pays` varchar(200) NOT NULL,
  `telephone` varchar(200) NOT NULL,
  `fix` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `web` varchar(200) DEFAULT NULL,
  `num_rc` varchar(200) DEFAULT NULL,
  `num_patente` varchar(200) DEFAULT NULL,
  `num_if` varchar(200) DEFAULT NULL,
  `num_cnss` varchar(200) DEFAULT NULL,
  `num_ice` varchar(200) DEFAULT NULL,
  `num_rib` varchar(200) DEFAULT NULL,
  `bank` varchar(200) DEFAULT NULL,
  `print_message` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_information`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `information` (`id_information`, `full_name`, `adresse`, `ville`, `pays`, `telephone`, `fix`, `email`, `web`, `num_rc`, `num_patente`, `num_if`, `num_cnss`, `num_ice`, `num_rib`, `bank`, `print_message`, `date_create`, `date_update`) VALUES (1, 'FES MARKETING SERVICE', 'Bureau 206 – 2éme étage Bureaux NOUR Angle AV. Slaoui', 'FES', 'Maroc', '+212 6 61 52 57 40', '+212 5 35 64 51 03', 'commercial@fes-marketing.net', 'www.fes-marketing.net', '150', '13230000', '40043427', '8850000', '201540002500000', '127 270 21212 00000000000 00', 'Al Barid Bank', '', NULL, NULL);


#
# TABLE STRUCTURE FOR: inventaire
#

DROP TABLE IF EXISTS `inventaire`;

CREATE TABLE `inventaire` (
  `id_inventaire` int(11) NOT NULL AUTO_INCREMENT,
  `code_inventaire` varchar(200) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `date_inventaire` date NOT NULL,
  `valide` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=Valide, 0=Not',
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_inventaire`),
  UNIQUE KEY `code_inventaire` (`code_inventaire`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `inventaire_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `inventaire` (`id_inventaire`, `code_inventaire`, `id_user`, `date_inventaire`, `valide`, `remarque`, `date_create`, `date_update`) VALUES (2, 'IV/23/0002', 1, '2023-08-14', 1, '', '2023-08-14 03:58:50', '2023-08-14 03:58:59');
INSERT INTO `inventaire` (`id_inventaire`, `code_inventaire`, `id_user`, `date_inventaire`, `valide`, `remarque`, `date_create`, `date_update`) VALUES (3, 'IV/23/0003', 1, '2023-08-18', 1, '', '2023-08-18 03:47:40', '2023-08-18 03:47:44');
INSERT INTO `inventaire` (`id_inventaire`, `code_inventaire`, `id_user`, `date_inventaire`, `valide`, `remarque`, `date_create`, `date_update`) VALUES (4, 'IV/23/0004', 1, '2023-08-21', 1, '', '2023-08-21 03:44:18', '2023-08-21 03:44:24');


#
# TABLE STRUCTURE FOR: inventaire_details
#

DROP TABLE IF EXISTS `inventaire_details`;

CREATE TABLE `inventaire_details` (
  `id_inventaire_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_inventaire` int(11) DEFAULT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL COMMENT '1=Entree, 2=Srotie',
  `quantite` int(11) NOT NULL,
  `prix` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_inventaire_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_inventaire` (`id_inventaire`) USING BTREE,
  CONSTRAINT `inventaire_details_ibfk_1` FOREIGN KEY (`id_inventaire`) REFERENCES `inventaire` (`id_inventaire`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `inventaire_details_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `inventaire_details` (`id_inventaire_details`, `id_inventaire`, `id_produit`, `type`, `quantite`, `prix`, `date_create`, `date_update`) VALUES (4, 2, 3, 0, 0, '12', '2023-08-14 03:58:50', NULL);
INSERT INTO `inventaire_details` (`id_inventaire_details`, `id_inventaire`, `id_produit`, `type`, `quantite`, `prix`, `date_create`, `date_update`) VALUES (5, 2, 2, 0, 0, '30', '2023-08-14 03:58:51', NULL);
INSERT INTO `inventaire_details` (`id_inventaire_details`, `id_inventaire`, `id_produit`, `type`, `quantite`, `prix`, `date_create`, `date_update`) VALUES (6, 2, 1, 0, 0, '66', '2023-08-14 03:58:53', NULL);
INSERT INTO `inventaire_details` (`id_inventaire_details`, `id_inventaire`, `id_produit`, `type`, `quantite`, `prix`, `date_create`, `date_update`) VALUES (7, 3, 30, 0, 0, '2', '2023-08-18 03:47:40', NULL);
INSERT INTO `inventaire_details` (`id_inventaire_details`, `id_inventaire`, `id_produit`, `type`, `quantite`, `prix`, `date_create`, `date_update`) VALUES (8, 3, 31, 0, 0, '100', '2023-08-18 03:47:41', NULL);
INSERT INTO `inventaire_details` (`id_inventaire_details`, `id_inventaire`, `id_produit`, `type`, `quantite`, `prix`, `date_create`, `date_update`) VALUES (9, 4, 32, 0, 0, '9', '2023-08-21 03:44:18', NULL);
INSERT INTO `inventaire_details` (`id_inventaire_details`, `id_inventaire`, `id_produit`, `type`, `quantite`, `prix`, `date_create`, `date_update`) VALUES (10, 4, 31, 0, 0, '100', '2023-08-21 03:44:20', NULL);
INSERT INTO `inventaire_details` (`id_inventaire_details`, `id_inventaire`, `id_produit`, `type`, `quantite`, `prix`, `date_create`, `date_update`) VALUES (11, 4, 30, 0, 0, '2', '2023-08-21 03:44:21', NULL);


#
# TABLE STRUCTURE FOR: paiement
#

DROP TABLE IF EXISTS `paiement`;

CREATE TABLE `paiement` (
  `id_paiement` int(11) NOT NULL AUTO_INCREMENT,
  `id_vente` int(11) DEFAULT NULL,
  `id_avoir` int(44) DEFAULT NULL,
  `id_achat` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `montant` double NOT NULL,
  `date_paiement` date NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1=Vente, 2=Achat, 3=Reglement',
  `methode` int(11) NOT NULL COMMENT '1=Espece, 2=Cheque, 3=Effet, 4=Virement, 5=From Avance',
  `type_avance` tinyint(4) DEFAULT NULL COMMENT '1=Espece, 2=Cheque/Effet, 3=Virement',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_paiement`),
  KEY `id_user` (`id_user`),
  KEY `id_vente` (`id_vente`) USING BTREE,
  KEY `id_achat` (`id_achat`),
  KEY `id_avoir` (`id_avoir`),
  CONSTRAINT `paiement_ibfk_1` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `paiement_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `paiement_ibfk_3` FOREIGN KEY (`id_achat`) REFERENCES `achat` (`id_achat`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `paiement_ibfk_4` FOREIGN KEY (`id_avoir`) REFERENCES `avoir` (`id_avoir`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (1, NULL, NULL, 1, 1, '660', '2023-08-15', 2, 1, NULL, '2023-08-15 11:55:37', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (2, NULL, NULL, 2, 1, '300', '2023-08-15', 2, 1, NULL, '2023-08-15 12:28:55', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (3, NULL, NULL, 1, 1, '66', '2023-08-16', 2, 1, NULL, '2023-08-16 04:27:49', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (4, NULL, NULL, 3, 1, '144', '2023-08-16', 2, 1, NULL, '2023-08-16 04:28:58', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (7, 11, NULL, NULL, 1, '240', '2023-08-16', 1, 1, NULL, '2023-08-16 04:56:48', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (8, 12, NULL, NULL, 1, '1200', '2023-08-16', 1, 1, NULL, '2023-08-16 08:37:14', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (9, 13, NULL, NULL, 1, '180', '2023-08-16', 1, 1, NULL, '2023-08-16 08:52:02', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (10, 14, NULL, NULL, 1, '804', '2023-08-17', 1, 1, NULL, '2023-08-17 04:48:52', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (11, 15, NULL, NULL, 1, '2.4', '2023-08-18', 1, 1, NULL, '2023-08-18 05:49:21', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (12, 16, NULL, NULL, 1, '1200', '2023-08-18', 1, 1, NULL, '2023-08-18 05:54:26', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (14, 18, NULL, NULL, 1, '180', '2023-08-19', 1, 1, NULL, '2023-08-19 04:52:07', NULL);
INSERT INTO `paiement` (`id_paiement`, `id_vente`, `id_avoir`, `id_achat`, `id_user`, `montant`, `date_paiement`, `type`, `methode`, `type_avance`, `date_create`, `date_update`) VALUES (15, NULL, NULL, 4, 1, '90', '2023-08-21', 2, 1, NULL, '2023-08-21 03:42:57', NULL);


#
# TABLE STRUCTURE FOR: production
#

DROP TABLE IF EXISTS `production`;

CREATE TABLE `production` (
  `id_production` int(11) NOT NULL AUTO_INCREMENT,
  `id_produit` int(11) DEFAULT NULL,
  `code_production` varchar(200) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `frais` double NOT NULL DEFAULT '0',
  `date_production` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_production`),
  UNIQUE KEY `code_production` (`code_production`),
  KEY `id_produit` (`id_produit`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `production_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: production_details
#

DROP TABLE IF EXISTS `production_details`;

CREATE TABLE `production_details` (
  `id_production_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_production` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_production_details`),
  KEY `id_production` (`id_production`),
  KEY `id_produit` (`id_produit`),
  CONSTRAINT `production_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `production_details_ibfk_2` FOREIGN KEY (`id_production`) REFERENCES `production` (`id_production`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: produit
#

DROP TABLE IF EXISTS `produit`;

CREATE TABLE `produit` (
  `id_produit` int(11) NOT NULL AUTO_INCREMENT,
  `id_categorie` int(11) DEFAULT NULL,
  `id_sub_categorie` int(11) DEFAULT NULL,
  `code_produit` varchar(200) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `prix_achat` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '1',
  `alert` int(11) NOT NULL,
  `image` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=Normal, 1=Composé',
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_produit`),
  UNIQUE KEY `code_produit` (`code_produit`),
  KEY `id_categorie` (`id_categorie`),
  KEY `id_sub_categorie` (`id_sub_categorie`),
  CONSTRAINT `produit_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categorie` (`id_categorie`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `produit_ibfk_2` FOREIGN KEY (`id_sub_categorie`) REFERENCES `sub_categorie` (`id_sub_categorie`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (1, 1, 1, 'Rerum aut dolorem eu', 'Alea Serrano', '66', '2', 19, 'Rerum aut dolorem eu.jpg', 'Nesciunt velit adipisci sed repellendus Quos hic id', 0, 0, '2023-08-14 03:32:49', '2023-08-18 03:36:35', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (2, 1, 1, 'Ut aut temporibus pr', 'Buffy Nielsen', '30', '45', 63, NULL, 'Qui cumque ut est hic deleniti non obcaecati irure dolorem illo distinctio Ullam', 0, 0, '2023-08-14 03:47:19', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (3, 1, 1, 'PR8007AM8926', 'Produit1', '12', '20', 2, NULL, '', 0, 0, '2023-08-14 03:48:25', '2023-08-17 08:56:09', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (4, 1, 1, 'Ipsa ipsum nihil sa', 'Nomlanga Beasley', '28', '0', 64, NULL, 'Non consequat Quasi porro quo irure molestiae', 0, 0, '2023-08-14 05:13:37', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (5, 1, 1, 'Magni ad aliquid dol', 'Anjolie Burks', '10', '51', 15, NULL, 'Tempora mollit minim numquam officia aut cillum labore exercitationem', 0, 0, '2023-08-14 05:23:18', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (6, 1, 1, 'Id dolore aspernatur', 'Maryam Guzman', '3', '67', 75, NULL, 'Suscipit voluptate amet alias nulla do', 0, 0, '2023-08-14 05:25:04', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (7, 1, 1, 'In anim cupidatat mi', 'Sloane Olson', '97', '8', 54, NULL, 'Impedit aliquam et vel magna aut nihil consequat Ducimus deleniti explicabo Ratione eius rerum quod laboris', 0, 0, '2023-08-14 05:26:15', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (8, 1, 1, 'iphone ', 'Eaton Whitaker', '38', '72', 82, NULL, 'A anim sit cillum tempora odit quia vitae', 0, 0, '2023-08-14 05:40:57', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (9, 1, 1, 'sms', 'Acton Rose', '85', '14', 57, NULL, 'Tenetur eum esse harum magnam ea eligendi labore quae magnam libero illo tempora voluptatem non', 0, 0, '2023-08-14 05:47:32', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (10, 1, 1, 'Eum occaecat culpa ', 'Cleo James', '27', '6', 89, NULL, 'Numquam consequatur laborum Aliquam aut dolor consequatur dolor aperiam beatae voluptatem et', 0, 0, '2023-08-14 05:54:13', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (11, 1, 1, 'Voluptatem Unde ex ', 'Buckminster Riggs', '90', '1', 33, NULL, 'Commodo ducimus autem laborum animi natus natus iste voluptas dolor et nihil dolorem', 0, 0, '2023-08-14 05:54:54', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (12, 1, 1, 'Autem exercitationem', 'Paloma Ayala', '31', '73', 74, NULL, 'Possimus praesentium lorem voluptate ea veniam aute eos excepteur nisi consequuntur pariatur Saepe suscipit maxime ut', 0, 0, '2023-08-14 05:56:18', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (13, 1, 1, 'dolores ', 'Lacey Medina', '79', '57', 18, NULL, 'Commodo quisquam mollit in ratione quis sequi corrupti iste rerum nulla ex rerum exercitationem ullam non molestiae quia', 0, 0, '2023-08-14 05:58:46', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (14, 1, 1, 'Quo in molestias dol', 'Denise Gilbert', '82', '84', 83, NULL, 'Omnis maiores esse dolor autem dolor officiis doloribus dolorum et ea', 0, 0, '2023-08-14 06:01:16', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (15, 1, 1, 'Fugiat obcaecati lab', 'Liberty Case', '0', '97', 69, NULL, 'Nostrum sed dignissimos ipsa qui omnis ut doloremque et duis et anim amet velit odio voluptatum minim est', 0, 0, '2023-08-14 06:05:02', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (16, 1, 1, 'Qui ex dolore possim', 'Natalie Ingram', '16', '93', 46, NULL, 'Cum earum sapiente consequatur in non voluptate qui amet est et et maxime enim do voluptatem ut', 0, 0, '2023-08-14 06:06:43', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (17, 1, 1, 'Suscipit animi aute', 'Christopher Delacruz', '7', '52', 64, NULL, 'Voluptatem iure sequi sit officiis Nam repellendus Eos temporibus officiis id et elit quo nisi voluptas esse magna sapiente', 0, 0, '2023-08-14 06:08:35', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (18, 1, 1, 'Velit do quia cum ve', 'Farrah Goff', '62', '6', 84, NULL, 'Dolorem rerum et sequi totam consequatur Sed dolor proident sit quaerat atque voluptatibus assumenda', 0, 0, '2023-08-14 06:20:46', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (19, 1, 1, 'Corrupti voluptatem', 'Katell Noble', '14', '55', 99, NULL, 'Qui culpa labore tempora aperiam dolores qui minim', 0, 0, '2023-08-14 06:23:02', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (20, 1, 1, 'Eu laboris aperiam a', 'Kitra Powers', '50', '72', 88, NULL, 'Excepteur occaecat quisquam voluptate irure excepteur non corporis enim aliquip expedita ipsa et', 0, 0, '2023-08-14 06:24:37', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (21, 1, 1, 'Ipsum ipsum animi ', 'Edan George', '57', '23', 41, NULL, 'Nisi occaecat hic voluptatibus accusamus sint est pariatur Dolor voluptate sint minus animi', 0, 0, '2023-08-14 06:35:09', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (22, 1, 1, 'Culpa laboris earum ', 'Martha Brooks', '61', '27', 79, NULL, 'Cupidatat magni facilis ut consequuntur ut quia quis quo consequat Beatae architecto', 0, 0, '2023-08-14 06:40:10', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (23, 1, 1, 'Aliqua Voluptatem c', 'Sierra Nicholson', '57', '89', 99, NULL, 'Nihil ad officia obcaecati beatae rerum maxime cumque cum', 0, 0, '2023-08-14 06:41:15', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (24, 1, 1, 'Suscipit soluta dese', 'Glenna Guy', '87', '41', 67, NULL, 'Optio velit omnis vitae saepe debitis qui est duis nobis', 0, 0, '2023-08-14 08:23:56', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (25, 1, 1, 'Ea sapiente nihil co', 'Tatyana Day', '8', '13', 77, NULL, 'Delectus rerum ut lorem modi ipsum sint labore est qui aut sit nesciunt quibusdam velit laudantium velit rem omnis nulla', 0, 0, '2023-08-14 09:20:46', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (26, 1, 1, 'Debitis occaecat fac', 'Priscilla Ortega', '93', '92', 6, NULL, 'Anim qui quibusdam ea neque nulla natus sed incididunt nemo non', 0, 0, '2023-08-14 09:46:34', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (27, 1, 1, 'Atque non aut exerci', 'Zenia Floyd', '20', '31', 50, NULL, 'Eaque eaque eveniet quae est doloribus', 0, 0, '2023-08-14 11:00:03', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (28, 1, 1, 'PRC4411AM6987', 'ProduiT COMPTOIR', '61', '27', 1, NULL, NULL, 1, 0, '2023-08-14 11:08:10', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (29, 1, 1, 'Dolor vel sunt eum ', 'Bruce Manning', '46', '40', 49, NULL, 'Vitae tempore nulla do labore voluptatem aliquip ad', 0, 0, '2023-08-15 05:24:45', '2023-08-17 04:49:12', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (30, 5, 3, 'Aspernatur molestiae', 'Darryl ', '2', '98', 3, NULL, 'Corporis ut et duis tenetur saepe officia ex necessitatibus in maxime delectus qui culpa in dolore et inventore', 0, 1, '2023-08-17 06:17:04', '2023-08-21 04:49:09', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (31, 6, 4, 'PR7140AF4050', 'Produit 3', '100', '150', 2, NULL, 'juste pour le teste c tous', 0, 1, '2023-08-18 03:37:22', '2023-08-21 03:35:02', NULL);
INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`, `stock`) VALUES (32, 6, 4, 'PR9031AF9961', 'Produit 4', '9', '10', 2, NULL, '', 0, 1, '2023-08-18 04:22:06', '2023-08-21 03:41:27', NULL);


#
# TABLE STRUCTURE FOR: produit_details
#

DROP TABLE IF EXISTS `produit_details`;

CREATE TABLE `produit_details` (
  `id_produit_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_produit_compose` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_produit_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_produit_compose` (`id_produit_compose`),
  CONSTRAINT `produit_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `produit_details_ibfk_2` FOREIGN KEY (`id_produit_compose`) REFERENCES `produit` (`id_produit`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `produit_details` (`id_produit_details`, `id_produit_compose`, `id_produit`, `quantite`, `date_create`, `date_update`) VALUES (1, 28, 22, '1', '2023-08-14 11:08:10', NULL);


#
# TABLE STRUCTURE FOR: produit_end
#

DROP TABLE IF EXISTS `produit_end`;

CREATE TABLE `produit_end` (
  `id_produit_end` int(11) NOT NULL AUTO_INCREMENT,
  `id_produit` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `quantite` double NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_produit_end`),
  KEY `id_produit` (`id_produit`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `produit_end_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `produit_end_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `produit_end` (`id_produit_end`, `id_produit`, `id_user`, `date`, `quantite`, `description`, `date_create`, `date_update`) VALUES (1, 2, 1, '2023-08-16', '2', '', '2023-08-16 11:36:10', '2023-08-19 05:25:44');
INSERT INTO `produit_end` (`id_produit_end`, `id_produit`, `id_user`, `date`, `quantite`, `description`, `date_create`, `date_update`) VALUES (2, 32, 1, '2023-08-21', '2', '', '2023-08-21 03:45:02', NULL);


#
# TABLE STRUCTURE FOR: service
#

DROP TABLE IF EXISTS `service`;

CREATE TABLE `service` (
  `id_service` int(11) NOT NULL AUTO_INCREMENT,
  `id_categorie` int(11) NOT NULL,
  `id_sub_categorie` int(11) NOT NULL,
  `full_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prix_vente` double NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  PRIMARY KEY (`id_service`),
  KEY `id_categorie` (`id_categorie`),
  KEY `id_sub_categorie` (`id_sub_categorie`),
  CONSTRAINT `service_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categorie` (`id_categorie`),
  CONSTRAINT `service_ibfk_2` FOREIGN KEY (`id_sub_categorie`) REFERENCES `sub_categorie` (`id_sub_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `service` (`id_service`, `id_categorie`, `id_sub_categorie`, `full_name`, `prix_vente`, `description`, `image`, `display`) VALUES (1, 1, 1, 'Updated service', '2000', 'creation site web', NULL, 0);
INSERT INTO `service` (`id_service`, `id_categorie`, `id_sub_categorie`, `full_name`, `prix_vente`, `description`, `image`, `display`) VALUES (5, 1, 1, 'Listed service1', '1000', 'nothing to say', NULL, 1);
INSERT INTO `service` (`id_service`, `id_categorie`, `id_sub_categorie`, `full_name`, `prix_vente`, `description`, `image`, `display`) VALUES (7, 6, 4, 'Service 3', '1000', 'also for the test', NULL, 1);


#
# TABLE STRUCTURE FOR: sub_categorie
#

DROP TABLE IF EXISTS `sub_categorie`;

CREATE TABLE `sub_categorie` (
  `id_sub_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `id_categorie` int(11) DEFAULT NULL,
  `full_name` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sub_categorie`),
  KEY `id_categorie` (`id_categorie`),
  CONSTRAINT `sub_categorie_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categorie` (`id_categorie`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `sub_categorie` (`id_sub_categorie`, `id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (1, 1, 'Raja Alexander', 'Nihil est quidem nesciunt molestiae debitis obcaecati et voluptate ipsum aliqua Sed enim reprehenderit molestias aut', 0, '2023-08-14 03:32:25', '2023-08-17 04:49:12');
INSERT INTO `sub_categorie` (`id_sub_categorie`, `id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (3, 5, 'Mechelle Pena', 'Dolorem qui doloremque omnis atque exercitationem cupiditate excepteur dolor similique nostrud harum voluptatibus cupiditate ea officia ipsum optio est', 1, '2023-08-15 05:02:51', '2023-08-21 04:49:09');
INSERT INTO `sub_categorie` (`id_sub_categorie`, `id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (4, 6, 'Sous categorie 3', 'aussi pour le teste c tous', 1, '2023-08-18 03:35:18', '2023-08-21 03:35:02');
INSERT INTO `sub_categorie` (`id_sub_categorie`, `id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (5, 7, 'Sous-Catégorie 4', '', 1, '2023-08-21 03:37:16', NULL);


#
# TABLE STRUCTURE FOR: transport
#

DROP TABLE IF EXISTS `transport`;

CREATE TABLE `transport` (
  `id_transport` int(11) NOT NULL AUTO_INCREMENT,
  `code_transport` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `livreur` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `matricule` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telephone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display` int(1) DEFAULT '1',
  PRIMARY KEY (`id_transport`),
  KEY `code_transport` (`code_transport`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `transport` (`id_transport`, `code_transport`, `livreur`, `matricule`, `telephone`, `description`, `display`) VALUES (8, 'TR/23/0001', 'Livreur 9', 'A17/456789', '+1 (671) 522-8005', 'Gfvhbjnk', 1);
INSERT INTO `transport` (`id_transport`, `code_transport`, `livreur`, `matricule`, `telephone`, `description`, `display`) VALUES (9, 'TR/23/0002', 'Livreur 2', 'A17/456789', '+1 (671) 522-8005', 'Xdcfvgbhnj', 1);
INSERT INTO `transport` (`id_transport`, `code_transport`, `livreur`, `matricule`, `telephone`, `description`, `display`) VALUES (10, 'TR/23/0003', 'Livreur 2', 'A17/456789', '+1 (671) 522-8005', 'Xdcfvgbhnj', 1);


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `role` int(11) NOT NULL DEFAULT '0' COMMENT '0=MANAGER, 1=ADMIN',
  `authenticator` int(11) NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `last_logout` datetime DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id_user`, `full_name`, `username`, `password`, `role`, `authenticator`, `last_login`, `last_logout`, `date_create`, `date_update`) VALUES (1, 'FMS', 'admin', '$2y$10$N7rV.xJyeQJ07HWRBwpKCut.73BSwcXzkYurloI1LxoySXLoMYwmq', 1, 0, '2023-08-21 09:21:00', '2023-08-14 09:36:00', NULL, '2023-08-21 03:21:00');
INSERT INTO `user` (`id_user`, `full_name`, `username`, `password`, `role`, `authenticator`, `last_login`, `last_logout`, `date_create`, `date_update`) VALUES (2, 'Demo Access', 'demo', '$2y$10$XOC5b.r4IqKySXGl4qlf5.F6DrS.gtIB1VjvRla7ZyH12zEJU5fOK', 1, 0, NULL, NULL, NULL, '2023-08-18 03:42:53');
INSERT INTO `user` (`id_user`, `full_name`, `username`, `password`, `role`, `authenticator`, `last_login`, `last_logout`, `date_create`, `date_update`) VALUES (4, 'Ahmed ', 'ahmed', '$2y$10$fTWp0UaYP8D/nslolsO/QuaT01L7gjrl3jaA7M7XgBs1UmiY8GMOm', 0, 0, NULL, NULL, '2023-08-14 03:41:08', NULL);


#
# TABLE STRUCTURE FOR: user_log
#

DROP TABLE IF EXISTS `user_log`;

CREATE TABLE `user_log` (
  `id_user_log` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `systeme` tinyint(4) NOT NULL DEFAULT '0',
  `ip_address` varchar(100) NOT NULL,
  `date_log` datetime NOT NULL,
  `text` varchar(200) NOT NULL,
  PRIMARY KEY (`id_user_log`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `user_log_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=277 DEFAULT CHARSET=utf8;

INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (1, 1, 0, '169.254.96.43', '2023-06-13 15:18:20', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (2, 1, 0, '196.89.134.245', '2023-08-12 12:49:49', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (3, 1, 0, '196.89.134.245', '2023-08-12 12:51:42', 'Modification de profile');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (4, 1, 0, '196.89.134.245', '2023-08-12 12:54:26', 'Déconnexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (5, 1, 0, '196.89.134.245', '2023-08-12 12:54:38', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (6, 1, 0, '196.89.134.245', '2023-08-12 12:55:04', 'Déconnexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (7, 1, 0, '196.89.134.245', '2023-08-12 12:55:07', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (8, 1, 0, '196.89.134.245', '2023-08-12 12:55:40', 'Déconnexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (9, 1, 0, '196.89.134.245', '2023-08-12 12:56:38', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (10, 1, 0, '196.89.134.245', '2023-08-12 13:00:28', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (11, 1, 0, '196.74.151.235', '2023-08-14 09:29:29', 'Enregistrement de client ( <b>Telaj med</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (12, 1, 0, '196.74.151.235', '2023-08-14 09:29:34', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (13, 1, 0, '196.74.151.235', '2023-08-14 09:31:33', 'Modification de client ( <b>Telaj med</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (14, 1, 0, '196.74.151.235', '2023-08-14 09:31:39', 'Suppression de client ( <b>Telaj med</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (15, 1, 0, '196.74.151.235', '2023-08-14 09:31:56', 'Enregistrement de catégorie ( <b>Shellie Santos</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (16, 1, 0, '196.74.151.235', '2023-08-14 09:32:25', 'Enregistrement de sous-catégorie ( <b>Raja Alexander</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (17, 1, 0, '196.74.151.235', '2023-08-14 09:32:29', 'Modification de catégorie ( <b>Shellie Santoss</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (18, 1, 0, '196.74.151.235', '2023-08-14 09:32:49', 'Enregistrement de produit ( <b>Alea Serrano</b> ) avec image');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (19, 1, 0, '196.74.151.235', '2023-08-14 09:34:57', 'Enregistrement de fournisseur ( <b>Keaton Gould</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (20, 1, 0, '196.74.151.235', '2023-08-14 09:36:13', 'Déconnexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (21, 1, 0, '196.74.151.235', '2023-08-14 09:36:22', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (22, 1, 0, '196.74.151.235', '2023-08-14 09:39:24', 'Modification de client ( <b>CLIENT COMPTOIRE1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (23, 1, 0, '196.74.151.235', '2023-08-14 09:41:08', 'Enregistrement de Commercial ( <b>Ahmed </b> / <b>ahmed</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (24, 1, 0, '196.74.151.235', '2023-08-14 09:42:50', 'Enregistrement de catégorie ( <b>Cat1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (25, 1, 0, '196.74.151.235', '2023-08-14 09:42:51', 'Enregistrement de client ( <b>Eaton Parker</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (26, 1, 0, '196.74.151.235', '2023-08-14 09:43:51', 'Modification de catégorie ( <b>Cat1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (27, 1, 0, '196.74.151.235', '2023-08-14 09:44:29', 'Suppression de catégorie ( <b>Cat1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (28, 1, 0, '196.74.151.235', '2023-08-14 09:45:00', 'Enregistrement de sous-catégorie ( <b>Sous cat1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (29, 1, 0, '196.74.151.235', '2023-08-14 09:45:07', 'Enregistrement d\'avance ( <b>1 000.00</b> DH / <b>Espèce</b> ) de client ( <b>Eaton Parker</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (30, 1, 0, '196.74.151.235', '2023-08-14 09:45:36', 'Modification de sous-catégorie ( <b>Sous cat2</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (31, 1, 0, '196.74.151.235', '2023-08-14 09:45:44', 'Suppression de sous-catégorie ( <b>Sous cat2</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (32, 1, 0, '196.74.151.235', '2023-08-14 09:45:50', 'Enregistrement d\'entrée de caisse ( <b>1 000.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (33, 1, 0, '196.74.151.235', '2023-08-14 09:46:23', 'Enregistrement de Sortie de caisse ( <b>500.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (34, 1, 0, '196.74.151.235', '2023-08-14 09:47:19', 'Enregistrement de produit ( <b>Buffy Nielsen</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (35, 1, 0, '196.74.151.235', '2023-08-14 09:48:25', 'Enregistrement de produit ( <b>Produit1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (36, 1, 0, '196.74.151.235', '2023-08-14 09:51:22', 'Modification de client ( <b>Eaton </b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (37, 1, 0, '196.74.151.235', '2023-08-14 09:53:14', 'Modification de Commercial ( <b>Demo Access</b> / <b>demo</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (38, 1, 0, '196.74.151.235', '2023-08-14 09:53:47', 'Enregistrement de Commercial ( <b>Telaj med</b> / <b>telajdemo</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (39, 1, 0, '196.74.151.235', '2023-08-14 09:53:55', 'Suppression de Commercial ( <b>Telaj med</b> / <b>telajdemo</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (40, 1, 0, '196.74.151.235', '2023-08-14 09:55:35', 'Modification de fournisseur ( <b>Keaton Gould</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (41, 1, 0, '196.74.151.235', '2023-08-14 09:56:24', 'Enregistrement de fournisseur ( <b>Telaj med</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (42, 1, 0, '196.74.151.235', '2023-08-14 09:56:27', 'Enregistrement de catégorie ( <b>Catherine Wolfe</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (43, 1, 0, '196.74.151.235', '2023-08-14 09:56:32', 'Suppression de fournisseur ( <b>Telaj med</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (44, 1, 0, '196.74.151.235', '2023-08-14 09:56:52', 'Modification de catégorie ( <b>Catherine Wolfe</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (45, 1, 0, '196.74.151.235', '2023-08-14 09:57:00', 'Modification/Archivage de catégorie ( <b>Catherine Wolfe</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (46, 1, 0, '196.74.151.235', '2023-08-14 09:57:43', 'Inventaire - Enregistrement d\'état de produit <b>Alea Serrano</b> \r\n                        ( Qte : <b>0</b> | <b>66.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (47, 1, 0, '196.74.151.235', '2023-08-14 09:57:44', 'Inventaire - Enregistrement d\'état de produit <b>Buffy Nielsen</b> \r\n                        ( Qte : <b>0</b> | <b>30.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (48, 1, 0, '196.74.151.235', '2023-08-14 09:57:45', 'Inventaire - Enregistrement d\'état de produit <b>Produit1</b> \r\n                        ( Qte : <b>0</b> | <b>12.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (49, 1, 0, '196.74.151.235', '2023-08-14 09:57:48', 'Validation d\'inventaire ( <b>IV/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (50, 1, 0, '196.74.151.235', '2023-08-14 09:58:50', 'Inventaire - Enregistrement d\'état de produit <b>Produit1</b> \r\n                        ( Qte : <b>0</b> | <b>12.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (51, 1, 0, '196.74.151.235', '2023-08-14 09:58:51', 'Inventaire - Enregistrement d\'état de produit <b>Buffy Nielsen</b> \r\n                        ( Qte : <b>0</b> | <b>30.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (52, 1, 0, '196.74.151.235', '2023-08-14 09:58:53', 'Inventaire - Enregistrement d\'état de produit <b>Alea Serrano</b> \r\n                        ( Qte : <b>0</b> | <b>66.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (53, 1, 0, '196.74.151.235', '2023-08-14 09:58:59', 'Validation d\'inventaire ( <b>IV/23/0002</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (54, 1, 0, '196.74.151.235', '2023-08-14 09:59:58', 'Suppression d\'inventaire ( <b>IV/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (55, 1, 0, '196.74.151.235', '2023-08-14 11:01:39', 'Enregistrement de client ( <b>Warren White</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (56, 1, 0, '196.74.151.235', '2023-08-14 11:03:56', 'Modification de client ( <b>Warren White</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (57, 1, 0, '196.74.151.235', '2023-08-14 11:08:17', 'Modification de client ( <b>Warren White</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (58, 1, 0, '196.74.151.235', '2023-08-14 11:09:03', 'Modification de client ( <b>Warren White</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (59, 1, 0, '196.74.151.235', '2023-08-14 11:10:04', 'Modification de client ( <b>Warren White</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (60, 1, 0, '196.74.151.235', '2023-08-14 11:10:21', 'Modification de client ( <b>Warren White</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (61, 1, 0, '196.74.151.235', '2023-08-14 11:11:25', 'Modification de client ( <b>Eaton </b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (62, 1, 0, '196.74.151.235', '2023-08-14 11:12:01', 'Enregistrement de client ( <b>Dawn Bauer</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (63, 1, 0, '196.74.151.235', '2023-08-14 11:13:37', 'Enregistrement de produit ( <b>Nomlanga Beasley</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (64, 1, 0, '196.74.151.235', '2023-08-14 11:23:18', 'Enregistrement de produit ( <b>Anjolie Burks</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (65, 1, 0, '196.74.151.235', '2023-08-14 11:25:04', 'Enregistrement de produit ( <b>Maryam Guzman</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (66, 1, 0, '196.74.151.235', '2023-08-14 11:26:15', 'Enregistrement de produit ( <b>Sloane Olson</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (67, 1, 0, '196.74.151.235', '2023-08-14 11:35:33', 'Enregistrement de client ( <b>Eurofes</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (68, 1, 0, '196.74.151.235', '2023-08-14 11:35:43', 'Modification de client ( <b>Eurofes</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (69, 1, 0, '196.74.151.235', '2023-08-14 11:35:54', 'Suppression de client ( <b>Eurofes</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (70, 1, 0, '196.74.151.235', '2023-08-14 11:40:57', 'Enregistrement de produit ( <b>Eaton Whitaker</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (71, 1, 0, '196.74.145.227', '2023-08-14 11:47:32', 'Enregistrement de produit ( <b>Acton Rose</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (72, 1, 0, '196.74.145.227', '2023-08-14 11:54:13', 'Enregistrement de produit ( <b>Cleo James</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (73, 1, 0, '196.74.145.227', '2023-08-14 11:54:54', 'Enregistrement de produit ( <b>Buckminster Riggs</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (74, 1, 0, '196.74.145.227', '2023-08-14 11:56:18', 'Enregistrement de produit ( <b>Paloma Ayala</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (75, 1, 0, '196.74.145.227', '2023-08-14 11:58:46', 'Enregistrement de produit ( <b>Lacey Medina</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (76, 1, 0, '196.74.145.227', '2023-08-14 12:01:16', 'Enregistrement de produit ( <b>Denise Gilbert</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (77, 1, 0, '196.74.145.227', '2023-08-14 12:05:02', 'Enregistrement de produit ( <b>Liberty Case</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (78, 1, 0, '196.74.145.227', '2023-08-14 12:06:43', 'Enregistrement de produit ( <b>Natalie Ingram</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (79, 1, 0, '196.74.145.227', '2023-08-14 12:08:35', 'Enregistrement de produit ( <b>Christopher Delacruz</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (80, 1, 0, '196.74.145.227', '2023-08-14 12:20:46', 'Enregistrement de produit ( <b>Farrah Goff</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (81, 1, 0, '196.74.145.227', '2023-08-14 12:21:15', 'Enregistrement de service ( <b>Service1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (82, 1, 0, '196.74.145.227', '2023-08-14 12:22:31', 'Enregistrement de client ( <b>Phoebe Ryan</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (83, 1, 0, '196.74.145.227', '2023-08-14 12:23:02', 'Enregistrement de produit ( <b>Katell Noble</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (84, 1, 0, '196.74.145.227', '2023-08-14 12:24:37', 'Enregistrement de produit ( <b>Kitra Powers</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (85, 1, 0, '196.74.145.227', '2023-08-14 12:26:04', 'Enregistrement de service ( <b>Zahira boutmi</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (86, 1, 0, '196.74.145.227', '2023-08-14 12:27:47', 'Enregistrement de service ( <b>SERVICE2</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (87, 1, 0, '196.74.145.227', '2023-08-14 12:31:24', 'Enregistrement de service ( <b>Service4</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (88, 1, 0, '196.74.145.227', '2023-08-14 12:35:09', 'Enregistrement de produit ( <b>Edan George</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (89, 1, 0, '196.74.145.227', '2023-08-14 12:40:10', 'Enregistrement de produit ( <b>Martha Brooks</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (90, 1, 0, '196.74.145.227', '2023-08-14 12:41:15', 'Enregistrement de produit ( <b>Sierra Nicholson</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (91, 1, 0, '196.74.145.227', '2023-08-14 14:23:56', 'Enregistrement de produit ( <b>Glenna Guy</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (92, 1, 0, '196.74.145.227', '2023-08-14 15:20:46', 'Enregistrement de produit ( <b>Tatyana Day</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (93, 1, 0, '196.74.145.227', '2023-08-14 15:27:53', 'Modification de produit ( <b>Tatyana Day</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (94, 1, 0, '196.74.145.227', '2023-08-14 15:29:22', 'Modification de produit ( <b>Tatyana Day</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (95, 1, 0, '196.74.145.227', '2023-08-14 15:46:34', 'Enregistrement de produit ( <b>Priscilla Ortega</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (96, 1, 0, '196.74.145.227', '2023-08-14 15:46:46', 'Modification de produit ( <b>Priscilla Ortega</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (97, 1, 0, '196.74.145.227', '2023-08-14 16:34:20', 'Enregistrement de service ( <b>Listed service</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (98, 1, 0, '196.74.145.227', '2023-08-14 16:44:10', 'Enregistrement de service ( <b>Agence 3</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (99, 1, 0, '196.74.145.227', '2023-08-14 16:58:56', 'Enregistrement de Commercial ( <b>Brennan Jenkins</b> / <b>vofoc</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (100, 1, 0, '196.74.145.227', '2023-08-14 16:59:02', 'Suppression de Commercial ( <b>Brennan Jenkins</b> / <b>vofoc</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (101, 1, 0, '196.74.145.227', '2023-08-14 17:00:03', 'Enregistrement de produit ( <b>Zenia Floyd</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (102, 1, 0, '196.74.145.227', '2023-08-14 17:00:22', 'Modification de produit ( <b>Zenia Floyd</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (103, 1, 0, '196.74.145.227', '2023-08-14 17:08:10', 'Création de produit composé ( <b>ProduiT COMPTOIR</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (104, 1, 0, '196.74.145.227', '2023-08-14 17:12:46', 'Suppression de service ( <b>Agence 3</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (105, 1, 0, '196.74.145.227', '2023-08-14 17:53:08', 'Modification de fournisseur ( <b>Keaton Gould</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (106, 1, 0, '196.74.145.227', '2023-08-14 17:54:58', 'Modification de catégorie ( <b>Shellie Santoss</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (107, 1, 0, '196.74.145.227', '2023-08-14 17:55:09', 'Enregistrement de catégorie ( <b>Abdul Clark</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (108, 1, 0, '196.74.145.227', '2023-08-15 11:01:04', 'Enregistrement de client ( <b>Shay Stokes</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (109, 1, 0, '196.74.145.227', '2023-08-15 11:01:15', 'Modification de client ( <b>Shay Stokes</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (110, 1, 0, '196.74.145.227', '2023-08-15 11:01:41', 'Modification de client ( <b>Shay Stokes</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (111, 1, 0, '196.74.145.227', '2023-08-15 11:02:22', 'Enregistrement de catégorie ( <b>Howard Jacobs</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (112, 1, 0, '196.74.145.227', '2023-08-15 11:02:39', 'Modification de catégorie ( <b>Howard Jacobs</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (113, 1, 0, '196.74.145.227', '2023-08-15 11:02:51', 'Enregistrement de sous-catégorie ( <b>Mechelle Pena</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (114, 1, 0, '196.74.145.227', '2023-08-15 11:05:30', 'Enregistrement de commande de fournisseur ( <b>CF/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (115, 1, 0, '196.74.145.227', '2023-08-15 11:24:45', 'Enregistrement de produit ( <b>Bruce Manning</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (116, 1, 0, '196.74.167.20', '2023-08-15 15:21:31', 'Enregistrement de transport ( <b>TR/23/0000</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (117, 1, 0, '196.74.167.20', '2023-08-15 15:23:37', 'Enregistrement de transport ( <b>TR/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (118, 1, 0, '196.74.167.20', '2023-08-15 15:26:10', 'Enregistrement de transport ( <b>TR/23/0002</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (119, 1, 0, '196.74.167.20', '2023-08-15 15:56:21', 'Enregistrement de transport ( <b>TR/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (120, 1, 0, '196.74.167.20', '2023-08-15 16:05:41', 'Enregistrement de transport ( <b>TR/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (121, 1, 0, '196.74.167.20', '2023-08-15 16:07:52', 'Enregistrement de transport ( <b>TR/23/0000</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (122, 1, 0, '196.74.167.20', '2023-08-15 16:19:04', 'Enregistrement de transport ( <b>TR/23/0000</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (123, 1, 0, '196.74.167.20', '2023-08-15 16:32:00', 'Enregistrement de transport ( <b>TR/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (124, 1, 0, '196.74.167.20', '2023-08-15 16:52:03', 'Enregistrement de transport ( <b>TR/23/0002</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (125, 1, 0, '196.74.167.20', '2023-08-15 16:52:03', 'Enregistrement de transport ( <b>TR/23/0002</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (126, 1, 0, '196.74.167.20', '2023-08-15 16:54:28', 'Enregistrement de transport ( <b>TR/23/0004</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (127, 1, 0, '196.74.167.20', '2023-08-15 17:22:29', 'Modification de transport ( <b>A17/456789</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (128, 1, 0, '196.74.167.20', '2023-08-15 17:22:39', 'Modification de transport ( <b>9999</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (129, 1, 0, '196.74.167.20', '2023-08-15 17:23:37', 'Modification de transport ( <b>A17/456789</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (130, 1, 0, '196.74.167.20', '2023-08-15 17:36:36', 'Suppression de transport ( <b>TR/23/0000</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (131, 1, 0, '196.74.167.20', '2023-08-15 17:55:37', 'Enregistrement d\'achat ( <b>A/23/0010</b> ) avec paiement ( <b>660.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (132, 1, 0, '196.74.167.20', '2023-08-15 18:28:55', 'Enregistrement d\'achat ( <b>A/23/0011</b> ) avec paiement ( <b>300.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (133, 1, 0, '196.74.167.20', '2023-08-16 09:08:23', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (134, 1, 0, '196.74.167.20', '2023-08-16 09:22:59', 'Modification de transport ( <b>A17/456789</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (135, 1, 0, '196.74.167.20', '2023-08-16 09:23:18', 'Suppression de transport ( <b>TR/23/0004</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (136, 1, 0, '196.74.167.20', '2023-08-16 09:56:46', 'Modification d\'achat ( <b>A/23/0011</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (137, 1, 0, '196.74.167.20', '2023-08-16 09:57:29', 'Modification d\'achat ( <b>A/23/0010</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (138, 1, 0, '196.74.167.20', '2023-08-16 09:57:53', 'Modification d\'achat ( <b>A/23/0010</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (139, 1, 0, '196.74.167.20', '2023-08-16 10:27:35', 'Enregistrement d\'entrée de caisse ( <b>20 000.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (140, 1, 0, '196.74.167.20', '2023-08-16 10:27:49', 'Enregistrement de paiement ( <b>66.00</b> DH / <b>Espèce</b> ) \n                            d\'achat ( <b>A/23/0010</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (141, 1, 0, '196.74.167.20', '2023-08-16 10:28:20', 'Modification d\'achat ( <b>A/23/0011</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (142, 1, 0, '196.74.167.20', '2023-08-16 10:28:58', 'Enregistrement d\'achat ( <b>A/23/0012</b> ) avec paiement ( <b>144.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (143, 1, 0, '196.74.167.20', '2023-08-16 10:32:48', 'Enregistrement de vente au comptoir ( <b>BL/23/0002</b> ) avec paiement ( <b>1 200.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (144, 1, 0, '196.74.167.20', '2023-08-16 10:33:14', 'Enregistrement de vente ( <b>BL/23/0003</b> ) avec paiement ( <b>1 200.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (145, 1, 0, '196.74.167.20', '2023-08-16 10:52:00', 'Suppression de vente ( <b>BL/23/0002</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (146, 1, 0, '196.74.167.20', '2023-08-16 10:56:48', 'Enregistrement de vente ( <b>BL/23/0010</b> ) avec paiement ( <b>240.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (147, 1, 0, '196.74.158.189', '2023-08-16 12:13:14', 'Suppression de vente ( <b>BL/23/0004</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (148, 1, 0, '196.74.158.189', '2023-08-16 14:37:14', 'Enregistrement de vente au comptoir ( <b>BL/23/0013</b> ) avec paiement ( <b>1 200.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (149, 1, 0, '196.74.158.189', '2023-08-16 14:46:52', 'Modification de vente ( <b>BL/23/0012</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (150, 1, 0, '196.74.158.189', '2023-08-16 14:49:36', 'Modification de vente ( <b>BL/23/0012</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (151, 1, 0, '196.74.158.189', '2023-08-16 14:49:43', 'Modification de vente ( <b>BL/23/0012</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (152, 1, 0, '196.74.158.189', '2023-08-16 14:52:02', 'Enregistrement de vente ( <b>BL/23/0014</b> ) avec paiement ( <b>180.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (153, 1, 0, '196.74.158.189', '2023-08-16 14:52:17', 'Suppression de vente ( <b>BL/23/0003</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (154, 1, 0, '196.74.158.189', '2023-08-16 14:52:20', 'Suppression de vente ( <b>BL/23/0005</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (155, 1, 0, '196.74.158.189', '2023-08-16 14:52:23', 'Suppression de vente ( <b>BL/23/0006</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (156, 1, 0, '196.74.158.189', '2023-08-16 14:52:27', 'Suppression de vente ( <b>BL/23/0007</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (157, 1, 0, '196.74.158.189', '2023-08-16 14:52:31', 'Suppression de vente ( <b>BL/23/0008</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (158, 1, 0, '196.74.158.189', '2023-08-16 14:52:49', 'Suppression de vente ( <b>BL/23/0009</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (159, 1, 0, '196.74.158.189', '2023-08-16 14:52:53', 'Suppression de vente ( <b>BL/23/0010</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (160, 1, 0, '196.74.158.189', '2023-08-16 14:52:56', 'Suppression de vente ( <b>BL/23/0011</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (161, 1, 0, '196.74.158.189', '2023-08-16 15:09:54', 'Enregistrement de devis ( <b>D/23/0008</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (162, 1, 0, '196.74.158.189', '2023-08-16 15:10:24', 'Suppression de devis ( <b>D/23/0007</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (163, 1, 0, '196.74.158.189', '2023-08-16 15:12:14', 'Enregistrement de devis ( <b>D/23/0009</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (164, 1, 0, '196.74.158.189', '2023-08-16 15:13:00', 'Enregistrement de commande de client ( <b>CC/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (165, 1, 0, '196.74.158.189', '2023-08-16 15:40:24', 'Création de facture ( <b>20230013</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (166, 1, 0, '196.74.158.189', '2023-08-16 15:45:08', 'Création de facture ( <b>20230014</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (167, 1, 0, '196.74.158.189', '2023-08-16 15:47:20', 'Modification de vente ( <b>BL/23/0014</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (168, 1, 0, '196.74.158.189', '2023-08-16 15:47:32', 'Modification de vente ( <b>BL/23/0012</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (169, 1, 0, '196.74.158.189', '2023-08-16 15:48:04', 'Création de facture ( <b>20230015</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (170, 1, 0, '196.74.158.189', '2023-08-16 16:12:09', 'Création de facture ( <b>20230016</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (171, 1, 0, '196.74.158.189', '2023-08-16 16:12:35', 'Création de facture ( <b>20230017</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (172, 1, 0, '196.74.158.189', '2023-08-16 16:26:04', 'Création de facture ( <b>20230019</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (173, 1, 0, '196.74.158.189', '2023-08-16 16:51:08', 'Création de facture ( <b>20230020</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (174, 1, 0, '196.74.158.189', '2023-08-16 16:58:12', 'Création de facture ( <b>20230021</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (175, 1, 0, '196.74.158.189', '2023-08-16 17:01:53', 'Création de facture ( <b>20230022</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (176, 1, 0, '196.74.158.189', '2023-08-16 17:02:53', 'Création de facture ( <b>20230023</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (177, 1, 0, '196.74.158.189', '2023-08-16 17:05:49', 'Création de facture ( <b>20230024</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (178, 1, 0, '196.74.158.189', '2023-08-16 17:09:51', 'Création de facture ( <b>20230025</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (179, 1, 0, '196.74.158.189', '2023-08-16 17:12:52', 'Création de facture ( <b>20230026</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (180, 1, 0, '196.74.158.189', '2023-08-16 17:29:53', 'Création de facture ( <b>20230027</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (181, 1, 0, '196.74.158.189', '2023-08-16 17:36:10', 'Enregistrement de produit endommagé ( <b>Buffy Nielsen</b> | Qte : <b>2</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (182, 1, 0, '196.74.158.189', '2023-08-16 17:42:44', 'Création de facture ( <b>20230028</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (183, 1, 0, '196.74.158.189', '2023-08-16 18:08:31', 'Création de facture ( <b>20230029</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (184, 1, 0, '196.74.158.189', '2023-08-17 09:27:07', 'Modification de commande de client ( <b>CC/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (185, 1, 0, '196.74.158.189', '2023-08-17 09:40:23', 'Modification de client ( <b>Shay Stokes</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (186, 1, 0, '196.74.158.189', '2023-08-17 09:44:36', 'Modification de devis ( <b>D/23/0009</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (187, 1, 0, '196.74.158.189', '2023-08-17 09:47:41', 'Modification de devis ( <b>D/23/0008</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (188, 1, 0, '196.74.158.189', '2023-08-17 10:03:39', 'Enregistrement de devis ( <b>D/23/0010</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (189, 1, 0, '196.74.158.189', '2023-08-17 10:09:21', 'Enregistrement de devis ( <b>D/23/0011</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (190, 1, 0, '196.74.158.189', '2023-08-17 10:16:43', 'Enregistrement de devis ( <b>D/23/0012</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (191, 1, 0, '196.74.158.189', '2023-08-17 10:22:36', 'Modification de devis ( <b>D/23/0012</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (192, 1, 0, '196.74.158.189', '2023-08-17 10:45:23', 'Enregistrement de devis ( <b>D/23/0017</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (193, 1, 0, '196.74.158.189', '2023-08-17 10:45:34', 'Modification de devis ( <b>D/23/0017</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (194, 1, 0, '196.74.158.189', '2023-08-17 10:48:08', 'Suppression de devis ( <b>D/23/0012</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (195, 1, 0, '196.74.158.189', '2023-08-17 10:48:11', 'Suppression de devis ( <b>D/23/0011</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (196, 1, 0, '196.74.158.189', '2023-08-17 10:48:14', 'Suppression de devis ( <b>D/23/0010</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (197, 1, 0, '196.74.158.189', '2023-08-17 10:48:17', 'Suppression de devis ( <b>D/23/0009</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (198, 1, 0, '196.74.158.189', '2023-08-17 10:48:20', 'Suppression de devis ( <b>D/23/0008</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (199, 1, 0, '196.74.158.189', '2023-08-17 10:48:47', 'Modification de devis ( <b>D/23/0017</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (200, 1, 0, '196.74.158.189', '2023-08-17 10:48:52', 'Enregistrement de vente ( <b>BL/23/0015</b> ) avec paiement ( <b>804.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (201, 1, 0, '196.74.158.189', '2023-08-17 10:48:58', 'Modification de catégorie ( <b>Shellie Santoss</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (202, 1, 0, '196.74.158.189', '2023-08-17 10:49:12', 'Modification/Archivage de catégorie ( <b>Shellie Santoss</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (203, 1, 0, '196.74.158.189', '2023-08-17 10:54:43', 'Enregistrement de devis ( <b>D/23/0018</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (204, 1, 0, '196.74.158.189', '2023-08-17 10:54:58', 'Modification de devis ( <b>D/23/0018</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (205, 1, 0, '196.74.158.189', '2023-08-17 10:58:09', 'Création de facture ( <b>20230035</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (206, 1, 0, '196.74.158.189', '2023-08-17 11:00:16', 'Création de facture ( <b>20230036</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (207, 1, 0, '196.74.158.189', '2023-08-17 11:15:44', 'Création de facture ( <b>20230037</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (208, 1, 0, '196.74.158.189', '2023-08-17 11:41:47', 'Modification de commande de client ( <b>CC/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (209, 1, 0, '196.74.158.189', '2023-08-17 11:44:33', 'Modification de fournisseur ( <b>Keaton Gould</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (210, 1, 0, '196.74.158.189', '2023-08-17 11:44:45', 'Modification d\'achat ( <b>A/23/0012</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (211, 1, 0, '196.206.77.183', '2023-08-17 11:48:44', 'Modification de produit endommagé ( <b>Buffy Nielsen</b> | Qte : <b>2</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (212, 1, 0, '196.206.77.183', '2023-08-17 11:48:48', 'Modification de produit endommagé ( <b>Buffy Nielsen</b> | Qte : <b>2</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (213, 1, 0, '196.206.77.183', '2023-08-17 11:50:31', 'Création de facture ( <b>20230038</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (214, 1, 0, '196.206.77.183', '2023-08-17 11:52:24', 'Modification de sous-catégorie ( <b>Mechelle Pena</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (215, 1, 0, '196.206.77.183', '2023-08-17 12:00:06', 'Enregistrement de charge ( <b>100.00</b> DH / <b>Espèce</b> ) : <b>sedfrghnjm</b>');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (216, 1, 0, '196.206.77.183', '2023-08-17 12:17:04', 'Enregistrement de produit ( <b>Darryl </b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (217, 1, 0, '196.206.77.183', '2023-08-17 12:17:15', 'Modification de produit ( <b>Darryl </b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (218, 1, 0, '196.206.77.183', '2023-08-17 12:17:48', 'Modification de produit ( <b>Darryl </b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (219, 1, 0, '197.253.253.185', '2023-08-17 14:56:09', 'Modification/Archivage de produit ( <b>Produit1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (220, 1, 0, '196.206.77.183', '2023-08-18 09:29:54', 'Modification de client ( <b>Shay Stokes</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (221, 1, 0, '196.206.77.183', '2023-08-18 09:30:40', 'Modification de client ( <b>CLIENT COMPTOIRE1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (222, 1, 0, '196.206.77.183', '2023-08-18 09:31:19', 'Modification de client ( <b>CLIENT COMPTOIRE1</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (223, 1, 0, '196.206.77.183', '2023-08-18 09:31:51', 'Modification de catégorie ( <b>Abdul Clark</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (224, 1, 0, '196.206.77.183', '2023-08-18 09:32:18', 'Enregistrement de catégorie ( <b>Categorie 3</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (225, 1, 0, '196.206.77.183', '2023-08-18 09:32:28', 'Modification de catégorie ( <b>Categorie 3</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (226, 1, 0, '196.206.77.183', '2023-08-18 09:35:18', 'Enregistrement de sous-catégorie ( <b>Sous categorie 3</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (227, 1, 0, '196.206.77.183', '2023-08-18 09:36:35', 'Modification/Archivage de produit ( <b>Alea Serrano</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (228, 1, 0, '196.206.77.183', '2023-08-18 09:36:35', 'Modification/Archivage de produit ( <b>Alea Serrano</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (229, 1, 0, '196.206.77.183', '2023-08-18 09:37:22', 'Enregistrement de produit ( <b>Produit 3</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (230, 1, 0, '196.206.77.183', '2023-08-18 09:40:21', 'Enregistrement de service ( <b>Service 3</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (231, 1, 0, '196.206.77.183', '2023-08-18 09:42:53', 'Modification de Commercial ( <b>Demo Access</b> / <b>demo</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (232, 1, 0, '196.206.77.183', '2023-08-18 09:43:21', 'Modification de transport ( <b>A17/456789</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (233, 1, 0, '196.206.77.183', '2023-08-18 09:45:00', 'Enregistrement de fournisseur ( <b>Fournisseur 3</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (234, 1, 0, '196.206.77.183', '2023-08-18 09:47:12', 'Modification de commande de fournisseur ( <b>CF/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (235, 1, 0, '196.206.77.183', '2023-08-18 09:47:40', 'Inventaire - Enregistrement d\'état de produit <b>Darryl </b> \r\n                        ( Qte : <b>0</b> | <b>2.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (236, 1, 0, '196.206.77.183', '2023-08-18 09:47:41', 'Inventaire - Enregistrement d\'état de produit <b>Produit 3</b> \r\n                        ( Qte : <b>0</b> | <b>100.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (237, 1, 0, '196.206.77.183', '2023-08-18 09:47:44', 'Validation d\'inventaire ( <b>IV/23/0003</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (238, 1, 0, '196.206.77.183', '2023-08-18 09:48:22', 'Enregistrement d\'entrée de caisse ( <b>1 000.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (239, 1, 0, '196.206.77.183', '2023-08-18 10:22:06', 'Enregistrement de produit ( <b>Produit 4</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (240, 1, 0, '196.206.77.183', '2023-08-18 10:55:03', 'Modification de devis ( <b>D/23/0017</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (241, 1, 0, '196.206.77.183', '2023-08-18 11:31:03', 'Création de facture ( <b>20230045</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (242, 1, 0, '196.206.77.183', '2023-08-18 11:32:42', 'Création de facture ( <b>20230046</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (243, 1, 0, '196.65.169.61', '2023-08-18 11:49:21', 'Enregistrement de vente ( <b>BL/23/0016</b> ) avec paiement ( <b>2.40</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (244, 1, 0, '196.65.169.61', '2023-08-18 11:54:26', 'Enregistrement de vente ( <b>BL/23/0017</b> ) avec paiement ( <b>1 200.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (245, 1, 0, '196.65.169.61', '2023-08-18 12:29:08', 'Création de facture ( <b>20230052</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (246, 1, 0, '196.65.169.61', '2023-08-18 12:33:23', 'Création de facture ( <b>20230053</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (247, 1, 0, '196.65.169.61', '2023-08-18 17:05:57', 'Enregistrement de vente ( <b>BL/23/0018</b> ) avec paiement ( <b>804.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (248, 1, 0, '196.65.169.61', '2023-08-18 17:06:01', 'Création de facture ( <b>20230054</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (249, 1, 0, '196.65.169.61', '2023-08-18 17:19:13', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (250, 1, 0, '196.65.169.61', '2023-08-19 10:36:37', 'Suppression de vente ( <b>BL/23/0018</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (251, 1, 0, '196.65.169.61', '2023-08-19 10:39:30', 'Modification de vente ( <b>BL/23/0017</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (252, 1, 0, '196.65.169.61', '2023-08-19 10:51:53', 'Création de facture ( <b>20230055</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (253, 1, 0, '196.65.169.61', '2023-08-19 10:52:07', 'Enregistrement de vente ( <b>BL/23/0019</b> ) avec paiement ( <b>180.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (254, 1, 0, '196.65.169.61', '2023-08-19 10:55:15', 'Création de facture ( <b>20230056</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (255, 1, 0, '196.65.169.61', '2023-08-19 11:25:44', 'Modification de produit endommagé ( <b>Buffy Nielsen</b> | Qte : <b>2</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (256, 1, 0, '196.65.169.61', '2023-08-19 11:32:13', 'Modification de produit ( <b>Darryl </b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (257, 1, 0, '105.69.222.57', '2023-08-20 17:03:39', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (258, 1, 0, '196.74.144.48', '2023-08-21 09:21:00', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (259, 1, 0, '196.74.144.48', '2023-08-21 09:31:58', 'Modification de commande de fournisseur ( <b>CF/23/0001</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (260, 1, 0, '196.74.144.48', '2023-08-21 09:35:02', 'Modification de sous-catégorie ( <b>Sous categorie 3</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (261, 1, 0, '196.74.144.48', '2023-08-21 09:36:59', 'Enregistrement de catégorie ( <b>Catégorie 4</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (262, 1, 0, '196.74.144.48', '2023-08-21 09:37:16', 'Enregistrement de sous-catégorie ( <b>Sous-Catégorie 4</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (263, 1, 0, '196.74.144.48', '2023-08-21 09:37:57', 'Enregistrement de produit ( <b>Produit4</b> ) avec image');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (264, 1, 0, '196.74.144.48', '2023-08-21 09:39:11', 'Enregistrement de fournisseur ( <b>Mahmoud</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (265, 1, 0, '196.74.144.48', '2023-08-21 09:39:27', 'Modification de fournisseur ( <b>Mahmoud</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (266, 1, 0, '196.74.144.48', '2023-08-21 09:41:27', 'Modification de produit ( <b>Produit 4</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (267, 1, 0, '196.74.144.48', '2023-08-21 09:42:06', 'Suppression de produit ( <b>Produit4</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (268, 1, 0, '196.74.144.48', '2023-08-21 09:42:57', 'Enregistrement d\'achat ( <b>A/23/0013</b> ) avec paiement ( <b>90.00</b> DH / <b>Espèce</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (269, 1, 0, '196.74.144.48', '2023-08-21 09:44:18', 'Inventaire - Enregistrement d\'état de produit <b>Produit 4</b> \r\n                        ( Qte : <b>0</b> | <b>9.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (270, 1, 0, '196.74.144.48', '2023-08-21 09:44:20', 'Inventaire - Enregistrement d\'état de produit <b>Produit 3</b> \r\n                        ( Qte : <b>0</b> | <b>100.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (271, 1, 0, '196.74.144.48', '2023-08-21 09:44:21', 'Inventaire - Enregistrement d\'état de produit <b>Darryl </b> \r\n                        ( Qte : <b>0</b> | <b>2.00</b> DH )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (272, 1, 0, '196.74.144.48', '2023-08-21 09:44:24', 'Validation d\'inventaire ( <b>IV/23/0004</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (273, 1, 0, '196.74.144.48', '2023-08-21 09:45:02', 'Enregistrement de produit endommagé ( <b>Produit 4</b> | Qte : <b>2</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (274, 1, 0, '196.74.144.48', '2023-08-21 10:49:09', 'Modification de sous-catégorie ( <b>Mechelle Pena</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (275, 1, 0, '196.74.144.48', '2023-08-21 11:14:19', 'Création de facture ( <b>20230057</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (276, 1, 0, '196.74.144.48', '2023-08-21 11:21:45', 'Enregistrement de commande de client ( <b>CC/23/0002</b> )');


#
# TABLE STRUCTURE FOR: vente
#

DROP TABLE IF EXISTS `vente`;

CREATE TABLE `vente` (
  `id_vente` int(11) NOT NULL AUTO_INCREMENT,
  `id_client_cmd` int(11) DEFAULT NULL,
  `id_devis` int(11) DEFAULT NULL,
  `code_vente` varchar(200) NOT NULL,
  `num_facture` varchar(200) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `tva` double NOT NULL DEFAULT '20',
  `date_vente` date NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  `id_transport` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_vente`),
  UNIQUE KEY `code_vente` (`code_vente`),
  UNIQUE KEY `num_facture` (`num_facture`),
  KEY `id_user` (`id_user`),
  KEY `id_client` (`id_client`),
  KEY `id_client_cmd` (`id_client_cmd`),
  KEY `id_devis` (`id_devis`),
  KEY `id_transport` (`id_transport`),
  CONSTRAINT `vente_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `vente_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `vente_ibfk_3` FOREIGN KEY (`id_client_cmd`) REFERENCES `client_cmd` (`id_client_cmd`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `vente_ibfk_4` FOREIGN KEY (`id_devis`) REFERENCES `devis` (`id_devis`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `vente_ibfk_5` FOREIGN KEY (`id_transport`) REFERENCES `transport` (`id_transport`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `vente` (`id_vente`, `id_client_cmd`, `id_devis`, `code_vente`, `num_facture`, `id_user`, `id_client`, `remarque`, `tva`, `date_vente`, `date_create`, `date_update`, `id_transport`) VALUES (11, NULL, NULL, 'BL/23/0012', '20230053', 1, 7, '', '20', '2023-08-16', '2023-08-16 04:56:48', '2023-08-18 06:33:23', 9);
INSERT INTO `vente` (`id_vente`, `id_client_cmd`, `id_devis`, `code_vente`, `num_facture`, `id_user`, `id_client`, `remarque`, `tva`, `date_vente`, `date_create`, `date_update`, `id_transport`) VALUES (12, NULL, NULL, 'BL/23/0013', NULL, 1, 1, '', '20', '2023-08-16', '2023-08-16 08:37:14', NULL, NULL);
INSERT INTO `vente` (`id_vente`, `id_client_cmd`, `id_devis`, `code_vente`, `num_facture`, `id_user`, `id_client`, `remarque`, `tva`, `date_vente`, `date_create`, `date_update`, `id_transport`) VALUES (13, NULL, NULL, 'BL/23/0014', '20230045', 1, 4, '', '20', '2023-08-16', '2023-08-16 08:52:02', '2023-08-18 05:31:03', 8);
INSERT INTO `vente` (`id_vente`, `id_client_cmd`, `id_devis`, `code_vente`, `num_facture`, `id_user`, `id_client`, `remarque`, `tva`, `date_vente`, `date_create`, `date_update`, `id_transport`) VALUES (14, NULL, 7, 'BL/23/0015', '20230055', 1, 5, '', '20', '2023-08-17', '2023-08-17 04:48:52', '2023-08-19 04:51:53', NULL);
INSERT INTO `vente` (`id_vente`, `id_client_cmd`, `id_devis`, `code_vente`, `num_facture`, `id_user`, `id_client`, `remarque`, `tva`, `date_vente`, `date_create`, `date_update`, `id_transport`) VALUES (15, 1, NULL, 'BL/23/0016', NULL, 1, 4, '', '20', '2023-08-18', '2023-08-18 05:49:21', NULL, NULL);
INSERT INTO `vente` (`id_vente`, `id_client_cmd`, `id_devis`, `code_vente`, `num_facture`, `id_user`, `id_client`, `remarque`, `tva`, `date_vente`, `date_create`, `date_update`, `id_transport`) VALUES (16, NULL, NULL, 'BL/23/0017', '20230057', 1, 8, '', '20', '2023-08-18', '2023-08-18 05:54:26', '2023-08-21 05:14:19', NULL);
INSERT INTO `vente` (`id_vente`, `id_client_cmd`, `id_devis`, `code_vente`, `num_facture`, `id_user`, `id_client`, `remarque`, `tva`, `date_vente`, `date_create`, `date_update`, `id_transport`) VALUES (18, NULL, NULL, 'BL/23/0019', '20230056', 1, 4, '', '20', '2023-08-19', '2023-08-19 04:52:07', '2023-08-19 04:55:15', 9);


#
# TABLE STRUCTURE FOR: vente_details
#

DROP TABLE IF EXISTS `vente_details`;

CREATE TABLE `vente_details` (
  `id_vente_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_vente` int(11) DEFAULT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '1',
  `remise` double NOT NULL DEFAULT '0',
  `remise_dh` decimal(10,2) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  `id_service` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_vente_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_vente` (`id_vente`),
  KEY `fk_ventes_details_id_service` (`id_service`),
  CONSTRAINT `fk_ventes_details_id_service` FOREIGN KEY (`id_service`) REFERENCES `service` (`id_service`),
  CONSTRAINT `vente_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `vente_details_ibfk_2` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `vente_details` (`id_vente_details`, `id_vente`, `id_produit`, `quantite`, `prix_vente`, `remise`, `remise_dh`, `date_create`, `date_update`, `id_service`) VALUES (4, 12, NULL, '1', '1000', '0', '0.00', '2023-08-16 08:37:14', NULL, 5);
INSERT INTO `vente_details` (`id_vente_details`, `id_vente`, `id_produit`, `quantite`, `prix_vente`, `remise`, `remise_dh`, `date_create`, `date_update`, `id_service`) VALUES (9, 13, NULL, '1', '1000', '85', '0.00', '2023-08-16 09:47:20', NULL, 5);
INSERT INTO `vente_details` (`id_vente_details`, `id_vente`, `id_produit`, `quantite`, `prix_vente`, `remise`, `remise_dh`, `date_create`, `date_update`, `id_service`) VALUES (10, 11, NULL, '1', '1000', '8', '0.00', '2023-08-16 09:47:32', NULL, 5);
INSERT INTO `vente_details` (`id_vente_details`, `id_vente`, `id_produit`, `quantite`, `prix_vente`, `remise`, `remise_dh`, `date_create`, `date_update`, `id_service`) VALUES (11, 14, NULL, '1', '1000', '33', NULL, '2023-08-17 04:48:52', NULL, 5);
INSERT INTO `vente_details` (`id_vente_details`, `id_vente`, `id_produit`, `quantite`, `prix_vente`, `remise`, `remise_dh`, `date_create`, `date_update`, `id_service`) VALUES (12, 15, 1, '1', '2', '0', '0.00', '2023-08-18 05:49:21', NULL, NULL);
INSERT INTO `vente_details` (`id_vente_details`, `id_vente`, `id_produit`, `quantite`, `prix_vente`, `remise`, `remise_dh`, `date_create`, `date_update`, `id_service`) VALUES (15, 16, NULL, '1', '1000', '0', '0.00', '2023-08-19 04:39:30', NULL, 7);
INSERT INTO `vente_details` (`id_vente_details`, `id_vente`, `id_produit`, `quantite`, `prix_vente`, `remise`, `remise_dh`, `date_create`, `date_update`, `id_service`) VALUES (16, 18, NULL, '1', '1000', '85', NULL, '2023-08-19 04:52:07', NULL, 7);


