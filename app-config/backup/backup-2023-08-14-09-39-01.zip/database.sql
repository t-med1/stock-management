#
# TABLE STRUCTURE FOR: achat
#

DROP TABLE IF EXISTS `achat`;

CREATE TABLE `achat` (
  `id_achat` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_fournisseur` int(11) DEFAULT NULL,
  `id_commande` int(11) DEFAULT NULL,
  `code_achat` varchar(200) NOT NULL,
  `num_facture` varchar(200) DEFAULT NULL,
  `date_achat` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `tva` double NOT NULL DEFAULT '20',
  `frais` double NOT NULL DEFAULT '0',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_achat`),
  UNIQUE KEY `code_achat` (`code_achat`),
  KEY `id_fournisseur` (`id_fournisseur`),
  KEY `id_user` (`id_user`),
  KEY `id_commande` (`id_commande`),
  CONSTRAINT `achat_ibfk_1` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseur` (`id_fournisseur`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `achat_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `achat_ibfk_3` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: achat_details
#

DROP TABLE IF EXISTS `achat_details`;

CREATE TABLE `achat_details` (
  `id_achat_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_achat` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_achat` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_achat_details`),
  KEY `id_achat` (`id_achat`),
  KEY `achat_details_ibfk_1` (`id_produit`),
  CONSTRAINT `achat_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `achat_details_ibfk_2` FOREIGN KEY (`id_achat`) REFERENCES `achat` (`id_achat`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: adresse
#

DROP TABLE IF EXISTS `adresse`;

CREATE TABLE `adresse` (
  `id_adresse` int(11) NOT NULL AUTO_INCREMENT,
  `id_commande` int(11) DEFAULT NULL,
  `id_achat` int(11) DEFAULT NULL,
  `id_client_cmd` int(11) DEFAULT NULL,
  `id_devis` int(11) DEFAULT NULL,
  `id_vente` int(11) DEFAULT NULL,
  `id_avoir` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `id_fournisseur` int(11) DEFAULT NULL,
  `ice` varchar(200) DEFAULT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `adresse` varchar(200) DEFAULT NULL,
  `ville` varchar(200) DEFAULT NULL,
  `pays` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_adresse`),
  KEY `id_commande` (`id_commande`),
  KEY `id_achat` (`id_achat`),
  KEY `id_vente` (`id_vente`),
  KEY `id_avoir` (`id_avoir`),
  KEY `id_client` (`id_client`),
  KEY `id_fournisseur` (`id_fournisseur`),
  KEY `id_client_cmd` (`id_client_cmd`),
  KEY `id_devis` (`id_devis`),
  CONSTRAINT `adresse_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_2` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_3` FOREIGN KEY (`id_achat`) REFERENCES `achat` (`id_achat`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_4` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_5` FOREIGN KEY (`id_avoir`) REFERENCES `avoir` (`id_avoir`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_6` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseur` (`id_fournisseur`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_7` FOREIGN KEY (`id_client_cmd`) REFERENCES `client_cmd` (`id_client_cmd`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `adresse_ibfk_8` FOREIGN KEY (`id_devis`) REFERENCES `devis` (`id_devis`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: auto_code
#

DROP TABLE IF EXISTS `auto_code`;

CREATE TABLE `auto_code` (
  `reference` varchar(200) NOT NULL,
  `year` int(11) NOT NULL DEFAULT '2000',
  `next_value` int(11) NOT NULL DEFAULT '1',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`reference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('A', 2021, 1, NULL, NULL);
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('BA', 2023, 1, NULL, '2023-08-14 03:34:08');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('BL', 2023, 1, NULL, '2023-08-14 03:33:37');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('C', 2023, 2, NULL, '2023-08-14 03:29:29');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('CC', 2021, 1, NULL, NULL);
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('CF', 2021, 1, NULL, NULL);
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('D', 2021, 1, NULL, NULL);
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('DM', 2023, 1, NULL, '2023-08-14 03:33:16');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('F', 2023, 2, NULL, '2023-08-14 03:34:57');
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('INVOICE', 2021, 1, NULL, NULL);
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('IV', 2021, 1, NULL, NULL);
INSERT INTO `auto_code` (`reference`, `year`, `next_value`, `date_create`, `date_update`) VALUES ('PD', 2021, 1, NULL, NULL);


#
# TABLE STRUCTURE FOR: avance
#

DROP TABLE IF EXISTS `avance`;

CREATE TABLE `avance` (
  `id_avance` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `date_avance` date NOT NULL,
  `montant` double NOT NULL,
  `methode` int(11) NOT NULL COMMENT '1=Espece, 2=Cheque, 3=Effet, 4=Virement',
  `description` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avance`),
  KEY `id_client` (`id_client`,`id_user`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `avance_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avance_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: avance_retour
#

DROP TABLE IF EXISTS `avance_retour`;

CREATE TABLE `avance_retour` (
  `id_avance_retour` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `date_retour` date NOT NULL,
  `montant` double NOT NULL,
  `methode` int(11) NOT NULL COMMENT '1=Espece, 2=Cheque, 3=Effet, 4=Virement, 5=From Avance',
  `type_avance` tinyint(4) DEFAULT NULL COMMENT '1=Espece, 2=Cheque/Effet, 3=Virement',
  `description` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avance_retour`),
  KEY `id_client` (`id_client`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `avance_retour_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avance_retour_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: avoir
#

DROP TABLE IF EXISTS `avoir`;

CREATE TABLE `avoir` (
  `id_avoir` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_vente` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `code_avoir` varchar(200) NOT NULL,
  `date_avoir` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `tva` double NOT NULL DEFAULT '20',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avoir`),
  UNIQUE KEY `code_avoir` (`code_avoir`),
  KEY `id_user` (`id_user`),
  KEY `id_client` (`id_client`),
  KEY `avoir_ibfk_3` (`id_vente`),
  CONSTRAINT `avoir_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avoir_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avoir_ibfk_3` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: avoir_details_in
#

DROP TABLE IF EXISTS `avoir_details_in`;

CREATE TABLE `avoir_details_in` (
  `id_avoir_details_in` int(11) NOT NULL AUTO_INCREMENT,
  `id_avoir` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '0',
  `remise` double NOT NULL DEFAULT '0',
  `remise_dh` double NOT NULL DEFAULT '0',
  `etat` int(11) NOT NULL COMMENT '1=GOOD, 0=BROKEN',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avoir_details_in`),
  KEY `id_produit` (`id_produit`),
  KEY `id_avoir` (`id_avoir`),
  CONSTRAINT `avoir_details_in_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avoir_details_in_ibfk_2` FOREIGN KEY (`id_avoir`) REFERENCES `avoir` (`id_avoir`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: avoir_details_out
#

DROP TABLE IF EXISTS `avoir_details_out`;

CREATE TABLE `avoir_details_out` (
  `id_avoir_details_out` int(11) NOT NULL AUTO_INCREMENT,
  `id_avoir` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '0',
  `remise` double NOT NULL DEFAULT '0',
  `remise_dh` double NOT NULL DEFAULT '0',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_avoir_details_out`),
  KEY `id_produit` (`id_produit`),
  KEY `id_avoir` (`id_avoir`),
  CONSTRAINT `avoir_details_out_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `avoir_details_out_ibfk_2` FOREIGN KEY (`id_avoir`) REFERENCES `avoir` (`id_avoir`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: caisse_entree
#

DROP TABLE IF EXISTS `caisse_entree`;

CREATE TABLE `caisse_entree` (
  `id_caisse_entree` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `montant` double NOT NULL,
  `date_entree` date NOT NULL,
  `description` varchar(200) NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_caisse_entree`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `caisse_entree_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: caisse_sortie
#

DROP TABLE IF EXISTS `caisse_sortie`;

CREATE TABLE `caisse_sortie` (
  `id_caisse_sortie` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `montant` double NOT NULL,
  `date_sortie` date NOT NULL,
  `description` varchar(200) NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_caisse_sortie`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `caisse_sortie_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: categorie
#

DROP TABLE IF EXISTS `categorie`;

CREATE TABLE `categorie` (
  `id_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `categorie` (`id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (1, 'Shellie Santoss', 'Irure deserunt consequuntur sint et facere qui blanditiis aliquip sint veniam fugit in nostrum nesciunt deserunt velit omnis esse in', 1, '2023-08-14 03:31:56', '2023-08-14 03:32:29');


#
# TABLE STRUCTURE FOR: charge
#

DROP TABLE IF EXISTS `charge`;

CREATE TABLE `charge` (
  `id_charge` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `date_charge` date NOT NULL,
  `montant` double NOT NULL,
  `methode` int(11) NOT NULL COMMENT '1=Espece, 2=Cheque, 3=Effet, 4=Virement',
  `description` varchar(200) NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_charge`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `charge_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: cheque
#

DROP TABLE IF EXISTS `cheque`;

CREATE TABLE `cheque` (
  `id_cheque` int(11) NOT NULL AUTO_INCREMENT,
  `id_paiement` int(11) DEFAULT NULL,
  `id_charge` int(11) DEFAULT NULL,
  `id_avance` int(11) DEFAULT NULL,
  `id_avance_retour` int(11) DEFAULT NULL,
  `date_cheque` date NOT NULL,
  `montant` double NOT NULL,
  `reference` varchar(200) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1=Vente, 2=Achat, 3=Reglement, 4=Charge, 5=Avance, 6=Retour d''Avance',
  `methode` tinyint(4) NOT NULL COMMENT '2=Cheque, 3=Effet',
  `remarque` varchar(200) DEFAULT NULL,
  `paid` tinyint(4) NOT NULL DEFAULT '0' COMMENT ' 0=Not Yet, 1=Paid, 2=Unpaid',
  `caisse` tinyint(4) DEFAULT NULL COMMENT '0=Bank, 1=Caisse',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cheque`),
  KEY `id_paiement` (`id_paiement`),
  KEY `id_charge` (`id_charge`),
  KEY `id_avance` (`id_avance`),
  KEY `id_avance_retour` (`id_avance_retour`),
  CONSTRAINT `cheque_ibfk_1` FOREIGN KEY (`id_paiement`) REFERENCES `paiement` (`id_paiement`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cheque_ibfk_2` FOREIGN KEY (`id_charge`) REFERENCES `charge` (`id_charge`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cheque_ibfk_3` FOREIGN KEY (`id_avance`) REFERENCES `avance` (`id_avance`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cheque_ibfk_4` FOREIGN KEY (`id_avance_retour`) REFERENCES `avance_retour` (`id_avance_retour`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01763803da4096da74fcd74da5214d74d2752a24', '196.74.151.235', 1692002336, '__ci_last_regenerate|i:1692002173;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:36\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0abc20e1ffda311ead55743566e1095dc19f6a28', '196.74.151.235', 1692002298, '__ci_last_regenerate|i:1692002298;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1035d310e954e3038822e2e32a8d2aecb8ae2c7a', '196.74.151.235', 1692001698, '__ci_last_regenerate|i:1692001698;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10d113124bce45a523db91c3cd2568575048ac22', '196.74.151.235', 1692002321, '__ci_last_regenerate|i:1692002298;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3b43446f161a7f6b81cefa433493d5ae4f62ad8e', '196.89.134.245', 1691841416, '__ci_last_regenerate|i:1691841340;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 12:56\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('70e0dd2a5bc914b4a2611b147b94721ea36a191a', '105.69.240.198', 1692001649, '__ci_last_regenerate|i:1692001649;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('84c3bc3f4442e97061b87eb4d5d54540b2220abd', '105.69.240.198', 1691924358, '__ci_last_regenerate|i:1691924358;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93519002125100fdcb7f5d7f354a55d3e847fc09', '196.89.134.245', 1691923277, '__ci_last_regenerate|i:1691923277;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('982c2ea7b6139e31e94fdc0e4039987ffa4faed2', '196.89.134.245', 1691841253, '__ci_last_regenerate|i:1691841253;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 12:49\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b08a84c069ed213f804485180ee80fa6d1338f2a', '105.69.240.198', 1692001698, '__ci_last_regenerate|i:1692001698;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d246f649dbfe359b51283207120b2b85178f5505', '196.74.151.235', 1692001960, '__ci_last_regenerate|i:1692001960;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"12/08/2023 13:00\";message|a:2:{s:5:\"title\";s:8:\"Succès!\";s:7:\"message\";s:33:\"Catégorie modifié avec succès.\";}__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7e3add2f60f38c3e68b5309e8df9d24d9c3cf88', '196.74.151.235', 1692002042, '__ci_last_regenerate|i:1692002042;STE|s:21:\"FES MARKETING SERVICE\";login|b:1;id_user|s:1:\"1\";name_user|s:3:\"FMS\";role_user|s:1:\"1\";last_login|s:16:\"14/08/2023 09:29\";');


#
# TABLE STRUCTURE FOR: client
#

DROP TABLE IF EXISTS `client`;

CREATE TABLE `client` (
  `id_client` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `code_client` varchar(200) NOT NULL,
  `ice` varchar(200) DEFAULT NULL,
  `full_name` varchar(200) NOT NULL,
  `responsable` varchar(200) DEFAULT NULL,
  `adresse` varchar(200) DEFAULT NULL,
  `ville` varchar(200) NOT NULL,
  `pays` varchar(200) NOT NULL,
  `remise` double NOT NULL DEFAULT '0',
  `telephone` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_client`),
  UNIQUE KEY `code_client` (`code_client`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `client_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `client` (`id_client`, `id_user`, `code_client`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `remise`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (1, 2, 'C/21/0001', '', 'CLIENT COMPTOIRE', '', '', 'Fes', 'Maroc', '0', '', '', '', 1, NULL, NULL);


#
# TABLE STRUCTURE FOR: client_cmd
#

DROP TABLE IF EXISTS `client_cmd`;

CREATE TABLE `client_cmd` (
  `id_client_cmd` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `code_client_cmd` varchar(200) NOT NULL,
  `date_client_cmd` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_client_cmd`),
  UNIQUE KEY `code_client_cmd` (`code_client_cmd`),
  KEY `id_client` (`id_client`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `client_cmd_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `client_cmd_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: client_cmd_details
#

DROP TABLE IF EXISTS `client_cmd_details`;

CREATE TABLE `client_cmd_details` (
  `id_client_cmd_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_client_cmd` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_client_cmd_details`),
  KEY `id_client_cmd` (`id_client_cmd`),
  KEY `id_produit` (`id_produit`),
  CONSTRAINT `client_cmd_details_ibfk_1` FOREIGN KEY (`id_client_cmd`) REFERENCES `client_cmd` (`id_client_cmd`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_cmd_details_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: commande
#

DROP TABLE IF EXISTS `commande`;

CREATE TABLE `commande` (
  `id_commande` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_fournisseur` int(11) DEFAULT NULL,
  `code_commande` varchar(200) NOT NULL,
  `date_commande` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_commande`),
  UNIQUE KEY `code_commande` (`code_commande`),
  KEY `id_fournisseur` (`id_fournisseur`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`id_fournisseur`) REFERENCES `fournisseur` (`id_fournisseur`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: commande_details
#

DROP TABLE IF EXISTS `commande_details`;

CREATE TABLE `commande_details` (
  `id_commande_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_commande` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_achat` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_commande_details`),
  KEY `id_produit` (`id_produit`),
  KEY `commande_details_ibfk_1` (`id_commande`),
  CONSTRAINT `commande_details_ibfk_1` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `commande_details_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: demontage
#

DROP TABLE IF EXISTS `demontage`;

CREATE TABLE `demontage` (
  `id_demontage` int(11) NOT NULL AUTO_INCREMENT,
  `id_produit` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `code_demontage` varchar(200) NOT NULL,
  `quantite` double NOT NULL,
  `frais` double NOT NULL DEFAULT '0',
  `date_demontage` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_demontage`),
  UNIQUE KEY `code_demontage` (`code_demontage`),
  KEY `id_produit` (`id_produit`),
  CONSTRAINT `demontage_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: demontage_details
#

DROP TABLE IF EXISTS `demontage_details`;

CREATE TABLE `demontage_details` (
  `id_demontage_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_demontage` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_demontage_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_demontage` (`id_demontage`),
  CONSTRAINT `demontage_details_ibfk_1` FOREIGN KEY (`id_demontage`) REFERENCES `demontage` (`id_demontage`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `demontage_details_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: devis
#

DROP TABLE IF EXISTS `devis`;

CREATE TABLE `devis` (
  `id_devis` int(11) NOT NULL AUTO_INCREMENT,
  `code_devis` varchar(200) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `tva` double NOT NULL DEFAULT '20',
  `date_devis` date NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_devis`),
  UNIQUE KEY `code_devis` (`code_devis`),
  KEY `id_user` (`id_user`),
  KEY `id_client` (`id_client`),
  CONSTRAINT `devis_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `devis_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: devis_details
#

DROP TABLE IF EXISTS `devis_details`;

CREATE TABLE `devis_details` (
  `id_devis_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_devis` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '1',
  `remise` double NOT NULL DEFAULT '0',
  `remise_dh` double NOT NULL DEFAULT '0',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_devis_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_devis` (`id_devis`),
  CONSTRAINT `devis_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `devis_details_ibfk_2` FOREIGN KEY (`id_devis`) REFERENCES `devis` (`id_devis`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: exoneration_reste
#

DROP TABLE IF EXISTS `exoneration_reste`;

CREATE TABLE `exoneration_reste` (
  `id_exoneration_reste` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_achat` int(11) DEFAULT NULL,
  `id_vente` int(11) DEFAULT NULL,
  `montant` double NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1=Vente, 2=Achat, 3=Reglement',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_exoneration_reste`),
  KEY `id_user` (`id_user`),
  KEY `id_achat` (`id_achat`),
  KEY `id_vente` (`id_vente`),
  CONSTRAINT `exoneration_reste_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `exoneration_reste_ibfk_2` FOREIGN KEY (`id_achat`) REFERENCES `achat` (`id_achat`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `exoneration_reste_ibfk_3` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: fournisseur
#

DROP TABLE IF EXISTS `fournisseur`;

CREATE TABLE `fournisseur` (
  `id_fournisseur` int(11) NOT NULL AUTO_INCREMENT,
  `code_fournisseur` varchar(200) NOT NULL,
  `ice` varchar(200) DEFAULT NULL,
  `full_name` varchar(200) NOT NULL,
  `responsable` varchar(200) DEFAULT NULL,
  `adresse` varchar(200) DEFAULT NULL,
  `ville` varchar(200) NOT NULL,
  `pays` varchar(200) NOT NULL,
  `telephone` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_fournisseur`),
  UNIQUE KEY `code_fournisseur` (`code_fournisseur`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `fournisseur` (`id_fournisseur`, `code_fournisseur`, `ice`, `full_name`, `responsable`, `adresse`, `ville`, `pays`, `telephone`, `email`, `description`, `display`, `date_create`, `date_update`) VALUES (1, 'F/23/0001', 'Est nostrum accusant', 'Keaton Gould', 'Possimus qui verita', 'Eligendi deleniti al', 'Lorem perspiciatis ', 'Liban', '+1 (232) 963-3323', 'hitugato@mailinator.com', 'Illo consequatur ea aut sequi molestias adipisicing cumque vel ad distinctio Nisi quibusdam aliquam provident nisi', 1, '2023-08-14 03:34:57', NULL);


#
# TABLE STRUCTURE FOR: information
#

DROP TABLE IF EXISTS `information`;

CREATE TABLE `information` (
  `id_information` int(11) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `adresse` varchar(200) NOT NULL,
  `ville` varchar(200) NOT NULL,
  `pays` varchar(200) NOT NULL,
  `telephone` varchar(200) NOT NULL,
  `fix` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `web` varchar(200) DEFAULT NULL,
  `num_rc` varchar(200) DEFAULT NULL,
  `num_patente` varchar(200) DEFAULT NULL,
  `num_if` varchar(200) DEFAULT NULL,
  `num_cnss` varchar(200) DEFAULT NULL,
  `num_ice` varchar(200) DEFAULT NULL,
  `num_rib` varchar(200) DEFAULT NULL,
  `bank` varchar(200) DEFAULT NULL,
  `print_message` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_information`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `information` (`id_information`, `full_name`, `adresse`, `ville`, `pays`, `telephone`, `fix`, `email`, `web`, `num_rc`, `num_patente`, `num_if`, `num_cnss`, `num_ice`, `num_rib`, `bank`, `print_message`, `date_create`, `date_update`) VALUES (1, 'FES MARKETING SERVICE', 'Bureau 206 – 2éme étage Bureaux NOUR Angle AV. Slaoui', 'FES', 'Maroc', '+212 6 61 52 57 40', '+212 5 35 64 51 03', 'commercial@fes-marketing.net', 'www.fes-marketing.net', '150', '13230000', '40043427', '8850000', '201540002500000', '127 270 21212 00000000000 00', 'Al Barid Bank', '', NULL, NULL);


#
# TABLE STRUCTURE FOR: inventaire
#

DROP TABLE IF EXISTS `inventaire`;

CREATE TABLE `inventaire` (
  `id_inventaire` int(11) NOT NULL AUTO_INCREMENT,
  `code_inventaire` varchar(200) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `date_inventaire` date NOT NULL,
  `valide` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=Valide, 0=Not',
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_inventaire`),
  UNIQUE KEY `code_inventaire` (`code_inventaire`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `inventaire_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: inventaire_details
#

DROP TABLE IF EXISTS `inventaire_details`;

CREATE TABLE `inventaire_details` (
  `id_inventaire_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_inventaire` int(11) DEFAULT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL COMMENT '1=Entree, 2=Srotie',
  `quantite` int(11) NOT NULL,
  `prix` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_inventaire_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_inventaire` (`id_inventaire`) USING BTREE,
  CONSTRAINT `inventaire_details_ibfk_1` FOREIGN KEY (`id_inventaire`) REFERENCES `inventaire` (`id_inventaire`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `inventaire_details_ibfk_2` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: paiement
#

DROP TABLE IF EXISTS `paiement`;

CREATE TABLE `paiement` (
  `id_paiement` int(11) NOT NULL AUTO_INCREMENT,
  `id_vente` int(11) DEFAULT NULL,
  `id_avoir` int(44) DEFAULT NULL,
  `id_achat` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `montant` double NOT NULL,
  `date_paiement` date NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1=Vente, 2=Achat, 3=Reglement',
  `methode` int(11) NOT NULL COMMENT '1=Espece, 2=Cheque, 3=Effet, 4=Virement, 5=From Avance',
  `type_avance` tinyint(4) DEFAULT NULL COMMENT '1=Espece, 2=Cheque/Effet, 3=Virement',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_paiement`),
  KEY `id_user` (`id_user`),
  KEY `id_vente` (`id_vente`) USING BTREE,
  KEY `id_achat` (`id_achat`),
  KEY `id_avoir` (`id_avoir`),
  CONSTRAINT `paiement_ibfk_1` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `paiement_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `paiement_ibfk_3` FOREIGN KEY (`id_achat`) REFERENCES `achat` (`id_achat`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `paiement_ibfk_4` FOREIGN KEY (`id_avoir`) REFERENCES `avoir` (`id_avoir`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: production
#

DROP TABLE IF EXISTS `production`;

CREATE TABLE `production` (
  `id_production` int(11) NOT NULL AUTO_INCREMENT,
  `id_produit` int(11) DEFAULT NULL,
  `code_production` varchar(200) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `frais` double NOT NULL DEFAULT '0',
  `date_production` date NOT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_production`),
  UNIQUE KEY `code_production` (`code_production`),
  KEY `id_produit` (`id_produit`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `production_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: production_details
#

DROP TABLE IF EXISTS `production_details`;

CREATE TABLE `production_details` (
  `id_production_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_production` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_production_details`),
  KEY `id_production` (`id_production`),
  KEY `id_produit` (`id_produit`),
  CONSTRAINT `production_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `production_details_ibfk_2` FOREIGN KEY (`id_production`) REFERENCES `production` (`id_production`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: produit
#

DROP TABLE IF EXISTS `produit`;

CREATE TABLE `produit` (
  `id_produit` int(11) NOT NULL AUTO_INCREMENT,
  `id_categorie` int(11) DEFAULT NULL,
  `id_sub_categorie` int(11) DEFAULT NULL,
  `code_produit` varchar(200) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `prix_achat` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '1',
  `alert` int(11) NOT NULL,
  `image` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=Normal, 1=Composé',
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_produit`),
  UNIQUE KEY `code_produit` (`code_produit`),
  KEY `id_categorie` (`id_categorie`),
  KEY `id_sub_categorie` (`id_sub_categorie`),
  CONSTRAINT `produit_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categorie` (`id_categorie`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `produit_ibfk_2` FOREIGN KEY (`id_sub_categorie`) REFERENCES `sub_categorie` (`id_sub_categorie`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `produit` (`id_produit`, `id_categorie`, `id_sub_categorie`, `code_produit`, `full_name`, `prix_achat`, `prix_vente`, `alert`, `image`, `description`, `type`, `display`, `date_create`, `date_update`) VALUES (1, 1, 1, 'Rerum aut dolorem eu', 'Alea Serrano', '66', '2', 19, 'Rerum aut dolorem eu.jpg', 'Nesciunt velit adipisci sed repellendus Quos hic id', 0, 1, '2023-08-14 03:32:49', NULL);


#
# TABLE STRUCTURE FOR: produit_details
#

DROP TABLE IF EXISTS `produit_details`;

CREATE TABLE `produit_details` (
  `id_produit_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_produit_compose` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_produit_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_produit_compose` (`id_produit_compose`),
  CONSTRAINT `produit_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `produit_details_ibfk_2` FOREIGN KEY (`id_produit_compose`) REFERENCES `produit` (`id_produit`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: produit_end
#

DROP TABLE IF EXISTS `produit_end`;

CREATE TABLE `produit_end` (
  `id_produit_end` int(11) NOT NULL AUTO_INCREMENT,
  `id_produit` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `quantite` double NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_produit_end`),
  KEY `id_produit` (`id_produit`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `produit_end_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `produit_end_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: sub_categorie
#

DROP TABLE IF EXISTS `sub_categorie`;

CREATE TABLE `sub_categorie` (
  `id_sub_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `id_categorie` int(11) DEFAULT NULL,
  `full_name` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `display` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Show, 0=Hide',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sub_categorie`),
  KEY `id_categorie` (`id_categorie`),
  CONSTRAINT `sub_categorie_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categorie` (`id_categorie`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `sub_categorie` (`id_sub_categorie`, `id_categorie`, `full_name`, `description`, `display`, `date_create`, `date_update`) VALUES (1, 1, 'Raja Alexander', 'Nihil est quidem nesciunt molestiae debitis obcaecati et voluptate ipsum aliqua Sed enim reprehenderit molestias aut', 1, '2023-08-14 03:32:25', '2023-08-14 03:32:29');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `role` int(11) NOT NULL DEFAULT '0' COMMENT '0=MANAGER, 1=ADMIN',
  `authenticator` int(11) NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `last_logout` datetime DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id_user`, `full_name`, `username`, `password`, `role`, `authenticator`, `last_login`, `last_logout`, `date_create`, `date_update`) VALUES (1, 'FMS', 'admin', '$2y$10$N7rV.xJyeQJ07HWRBwpKCut.73BSwcXzkYurloI1LxoySXLoMYwmq', 1, 0, '2023-08-14 09:36:00', '2023-08-14 09:36:00', NULL, '2023-08-14 03:36:22');
INSERT INTO `user` (`id_user`, `full_name`, `username`, `password`, `role`, `authenticator`, `last_login`, `last_logout`, `date_create`, `date_update`) VALUES (2, 'Demo Access', 'demo', '$2y$10$XOC5b.r4IqKySXGl4qlf5.F6DrS.gtIB1VjvRla7ZyH12zEJU5fOK', 1, 0, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: user_log
#

DROP TABLE IF EXISTS `user_log`;

CREATE TABLE `user_log` (
  `id_user_log` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `systeme` tinyint(4) NOT NULL DEFAULT '0',
  `ip_address` varchar(100) NOT NULL,
  `date_log` datetime NOT NULL,
  `text` varchar(200) NOT NULL,
  PRIMARY KEY (`id_user_log`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `user_log_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (1, 1, 0, '169.254.96.43', '2023-06-13 15:18:20', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (2, 1, 0, '196.89.134.245', '2023-08-12 12:49:49', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (3, 1, 0, '196.89.134.245', '2023-08-12 12:51:42', 'Modification de profile');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (4, 1, 0, '196.89.134.245', '2023-08-12 12:54:26', 'Déconnexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (5, 1, 0, '196.89.134.245', '2023-08-12 12:54:38', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (6, 1, 0, '196.89.134.245', '2023-08-12 12:55:04', 'Déconnexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (7, 1, 0, '196.89.134.245', '2023-08-12 12:55:07', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (8, 1, 0, '196.89.134.245', '2023-08-12 12:55:40', 'Déconnexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (9, 1, 0, '196.89.134.245', '2023-08-12 12:56:38', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (10, 1, 0, '196.89.134.245', '2023-08-12 13:00:28', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (11, 1, 0, '196.74.151.235', '2023-08-14 09:29:29', 'Enregistrement de client ( <b>Telaj med</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (12, 1, 0, '196.74.151.235', '2023-08-14 09:29:34', 'Connexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (13, 1, 0, '196.74.151.235', '2023-08-14 09:31:33', 'Modification de client ( <b>Telaj med</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (14, 1, 0, '196.74.151.235', '2023-08-14 09:31:39', 'Suppression de client ( <b>Telaj med</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (15, 1, 0, '196.74.151.235', '2023-08-14 09:31:56', 'Enregistrement de catégorie ( <b>Shellie Santos</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (16, 1, 0, '196.74.151.235', '2023-08-14 09:32:25', 'Enregistrement de sous-catégorie ( <b>Raja Alexander</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (17, 1, 0, '196.74.151.235', '2023-08-14 09:32:29', 'Modification de catégorie ( <b>Shellie Santoss</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (18, 1, 0, '196.74.151.235', '2023-08-14 09:32:49', 'Enregistrement de produit ( <b>Alea Serrano</b> ) avec image');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (19, 1, 0, '196.74.151.235', '2023-08-14 09:34:57', 'Enregistrement de fournisseur ( <b>Keaton Gould</b> )');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (20, 1, 0, '196.74.151.235', '2023-08-14 09:36:13', 'Déconnexion');
INSERT INTO `user_log` (`id_user_log`, `id_user`, `systeme`, `ip_address`, `date_log`, `text`) VALUES (21, 1, 0, '196.74.151.235', '2023-08-14 09:36:22', 'Connexion');


#
# TABLE STRUCTURE FOR: vente
#

DROP TABLE IF EXISTS `vente`;

CREATE TABLE `vente` (
  `id_vente` int(11) NOT NULL AUTO_INCREMENT,
  `id_client_cmd` int(11) DEFAULT NULL,
  `id_devis` int(11) DEFAULT NULL,
  `code_vente` varchar(200) NOT NULL,
  `num_facture` varchar(200) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_client` int(11) DEFAULT NULL,
  `remarque` varchar(200) DEFAULT NULL,
  `tva` double NOT NULL DEFAULT '20',
  `date_vente` date NOT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_vente`),
  UNIQUE KEY `code_vente` (`code_vente`),
  UNIQUE KEY `num_facture` (`num_facture`),
  KEY `id_user` (`id_user`),
  KEY `id_client` (`id_client`),
  KEY `id_client_cmd` (`id_client_cmd`),
  KEY `id_devis` (`id_devis`),
  CONSTRAINT `vente_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `vente_ibfk_2` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `vente_ibfk_3` FOREIGN KEY (`id_client_cmd`) REFERENCES `client_cmd` (`id_client_cmd`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `vente_ibfk_4` FOREIGN KEY (`id_devis`) REFERENCES `devis` (`id_devis`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: vente_details
#

DROP TABLE IF EXISTS `vente_details`;

CREATE TABLE `vente_details` (
  `id_vente_details` int(11) NOT NULL AUTO_INCREMENT,
  `id_vente` int(11) NOT NULL,
  `id_produit` int(11) DEFAULT NULL,
  `quantite` double NOT NULL,
  `prix_vente` double NOT NULL DEFAULT '1',
  `remise` double NOT NULL DEFAULT '0',
  `remise_dh` double NOT NULL DEFAULT '0',
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_vente_details`),
  KEY `id_produit` (`id_produit`),
  KEY `id_vente` (`id_vente`),
  CONSTRAINT `vente_details_ibfk_1` FOREIGN KEY (`id_produit`) REFERENCES `produit` (`id_produit`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `vente_details_ibfk_2` FOREIGN KEY (`id_vente`) REFERENCES `vente` (`id_vente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

